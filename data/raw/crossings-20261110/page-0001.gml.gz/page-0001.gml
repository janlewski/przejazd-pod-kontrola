<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:16" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=2000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>209932.827000 639194.466087</gml:lowerCorner>
      		<gml:upperCorner>721860.373867 828016.003000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458519.687251 732470.821804</gml:lowerCorner>
        		<gml:upperCorner>458519.687251 732470.821804</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458519.687251 732470.821804</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 119 973</ms:GML_ID>
        <ms:NAZWA>002 119 973</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002119973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458636.941471 731827.541885</gml:lowerCorner>
        		<gml:upperCorner>458636.941471 731827.541885</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458636.941471 731827.541885</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 158 985</ms:GML_ID>
        <ms:NAZWA>012 158 985</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012158985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458716.867000 741232.706000</gml:lowerCorner>
        		<gml:upperCorner>458716.867000 741232.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458716.867000 741232.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 129 294</ms:GML_ID>
        <ms:NAZWA>002 129 294</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002129294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458776.899900 731791.923168</gml:lowerCorner>
        		<gml:upperCorner>458776.899900 731791.923168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458776.899900 731791.923168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.523 001 045</ms:GML_ID>
        <ms:NAZWA>523 001 045</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>523001045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459305.962000 743405.425000</gml:lowerCorner>
        		<gml:upperCorner>459305.962000 743405.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459305.962000 743405.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 131 540</ms:GML_ID>
        <ms:NAZWA>002 131 540</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002131540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460085.239059 746280.743422</gml:lowerCorner>
        		<gml:upperCorner>460085.239059 746280.743422</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460085.239059 746280.743422</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 134 522</ms:GML_ID>
        <ms:NAZWA>002 134 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002134522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460307.496981 747802.317690</gml:lowerCorner>
        		<gml:upperCorner>460307.496981 747802.317690</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460307.496981 747802.317690</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 136 063</ms:GML_ID>
        <ms:NAZWA>002 136 063</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002136063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460334.388000 731479.557000</gml:lowerCorner>
        		<gml:upperCorner>460334.388000 731479.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460334.388000 731479.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 117 828</ms:GML_ID>
        <ms:NAZWA>002 117 828</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002117828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460507.980850 749842.359731</gml:lowerCorner>
        		<gml:upperCorner>460507.980850 749842.359731</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460507.980850 749842.359731</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 138 114</ms:GML_ID>
        <ms:NAZWA>002 138 114</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002138114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461207.731000 753308.389000</gml:lowerCorner>
        		<gml:upperCorner>461207.731000 753308.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461207.731000 753308.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 141 677</ms:GML_ID>
        <ms:NAZWA>002 141 677</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002141677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462842.009000 757401.900000</gml:lowerCorner>
        		<gml:upperCorner>462842.009000 757401.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462842.009000 757401.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 146 084</ms:GML_ID>
        <ms:NAZWA>002 146 084</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002146084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463355.377731 759662.906668</gml:lowerCorner>
        		<gml:upperCorner>463355.377731 759662.906668</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463355.377731 759662.906668</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 148 416</ms:GML_ID>
        <ms:NAZWA>002 148 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002148416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464682.384000 731546.022000</gml:lowerCorner>
        		<gml:upperCorner>464682.384000 731546.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464682.384000 731546.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 113 446</ms:GML_ID>
        <ms:NAZWA>002 113 446</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002113446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464785.602000 765366.702000</gml:lowerCorner>
        		<gml:upperCorner>464785.602000 765366.702000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464785.602000 765366.702000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 154 297</ms:GML_ID>
        <ms:NAZWA>002 154 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002154297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465436.782000 731610.615000</gml:lowerCorner>
        		<gml:upperCorner>465436.782000 731610.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465436.782000 731610.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 112 689</ms:GML_ID>
        <ms:NAZWA>002 112 689</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002112689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468160.900000 731842.608000</gml:lowerCorner>
        		<gml:upperCorner>468160.900000 731842.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468160.900000 731842.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 109 954</ms:GML_ID>
        <ms:NAZWA>002 109 954</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002109954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469583.575000 731963.379000</gml:lowerCorner>
        		<gml:upperCorner>469583.575000 731963.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469583.575000 731963.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 108 528</ms:GML_ID>
        <ms:NAZWA>002 108 528</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002108528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470757.703000 732063.271000</gml:lowerCorner>
        		<gml:upperCorner>470757.703000 732063.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470757.703000 732063.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 107 349</ms:GML_ID>
        <ms:NAZWA>002 107 349</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002107349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472712.512000 731511.094000</gml:lowerCorner>
        		<gml:upperCorner>472712.512000 731511.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472712.512000 731511.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 105 242</ms:GML_ID>
        <ms:NAZWA>002 105 242</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002105242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473957.810000 730468.592000</gml:lowerCorner>
        		<gml:upperCorner>473957.810000 730468.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473957.810000 730468.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 103 619</ms:GML_ID>
        <ms:NAZWA>002 103 619</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002103619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474522.766000 729995.736000</gml:lowerCorner>
        		<gml:upperCorner>474522.766000 729995.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474522.766000 729995.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 102 880</ms:GML_ID>
        <ms:NAZWA>002 102 880</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002102880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475294.272000 729350.251000</gml:lowerCorner>
        		<gml:upperCorner>475294.272000 729350.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475294.272000 729350.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 101 874</ms:GML_ID>
        <ms:NAZWA>002 101 874</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002101874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476463.606000 728371.522000</gml:lowerCorner>
        		<gml:upperCorner>476463.606000 728371.522000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476463.606000 728371.522000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 100 349</ms:GML_ID>
        <ms:NAZWA>002 100 349</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002100349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477280.094000 727688.014000</gml:lowerCorner>
        		<gml:upperCorner>477280.094000 727688.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477280.094000 727688.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 099 285</ms:GML_ID>
        <ms:NAZWA>002 099 285</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002099285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478774.804000 726441.188000</gml:lowerCorner>
        		<gml:upperCorner>478774.804000 726441.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478774.804000 726441.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 097 340</ms:GML_ID>
        <ms:NAZWA>002 097 340</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002097340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479800.449000 726165.410000</gml:lowerCorner>
        		<gml:upperCorner>479800.449000 726165.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479800.449000 726165.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.520 000 530</ms:GML_ID>
        <ms:NAZWA>520 000 530</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>520000530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458396.454000 688314.166000</gml:lowerCorner>
        		<gml:upperCorner>458396.454000 688314.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458396.454000 688314.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 114 934</ms:GML_ID>
        <ms:NAZWA>012 114 934</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012114934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480129.600000 689368.900000</gml:lowerCorner>
        		<gml:upperCorner>480129.600000 689368.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480129.600000 689368.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 056 129</ms:GML_ID>
        <ms:NAZWA>002 056 129</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002056129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458270.866000 689915.479000</gml:lowerCorner>
        		<gml:upperCorner>458270.866000 689915.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458270.866000 689915.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 116 546</ms:GML_ID>
        <ms:NAZWA>012 116 546</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012116546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458627.505000 691605.770000</gml:lowerCorner>
        		<gml:upperCorner>458627.505000 691605.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458627.505000 691605.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 118 294</ms:GML_ID>
        <ms:NAZWA>012 118 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012118294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481363.739596 691798.243014</gml:lowerCorner>
        		<gml:upperCorner>481363.739596 691798.243014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481363.739596 691798.243014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 058 869</ms:GML_ID>
        <ms:NAZWA>002 058 869</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002058869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459025.135000 693484.689000</gml:lowerCorner>
        		<gml:upperCorner>459025.135000 693484.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459025.135000 693484.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 120 194</ms:GML_ID>
        <ms:NAZWA>012 120 194</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012120194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459346.942000 695005.306000</gml:lowerCorner>
        		<gml:upperCorner>459346.942000 695005.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459346.942000 695005.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 121 752</ms:GML_ID>
        <ms:NAZWA>012 121 752</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012121752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480685.342000 695193.943000</gml:lowerCorner>
        		<gml:upperCorner>480685.342000 695193.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480685.342000 695193.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 062 501</ms:GML_ID>
        <ms:NAZWA>002 062 501</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002062501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481079.470000 696400.715000</gml:lowerCorner>
        		<gml:upperCorner>481079.470000 696400.715000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481079.470000 696400.715000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 063 796</ms:GML_ID>
        <ms:NAZWA>002 063 796</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002063796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459788.691000 697431.614000</gml:lowerCorner>
        		<gml:upperCorner>459788.691000 697431.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459788.691000 697431.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 124 222</ms:GML_ID>
        <ms:NAZWA>012 124 222</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012124222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481634.789130 697626.621085</gml:lowerCorner>
        		<gml:upperCorner>481634.789130 697626.621085</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481634.789130 697626.621085</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 065 146</ms:GML_ID>
        <ms:NAZWA>002 065 146</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002065146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459578.779000 698275.661000</gml:lowerCorner>
        		<gml:upperCorner>459578.779000 698275.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459578.779000 698275.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 125 094</ms:GML_ID>
        <ms:NAZWA>012 125 094</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012125094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459478.626000 698648.877000</gml:lowerCorner>
        		<gml:upperCorner>459478.626000 698648.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459478.626000 698648.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 125 478</ms:GML_ID>
        <ms:NAZWA>012 125 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012125478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459304.224569 699297.518167</gml:lowerCorner>
        		<gml:upperCorner>459304.224569 699297.518167</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459304.224569 699297.518167</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 126 159</ms:GML_ID>
        <ms:NAZWA>012 126 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012126159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459103.378479 700046.162272</gml:lowerCorner>
        		<gml:upperCorner>459103.378479 700046.162272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459103.378479 700046.162272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 126 930</ms:GML_ID>
        <ms:NAZWA>012 126 930</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012126930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481978.915000 705116.998000</gml:lowerCorner>
        		<gml:upperCorner>481978.915000 705116.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481978.915000 705116.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 073 104</ms:GML_ID>
        <ms:NAZWA>002 073 104</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002073104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458207.087000 705183.710000</gml:lowerCorner>
        		<gml:upperCorner>458207.087000 705183.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458207.087000 705183.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 132 182</ms:GML_ID>
        <ms:NAZWA>012 132 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012132182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457996.540000 706210.071000</gml:lowerCorner>
        		<gml:upperCorner>457996.540000 706210.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457996.540000 706210.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 133 237</ms:GML_ID>
        <ms:NAZWA>012 133 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012133237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457930.200000 706888.505000</gml:lowerCorner>
        		<gml:upperCorner>457930.200000 706888.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457930.200000 706888.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 133 919</ms:GML_ID>
        <ms:NAZWA>012 133 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012133919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457803.035286 708331.544597</gml:lowerCorner>
        		<gml:upperCorner>457803.035286 708331.544597</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457803.035286 708331.544597</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 135 368</ms:GML_ID>
        <ms:NAZWA>012 135 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012135368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483630.513000 710450.232000</gml:lowerCorner>
        		<gml:upperCorner>483630.513000 710450.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483630.513000 710450.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 078 744</ms:GML_ID>
        <ms:NAZWA>002 078 744</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002078744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457843.964883 711973.614973</gml:lowerCorner>
        		<gml:upperCorner>457843.964883 711973.614973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457843.964883 711973.614973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 139 041</ms:GML_ID>
        <ms:NAZWA>012 139 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012139041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483306.970808 716873.378191</gml:lowerCorner>
        		<gml:upperCorner>483306.970808 716873.378191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483306.970808 716873.378191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 085 331</ms:GML_ID>
        <ms:NAZWA>002 085 331</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002085331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483535.031000 721166.210000</gml:lowerCorner>
        		<gml:upperCorner>483535.031000 721166.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483535.031000 721166.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 089 863</ms:GML_ID>
        <ms:NAZWA>002 089 863</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002089863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445317.512000 725946.676000</gml:lowerCorner>
        		<gml:upperCorner>445317.512000 725946.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445317.512000 725946.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 016 129</ms:GML_ID>
        <ms:NAZWA>026 016 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026016129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447063.225000 727010.255000</gml:lowerCorner>
        		<gml:upperCorner>447063.225000 727010.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447063.225000 727010.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 014 070</ms:GML_ID>
        <ms:NAZWA>026 014 070</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026014070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447584.906000 727461.610000</gml:lowerCorner>
        		<gml:upperCorner>447584.906000 727461.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447584.906000 727461.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 013 381</ms:GML_ID>
        <ms:NAZWA>026 013 381</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026013381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448296.362996 728163.801682</gml:lowerCorner>
        		<gml:upperCorner>448296.362996 728163.801682</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448296.362996 728163.801682</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 012 381</ms:GML_ID>
        <ms:NAZWA>026 012 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026012381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449983.985000 729355.755000</gml:lowerCorner>
        		<gml:upperCorner>449983.985000 729355.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449983.985000 729355.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 010 279</ms:GML_ID>
        <ms:NAZWA>026 010 279</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026010279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452411.583000 730149.648000</gml:lowerCorner>
        		<gml:upperCorner>452411.583000 730149.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452411.583000 730149.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 007 716</ms:GML_ID>
        <ms:NAZWA>026 007 716</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026007716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455700.300000 730821.836000</gml:lowerCorner>
        		<gml:upperCorner>455700.300000 730821.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455700.300000 730821.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 004 354</ms:GML_ID>
        <ms:NAZWA>026 004 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>026004354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456354.896113 730951.271062</gml:lowerCorner>
        		<gml:upperCorner>456354.896113 730951.271062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456354.896113 730951.271062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 003 691</ms:GML_ID>
        <ms:NAZWA>026 003 691</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>026003691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456729.478959 731045.228514</gml:lowerCorner>
        		<gml:upperCorner>456729.478959 731045.228514</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456729.478959 731045.228514</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 003 307</ms:GML_ID>
        <ms:NAZWA>026 003 307</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>026003307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457281.325000 731149.172000</gml:lowerCorner>
        		<gml:upperCorner>457281.325000 731149.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457281.325000 731149.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 002 744</ms:GML_ID>
        <ms:NAZWA>026 002 744</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>026002744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457292.320000 734559.982000</gml:lowerCorner>
        		<gml:upperCorner>457292.320000 734559.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457292.320000 734559.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 122 394</ms:GML_ID>
        <ms:NAZWA>002 122 394</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002122394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457161.864000 734738.539000</gml:lowerCorner>
        		<gml:upperCorner>457161.864000 734738.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457161.864000 734738.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 002 166</ms:GML_ID>
        <ms:NAZWA>030 002 166</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>030002166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457238.184000 735778.606000</gml:lowerCorner>
        		<gml:upperCorner>457238.184000 735778.606000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457238.184000 735778.606000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 123 640</ms:GML_ID>
        <ms:NAZWA>002 123 640</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002123640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455078.535578 738290.807264</gml:lowerCorner>
        		<gml:upperCorner>455078.535578 738290.807264</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455078.535578 738290.807264</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 006 285</ms:GML_ID>
        <ms:NAZWA>030 006 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030006285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454425.816000 739401.054000</gml:lowerCorner>
        		<gml:upperCorner>454425.816000 739401.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454425.816000 739401.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 007 571</ms:GML_ID>
        <ms:NAZWA>030 007 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030007571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453538.922000 740907.987000</gml:lowerCorner>
        		<gml:upperCorner>453538.922000 740907.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453538.922000 740907.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 009 318</ms:GML_ID>
        <ms:NAZWA>030 009 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030009318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451090.481078 745066.364191</gml:lowerCorner>
        		<gml:upperCorner>451090.481078 745066.364191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451090.481078 745066.364191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 014 148</ms:GML_ID>
        <ms:NAZWA>030 014 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030014148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450203.589343 746569.640605</gml:lowerCorner>
        		<gml:upperCorner>450203.589343 746569.640605</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450203.589343 746569.640605</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 015 895</ms:GML_ID>
        <ms:NAZWA>030 015 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030015895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449761.460000 747226.255000</gml:lowerCorner>
        		<gml:upperCorner>449761.460000 747226.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449761.460000 747226.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 016 680</ms:GML_ID>
        <ms:NAZWA>030 016 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030016680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448618.906754 749018.370683</gml:lowerCorner>
        		<gml:upperCorner>448618.906754 749018.370683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448618.906754 749018.370683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 018 816</ms:GML_ID>
        <ms:NAZWA>030 018 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030018816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448177.767726 749766.339067</gml:lowerCorner>
        		<gml:upperCorner>448177.767726 749766.339067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448177.767726 749766.339067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 019 682</ms:GML_ID>
        <ms:NAZWA>030 019 682</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030019682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457748.877000 709194.723000</gml:lowerCorner>
        		<gml:upperCorner>457748.877000 709194.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457748.877000 709194.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 136 232</ms:GML_ID>
        <ms:NAZWA>012 136 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012136232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457761.831000 713422.907000</gml:lowerCorner>
        		<gml:upperCorner>457761.831000 713422.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457761.831000 713422.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 140 492</ms:GML_ID>
        <ms:NAZWA>012 140 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012140492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457714.058000 714261.578000</gml:lowerCorner>
        		<gml:upperCorner>457714.058000 714261.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457714.058000 714261.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 141 332</ms:GML_ID>
        <ms:NAZWA>012 141 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012141332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457635.969000 716233.125000</gml:lowerCorner>
        		<gml:upperCorner>457635.969000 716233.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457635.969000 716233.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 143 307</ms:GML_ID>
        <ms:NAZWA>012 143 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012143307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457593.657000 717841.326000</gml:lowerCorner>
        		<gml:upperCorner>457593.657000 717841.326000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457593.657000 717841.326000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 144 914</ms:GML_ID>
        <ms:NAZWA>012 144 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012144914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436634.020130 718020.935464</gml:lowerCorner>
        		<gml:upperCorner>436634.020130 718020.935464</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436634.020130 718020.935464</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 028 092</ms:GML_ID>
        <ms:NAZWA>026 028 092</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026028092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457563.242000 718469.067000</gml:lowerCorner>
        		<gml:upperCorner>457563.242000 718469.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457563.242000 718469.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 145 543</ms:GML_ID>
        <ms:NAZWA>012 145 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012145543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457555.747000 719571.502000</gml:lowerCorner>
        		<gml:upperCorner>457555.747000 719571.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457555.747000 719571.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 146 644</ms:GML_ID>
        <ms:NAZWA>012 146 644</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012146644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439573.754828 719731.457874</gml:lowerCorner>
        		<gml:upperCorner>439573.754828 719731.457874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439573.754828 719731.457874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 024 694</ms:GML_ID>
        <ms:NAZWA>026 024 694</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026024694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441186.627000 720762.281000</gml:lowerCorner>
        		<gml:upperCorner>441186.627000 720762.281000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441186.627000 720762.281000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 022 773</ms:GML_ID>
        <ms:NAZWA>026 022 773</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026022773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457648.881000 721950.119000</gml:lowerCorner>
        		<gml:upperCorner>457648.881000 721950.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457648.881000 721950.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 149 027</ms:GML_ID>
        <ms:NAZWA>012 149 027</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012149027</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442406.272000 722133.576000</gml:lowerCorner>
        		<gml:upperCorner>442406.272000 722133.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442406.272000 722133.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 020 934</ms:GML_ID>
        <ms:NAZWA>026 020 934</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026020934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457666.953000 722410.707000</gml:lowerCorner>
        		<gml:upperCorner>457666.953000 722410.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457666.953000 722410.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 149 497</ms:GML_ID>
        <ms:NAZWA>012 149 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012149497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442995.629676 722861.080550</gml:lowerCorner>
        		<gml:upperCorner>442995.629676 722861.080550</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442995.629676 722861.080550</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 019 998</ms:GML_ID>
        <ms:NAZWA>026 019 998</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026019998</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443620.008000 723630.657000</gml:lowerCorner>
        		<gml:upperCorner>443620.008000 723630.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443620.008000 723630.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 019 006</ms:GML_ID>
        <ms:NAZWA>026 019 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026019006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457714.357000 723630.951000</gml:lowerCorner>
        		<gml:upperCorner>457714.357000 723630.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457714.357000 723630.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 150 710</ms:GML_ID>
        <ms:NAZWA>012 150 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012150710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457767.414000 724985.918000</gml:lowerCorner>
        		<gml:upperCorner>457767.414000 724985.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457767.414000 724985.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 152 064</ms:GML_ID>
        <ms:NAZWA>012 152 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012152064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444853.466465 725185.823653</gml:lowerCorner>
        		<gml:upperCorner>444853.466465 725185.823653</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444853.466465 725185.823653</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 017 023</ms:GML_ID>
        <ms:NAZWA>026 017 023</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026017023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417930.940000 762181.141000</gml:lowerCorner>
        		<gml:upperCorner>417930.940000 762181.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417930.940000 762181.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 062 185</ms:GML_ID>
        <ms:NAZWA>030 062 185</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030062185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419351.904952 762746.232189</gml:lowerCorner>
        		<gml:upperCorner>419351.904952 762746.232189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419351.904952 762746.232189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 060 651</ms:GML_ID>
        <ms:NAZWA>030 060 651</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030060651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420377.488523 763678.874821</gml:lowerCorner>
        		<gml:upperCorner>420377.488523 763678.874821</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420377.488523 763678.874821</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 059 266</ms:GML_ID>
        <ms:NAZWA>030 059 266</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030059266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422524.797586 765694.222711</gml:lowerCorner>
        		<gml:upperCorner>422524.797586 765694.222711</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422524.797586 765694.222711</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 056 324</ms:GML_ID>
        <ms:NAZWA>030 056 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030056324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423761.477000 766854.637000</gml:lowerCorner>
        		<gml:upperCorner>423761.477000 766854.637000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423761.477000 766854.637000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 054 627</ms:GML_ID>
        <ms:NAZWA>030 054 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030054627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424552.526847 767596.480074</gml:lowerCorner>
        		<gml:upperCorner>424552.526847 767596.480074</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424552.526847 767596.480074</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 053 549</ms:GML_ID>
        <ms:NAZWA>030 053 549</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030053549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425854.875039 768454.048604</gml:lowerCorner>
        		<gml:upperCorner>425854.875039 768454.048604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425854.875039 768454.048604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 051 912</ms:GML_ID>
        <ms:NAZWA>030 051 912</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030051912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426672.037790 768274.880645</gml:lowerCorner>
        		<gml:upperCorner>426672.037790 768274.880645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426672.037790 768274.880645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 051 075</ms:GML_ID>
        <ms:NAZWA>030 051 075</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030051075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433347.603161 767657.656927</gml:lowerCorner>
        		<gml:upperCorner>433347.603161 767657.656927</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433347.603161 767657.656927</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 044 372</ms:GML_ID>
        <ms:NAZWA>030 044 372</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030044372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436915.814170 767337.747572</gml:lowerCorner>
        		<gml:upperCorner>436915.814170 767337.747572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436915.814170 767337.747572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 040 789</ms:GML_ID>
        <ms:NAZWA>030 040 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030040789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438260.269384 766614.675066</gml:lowerCorner>
        		<gml:upperCorner>438260.269384 766614.675066</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438260.269384 766614.675066</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 039 325</ms:GML_ID>
        <ms:NAZWA>030 039 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030039325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438684.095635 765959.107715</gml:lowerCorner>
        		<gml:upperCorner>438684.095635 765959.107715</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438684.095635 765959.107715</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 038 443</ms:GML_ID>
        <ms:NAZWA>030 038 443</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030038443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439392.541770 764746.759666</gml:lowerCorner>
        		<gml:upperCorner>439392.541770 764746.759666</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439392.541770 764746.759666</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 037 050</ms:GML_ID>
        <ms:NAZWA>030 037 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030037050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440280.223816 763279.385215</gml:lowerCorner>
        		<gml:upperCorner>440280.223816 763279.385215</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440280.223816 763279.385215</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 035 337</ms:GML_ID>
        <ms:NAZWA>030 035 337</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030035337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440751.954062 762421.493436</gml:lowerCorner>
        		<gml:upperCorner>440751.954062 762421.493436</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440751.954062 762421.493436</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 034 354</ms:GML_ID>
        <ms:NAZWA>030 034 354</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030034354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441535.194306 761084.753459</gml:lowerCorner>
        		<gml:upperCorner>441535.194306 761084.753459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441535.194306 761084.753459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 032 798</ms:GML_ID>
        <ms:NAZWA>030 032 798</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030032798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442534.047000 759380.244000</gml:lowerCorner>
        		<gml:upperCorner>442534.047000 759380.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442534.047000 759380.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 030 832</ms:GML_ID>
        <ms:NAZWA>030 030 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030030832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442898.428075 758759.327938</gml:lowerCorner>
        		<gml:upperCorner>442898.428075 758759.327938</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442898.428075 758759.327938</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 030 110</ms:GML_ID>
        <ms:NAZWA>030 030 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030030110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443876.062000 757091.750000</gml:lowerCorner>
        		<gml:upperCorner>443876.062000 757091.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443876.062000 757091.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 028 175</ms:GML_ID>
        <ms:NAZWA>030 028 175</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030028175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444822.971551 755477.694730</gml:lowerCorner>
        		<gml:upperCorner>444822.971551 755477.694730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444822.971551 755477.694730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 026 306</ms:GML_ID>
        <ms:NAZWA>030 026 306</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030026306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445307.274216 754652.454269</gml:lowerCorner>
        		<gml:upperCorner>445307.274216 754652.454269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445307.274216 754652.454269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 025 349</ms:GML_ID>
        <ms:NAZWA>030 025 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030025349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446061.194000 753367.254000</gml:lowerCorner>
        		<gml:upperCorner>446061.194000 753367.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446061.194000 753367.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 023 859</ms:GML_ID>
        <ms:NAZWA>030 023 859</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030023859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465606.059000 768373.005000</gml:lowerCorner>
        		<gml:upperCorner>465606.059000 768373.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465606.059000 768373.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 157 414</ms:GML_ID>
        <ms:NAZWA>002 157 414</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002157414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467883.813000 790902.354000</gml:lowerCorner>
        		<gml:upperCorner>467883.813000 790902.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467883.813000 790902.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 180 806</ms:GML_ID>
        <ms:NAZWA>002 180 806</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002180806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468413.974000 778656.023000</gml:lowerCorner>
        		<gml:upperCorner>468413.974000 778656.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468413.974000 778656.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 168 070</ms:GML_ID>
        <ms:NAZWA>002 168 070</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002168070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469365.370314 786772.532851</gml:lowerCorner>
        		<gml:upperCorner>469365.370314 786772.532851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469365.370314 786772.532851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 176 420</ms:GML_ID>
        <ms:NAZWA>002 176 420</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002176420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702717.032000 761993.496000</gml:lowerCorner>
        		<gml:upperCorner>702717.032000 761993.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702717.032000 761993.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 005 594</ms:GML_ID>
        <ms:NAZWA>051 005 594</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051005594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704094.443563 763336.510558</gml:lowerCorner>
        		<gml:upperCorner>704094.443563 763336.510558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704094.443563 763336.510558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 007 581</ms:GML_ID>
        <ms:NAZWA>051 007 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051007581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705456.054906 763321.250527</gml:lowerCorner>
        		<gml:upperCorner>705456.054906 763321.250527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705456.054906 763321.250527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 008 942</ms:GML_ID>
        <ms:NAZWA>051 008 942</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051008942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706641.983106 763544.856240</gml:lowerCorner>
        		<gml:upperCorner>706641.983106 763544.856240</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706641.983106 763544.856240</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 010 149</ms:GML_ID>
        <ms:NAZWA>051 010 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051010149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707178.381000 763825.431000</gml:lowerCorner>
        		<gml:upperCorner>707178.381000 763825.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707178.381000 763825.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 010 770</ms:GML_ID>
        <ms:NAZWA>051 010 770</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051010770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707987.546000 764727.859000</gml:lowerCorner>
        		<gml:upperCorner>707987.546000 764727.859000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707987.546000 764727.859000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 011 989</ms:GML_ID>
        <ms:NAZWA>051 011 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051011989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708160.143000 764890.671000</gml:lowerCorner>
        		<gml:upperCorner>708160.143000 764890.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708160.143000 764890.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 012 226</ms:GML_ID>
        <ms:NAZWA>051 012 226</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051012226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709108.399000 765850.003000</gml:lowerCorner>
        		<gml:upperCorner>709108.399000 765850.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709108.399000 765850.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 013 601</ms:GML_ID>
        <ms:NAZWA>051 013 601</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051013601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709173.690000 766175.047000</gml:lowerCorner>
        		<gml:upperCorner>709173.690000 766175.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709173.690000 766175.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 013 934</ms:GML_ID>
        <ms:NAZWA>051 013 934</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051013934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709284.082331 766998.578642</gml:lowerCorner>
        		<gml:upperCorner>709284.082331 766998.578642</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709284.082331 766998.578642</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 014 765</ms:GML_ID>
        <ms:NAZWA>051 014 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051014765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709689.719000 767704.367000</gml:lowerCorner>
        		<gml:upperCorner>709689.719000 767704.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709689.719000 767704.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 015 590</ms:GML_ID>
        <ms:NAZWA>051 015 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051015590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710702.955000 768538.999000</gml:lowerCorner>
        		<gml:upperCorner>710702.955000 768538.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710702.955000 768538.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 016 914</ms:GML_ID>
        <ms:NAZWA>051 016 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051016914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711445.916000 769255.383000</gml:lowerCorner>
        		<gml:upperCorner>711445.916000 769255.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711445.916000 769255.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 017 962</ms:GML_ID>
        <ms:NAZWA>051 017 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051017962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712098.033000 770173.261000</gml:lowerCorner>
        		<gml:upperCorner>712098.033000 770173.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712098.033000 770173.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 019 123</ms:GML_ID>
        <ms:NAZWA>051 019 123</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051019123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712820.841000 770935.814000</gml:lowerCorner>
        		<gml:upperCorner>712820.841000 770935.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712820.841000 770935.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 020 188</ms:GML_ID>
        <ms:NAZWA>051 020 188</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051020188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715154.500000 773316.052000</gml:lowerCorner>
        		<gml:upperCorner>715154.500000 773316.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715154.500000 773316.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 023 691</ms:GML_ID>
        <ms:NAZWA>051 023 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051023691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715955.428000 773888.232000</gml:lowerCorner>
        		<gml:upperCorner>715955.428000 773888.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715955.428000 773888.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 024 691</ms:GML_ID>
        <ms:NAZWA>051 024 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051024691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718472.074000 774634.641000</gml:lowerCorner>
        		<gml:upperCorner>718472.074000 774634.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718472.074000 774634.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 027 331</ms:GML_ID>
        <ms:NAZWA>051 027 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051027331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709139.406986 722455.447556</gml:lowerCorner>
        		<gml:upperCorner>709139.406986 722455.447556</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709139.406986 722455.447556</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 046 883</ms:GML_ID>
        <ms:NAZWA>041 046 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041046883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710128.612716 722575.889421</gml:lowerCorner>
        		<gml:upperCorner>710128.612716 722575.889421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710128.612716 722575.889421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 047 886</ms:GML_ID>
        <ms:NAZWA>041 047 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041047886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710482.604000 722616.833000</gml:lowerCorner>
        		<gml:upperCorner>710482.604000 722616.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710482.604000 722616.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 048 243</ms:GML_ID>
        <ms:NAZWA>041 048 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041048243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711344.674000 722622.073000</gml:lowerCorner>
        		<gml:upperCorner>711344.674000 722622.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711344.674000 722622.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 049 106</ms:GML_ID>
        <ms:NAZWA>041 049 106</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041049106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712507.330189 722628.938053</gml:lowerCorner>
        		<gml:upperCorner>712507.330189 722628.938053</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712507.330189 722628.938053</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 050 268</ms:GML_ID>
        <ms:NAZWA>041 050 268</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041050268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707858.777000 722672.039000</gml:lowerCorner>
        		<gml:upperCorner>707858.777000 722672.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707858.777000 722672.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 045 583</ms:GML_ID>
        <ms:NAZWA>041 045 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041045583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705879.947088 722747.451030</gml:lowerCorner>
        		<gml:upperCorner>705879.947088 722747.451030</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705879.947088 722747.451030</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 043 590</ms:GML_ID>
        <ms:NAZWA>041 043 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041043590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706979.676760 722795.913299</gml:lowerCorner>
        		<gml:upperCorner>706979.676760 722795.913299</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706979.676760 722795.913299</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 044 696</ms:GML_ID>
        <ms:NAZWA>041 044 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041044696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706583.050000 722816.901000</gml:lowerCorner>
        		<gml:upperCorner>706583.050000 722816.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706583.050000 722816.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 044 294</ms:GML_ID>
        <ms:NAZWA>041 044 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041044294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705222.322099 722838.209757</gml:lowerCorner>
        		<gml:upperCorner>705222.322099 722838.209757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705222.322099 722838.209757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 042 916</ms:GML_ID>
        <ms:NAZWA>041 042 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041042916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704078.628000 723141.320000</gml:lowerCorner>
        		<gml:upperCorner>704078.628000 723141.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704078.628000 723141.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 041 736</ms:GML_ID>
        <ms:NAZWA>041 041 736</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041041736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715606.567523 723238.184569</gml:lowerCorner>
        		<gml:upperCorner>715606.567523 723238.184569</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715606.567523 723238.184569</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 053 462</ms:GML_ID>
        <ms:NAZWA>041 053 462</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041053462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717202.372000 723574.746000</gml:lowerCorner>
        		<gml:upperCorner>717202.372000 723574.746000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717202.372000 723574.746000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 055 100</ms:GML_ID>
        <ms:NAZWA>041 055 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041055100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701239.993288 723851.788534</gml:lowerCorner>
        		<gml:upperCorner>701239.993288 723851.788534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701239.993288 723851.788534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 038 807</ms:GML_ID>
        <ms:NAZWA>041 038 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041038807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699719.646692 724242.038576</gml:lowerCorner>
        		<gml:upperCorner>699719.646692 724242.038576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699719.646692 724242.038576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 037 235</ms:GML_ID>
        <ms:NAZWA>041 037 235</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041037235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698925.468746 724416.346219</gml:lowerCorner>
        		<gml:upperCorner>698925.468746 724416.346219</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698925.468746 724416.346219</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 036 424</ms:GML_ID>
        <ms:NAZWA>041 036 424</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041036424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697875.131247 725022.371570</gml:lowerCorner>
        		<gml:upperCorner>697875.131247 725022.371570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697875.131247 725022.371570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 035 205</ms:GML_ID>
        <ms:NAZWA>041 035 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041035205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687751.326000 760096.772000</gml:lowerCorner>
        		<gml:upperCorner>687751.326000 760096.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687751.326000 760096.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 085 104</ms:GML_ID>
        <ms:NAZWA>040 085 104</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040085104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689107.174000 759685.884000</gml:lowerCorner>
        		<gml:upperCorner>689107.174000 759685.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689107.174000 759685.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 086 517</ms:GML_ID>
        <ms:NAZWA>040 086 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040086517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690315.270000 759320.618000</gml:lowerCorner>
        		<gml:upperCorner>690315.270000 759320.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690315.270000 759320.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 087 779</ms:GML_ID>
        <ms:NAZWA>040 087 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040087779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691725.295000 750905.500000</gml:lowerCorner>
        		<gml:upperCorner>691725.295000 750905.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691725.295000 750905.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 029 972</ms:GML_ID>
        <ms:NAZWA>039 029 972</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039029972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691924.216000 758840.201000</gml:lowerCorner>
        		<gml:upperCorner>691924.216000 758840.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691924.216000 758840.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 089 453</ms:GML_ID>
        <ms:NAZWA>040 089 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040089453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692451.479000 751757.144000</gml:lowerCorner>
        		<gml:upperCorner>692451.479000 751757.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692451.479000 751757.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 031 109</ms:GML_ID>
        <ms:NAZWA>039 031 109</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039031109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692610.102000 752048.965000</gml:lowerCorner>
        		<gml:upperCorner>692610.102000 752048.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692610.102000 752048.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 031 444</ms:GML_ID>
        <ms:NAZWA>039 031 444</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039031444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693029.594000 758510.756000</gml:lowerCorner>
        		<gml:upperCorner>693029.594000 758510.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693029.594000 758510.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 090 610</ms:GML_ID>
        <ms:NAZWA>040 090 610</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040090610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693880.065000 753670.282000</gml:lowerCorner>
        		<gml:upperCorner>693880.065000 753670.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693880.065000 753670.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 033 531</ms:GML_ID>
        <ms:NAZWA>039 033 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039033531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694447.606000 753904.636000</gml:lowerCorner>
        		<gml:upperCorner>694447.606000 753904.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694447.606000 753904.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 034 151</ms:GML_ID>
        <ms:NAZWA>039 034 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039034151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695632.717097 755289.660318</gml:lowerCorner>
        		<gml:upperCorner>695632.717097 755289.660318</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695632.717097 755289.660318</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 035 974</ms:GML_ID>
        <ms:NAZWA>039 035 974</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039035974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695922.523000 757645.908000</gml:lowerCorner>
        		<gml:upperCorner>695922.523000 757645.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695922.523000 757645.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 093 634</ms:GML_ID>
        <ms:NAZWA>040 093 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040093634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696404.133000 757296.808000</gml:lowerCorner>
        		<gml:upperCorner>696404.133000 757296.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696404.133000 757296.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 038 140</ms:GML_ID>
        <ms:NAZWA>039 038 140</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039038140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699988.717000 758415.020000</gml:lowerCorner>
        		<gml:upperCorner>699988.717000 758415.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699988.717000 758415.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 097 850</ms:GML_ID>
        <ms:NAZWA>040 097 850</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040097850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700462.086884 758142.396037</gml:lowerCorner>
        		<gml:upperCorner>700462.086884 758142.396037</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700462.086884 758142.396037</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 098 441</ms:GML_ID>
        <ms:NAZWA>040 098 441</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040098441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701525.047000 759132.610000</gml:lowerCorner>
        		<gml:upperCorner>701525.047000 759132.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701525.047000 759132.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 002 386</ms:GML_ID>
        <ms:NAZWA>051 002 386</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051002386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701694.812000 759392.962000</gml:lowerCorner>
        		<gml:upperCorner>701694.812000 759392.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701694.812000 759392.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 002 700</ms:GML_ID>
        <ms:NAZWA>051 002 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051002700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701910.575000 760611.389000</gml:lowerCorner>
        		<gml:upperCorner>701910.575000 760611.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701910.575000 760611.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.051 003 967</ms:GML_ID>
        <ms:NAZWA>051 003 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>051003967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697591.101519 725247.395290</gml:lowerCorner>
        		<gml:upperCorner>697591.101519 725247.395290</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697591.101519 725247.395290</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 034 842</ms:GML_ID>
        <ms:NAZWA>041 034 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041034842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696943.702000 725782.262000</gml:lowerCorner>
        		<gml:upperCorner>696943.702000 725782.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696943.702000 725782.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 034 004</ms:GML_ID>
        <ms:NAZWA>041 034 004</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041034004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696212.053575 726378.196574</gml:lowerCorner>
        		<gml:upperCorner>696212.053575 726378.196574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696212.053575 726378.196574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 033 060</ms:GML_ID>
        <ms:NAZWA>041 033 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041033060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695986.538606 726559.298342</gml:lowerCorner>
        		<gml:upperCorner>695986.538606 726559.298342</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695986.538606 726559.298342</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 032 765</ms:GML_ID>
        <ms:NAZWA>041 032 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041032765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695398.325475 727045.282888</gml:lowerCorner>
        		<gml:upperCorner>695398.325475 727045.282888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695398.325475 727045.282888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 032 006</ms:GML_ID>
        <ms:NAZWA>041 032 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041032006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694456.499519 727487.090487</gml:lowerCorner>
        		<gml:upperCorner>694456.499519 727487.090487</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694456.499519 727487.090487</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 030 955</ms:GML_ID>
        <ms:NAZWA>041 030 955</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041030955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692286.781000 728248.101000</gml:lowerCorner>
        		<gml:upperCorner>692286.781000 728248.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692286.781000 728248.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 028 652</ms:GML_ID>
        <ms:NAZWA>041 028 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041028652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691928.714917 728412.755874</gml:lowerCorner>
        		<gml:upperCorner>691928.714917 728412.755874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691928.714917 728412.755874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 028 258</ms:GML_ID>
        <ms:NAZWA>041 028 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041028258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691574.531396 728578.270523</gml:lowerCorner>
        		<gml:upperCorner>691574.531396 728578.270523</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691574.531396 728578.270523</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 027 868</ms:GML_ID>
        <ms:NAZWA>041 027 868</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041027868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690298.811691 729209.855335</gml:lowerCorner>
        		<gml:upperCorner>690298.811691 729209.855335</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690298.811691 729209.855335</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 026 442</ms:GML_ID>
        <ms:NAZWA>041 026 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041026442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689097.437000 729741.354000</gml:lowerCorner>
        		<gml:upperCorner>689097.437000 729741.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689097.437000 729741.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 025 122</ms:GML_ID>
        <ms:NAZWA>041 025 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041025122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688248.148433 733073.779718</gml:lowerCorner>
        		<gml:upperCorner>688248.148433 733073.779718</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688248.148433 733073.779718</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 005 568</ms:GML_ID>
        <ms:NAZWA>039 005 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039005568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687422.787000 733625.020000</gml:lowerCorner>
        		<gml:upperCorner>687422.787000 733625.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687422.787000 733625.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 006 572</ms:GML_ID>
        <ms:NAZWA>039 006 572</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039006572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687700.010000 743891.502000</gml:lowerCorner>
        		<gml:upperCorner>687700.010000 743891.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687700.010000 743891.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 020 484</ms:GML_ID>
        <ms:NAZWA>039 020 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039020484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687847.789000 744532.596000</gml:lowerCorner>
        		<gml:upperCorner>687847.789000 744532.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687847.789000 744532.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 021 177</ms:GML_ID>
        <ms:NAZWA>039 021 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039021177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687758.779000 745681.768000</gml:lowerCorner>
        		<gml:upperCorner>687758.779000 745681.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687758.779000 745681.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 022 356</ms:GML_ID>
        <ms:NAZWA>039 022 356</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039022356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687572.541000 747336.138000</gml:lowerCorner>
        		<gml:upperCorner>687572.541000 747336.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687572.541000 747336.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 024 040</ms:GML_ID>
        <ms:NAZWA>039 024 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039024040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688844.193000 747783.113000</gml:lowerCorner>
        		<gml:upperCorner>688844.193000 747783.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688844.193000 747783.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 025 567</ms:GML_ID>
        <ms:NAZWA>039 025 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039025567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688148.386000 747881.394000</gml:lowerCorner>
        		<gml:upperCorner>688148.386000 747881.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688148.386000 747881.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 024 857</ms:GML_ID>
        <ms:NAZWA>039 024 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039024857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689559.629000 748315.938000</gml:lowerCorner>
        		<gml:upperCorner>689559.629000 748315.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689559.629000 748315.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 026 470</ms:GML_ID>
        <ms:NAZWA>039 026 470</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039026470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690049.424000 748884.795000</gml:lowerCorner>
        		<gml:upperCorner>690049.424000 748884.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690049.424000 748884.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 027 228</ms:GML_ID>
        <ms:NAZWA>039 027 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039027228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690570.121000 749457.630000</gml:lowerCorner>
        		<gml:upperCorner>690570.121000 749457.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690570.121000 749457.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 028 007</ms:GML_ID>
        <ms:NAZWA>039 028 007</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039028007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676539.953000 727983.111000</gml:lowerCorner>
        		<gml:upperCorner>676539.953000 727983.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676539.953000 727983.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 011 928</ms:GML_ID>
        <ms:NAZWA>041 011 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041011928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676963.449157 728422.649883</gml:lowerCorner>
        		<gml:upperCorner>676963.449157 728422.649883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676963.449157 728422.649883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 012 540</ms:GML_ID>
        <ms:NAZWA>041 012 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041012540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678203.475991 729378.781095</gml:lowerCorner>
        		<gml:upperCorner>678203.475991 729378.781095</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678203.475991 729378.781095</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 014 146</ms:GML_ID>
        <ms:NAZWA>041 014 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041014146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678486.731000 729446.977000</gml:lowerCorner>
        		<gml:upperCorner>678486.731000 729446.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678486.731000 729446.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 014 438</ms:GML_ID>
        <ms:NAZWA>041 014 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041014438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679705.314463 729739.757502</gml:lowerCorner>
        		<gml:upperCorner>679705.314463 729739.757502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679705.314463 729739.757502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 015 692</ms:GML_ID>
        <ms:NAZWA>041 015 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041015692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687239.873338 729885.591425</gml:lowerCorner>
        		<gml:upperCorner>687239.873338 729885.591425</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687239.873338 729885.591425</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 023 261</ms:GML_ID>
        <ms:NAZWA>041 023 261</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041023261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681025.308000 729942.960000</gml:lowerCorner>
        		<gml:upperCorner>681025.308000 729942.960000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681025.308000 729942.960000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 017 026</ms:GML_ID>
        <ms:NAZWA>041 017 026</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041017026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685442.448485 730020.435267</gml:lowerCorner>
        		<gml:upperCorner>685442.448485 730020.435267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685442.448485 730020.435267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 021 459</ms:GML_ID>
        <ms:NAZWA>041 021 459</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041021459</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681774.446256 730039.229676</gml:lowerCorner>
        		<gml:upperCorner>681774.446256 730039.229676</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681774.446256 730039.229676</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 017 783</ms:GML_ID>
        <ms:NAZWA>041 017 783</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041017783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684139.271741 730041.702905</gml:lowerCorner>
        		<gml:upperCorner>684139.271741 730041.702905</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684139.271741 730041.702905</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 020 155</ms:GML_ID>
        <ms:NAZWA>041 020 155</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041020155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682265.136903 730097.819270</gml:lowerCorner>
        		<gml:upperCorner>682265.136903 730097.819270</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682265.136903 730097.819270</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 018 277</ms:GML_ID>
        <ms:NAZWA>041 018 277</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041018277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686085.070000 736122.301000</gml:lowerCorner>
        		<gml:upperCorner>686085.070000 736122.301000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686085.070000 736122.301000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 010 113</ms:GML_ID>
        <ms:NAZWA>039 010 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039010113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686299.280000 736941.218000</gml:lowerCorner>
        		<gml:upperCorner>686299.280000 736941.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686299.280000 736941.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 010 965</ms:GML_ID>
        <ms:NAZWA>039 010 965</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039010965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686287.678000 737448.921000</gml:lowerCorner>
        		<gml:upperCorner>686287.678000 737448.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686287.678000 737448.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 011 473</ms:GML_ID>
        <ms:NAZWA>039 011 473</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039011473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686256.670000 738260.887000</gml:lowerCorner>
        		<gml:upperCorner>686256.670000 738260.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686256.670000 738260.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 012 287</ms:GML_ID>
        <ms:NAZWA>039 012 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>039012287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685159.844000 742893.760000</gml:lowerCorner>
        		<gml:upperCorner>685159.844000 742893.760000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685159.844000 742893.760000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 017 489</ms:GML_ID>
        <ms:NAZWA>039 017 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039017489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686338.119000 742978.611000</gml:lowerCorner>
        		<gml:upperCorner>686338.119000 742978.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686338.119000 742978.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 018 771</ms:GML_ID>
        <ms:NAZWA>039 018 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039018771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686836.742000 743135.287000</gml:lowerCorner>
        		<gml:upperCorner>686836.742000 743135.287000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686836.742000 743135.287000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.039 019 305</ms:GML_ID>
        <ms:NAZWA>039 019 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>039019305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687021.525000 760360.814000</gml:lowerCorner>
        		<gml:upperCorner>687021.525000 760360.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687021.525000 760360.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 084 324</ms:GML_ID>
        <ms:NAZWA>040 084 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040084324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686003.246000 760558.052000</gml:lowerCorner>
        		<gml:upperCorner>686003.246000 760558.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686003.246000 760558.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 083 286</ms:GML_ID>
        <ms:NAZWA>040 083 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040083286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685356.069362 761335.778474</gml:lowerCorner>
        		<gml:upperCorner>685356.069362 761335.778474</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685356.069362 761335.778474</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 082 240</ms:GML_ID>
        <ms:NAZWA>040 082 240</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040082240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684271.670000 762339.120000</gml:lowerCorner>
        		<gml:upperCorner>684271.670000 762339.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684271.670000 762339.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 080 706</ms:GML_ID>
        <ms:NAZWA>040 080 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040080706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683882.118000 762483.609000</gml:lowerCorner>
        		<gml:upperCorner>683882.118000 762483.609000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683882.118000 762483.609000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 080 289</ms:GML_ID>
        <ms:NAZWA>040 080 289</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040080289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683497.088256 762625.728171</gml:lowerCorner>
        		<gml:upperCorner>683497.088256 762625.728171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683497.088256 762625.728171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 079 878</ms:GML_ID>
        <ms:NAZWA>040 079 878</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040079878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686249.917071 673422.870771</gml:lowerCorner>
        		<gml:upperCorner>686249.917071 673422.870771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686249.917071 673422.870771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 160 514</ms:GML_ID>
        <ms:NAZWA>038 160 514</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038160514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668232.288000 674237.919000</gml:lowerCorner>
        		<gml:upperCorner>668232.288000 674237.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668232.288000 674237.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 063 247</ms:GML_ID>
        <ms:NAZWA>223 063 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223063247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686649.184232 674947.209734</gml:lowerCorner>
        		<gml:upperCorner>686649.184232 674947.209734</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686649.184232 674947.209734</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 158 912</ms:GML_ID>
        <ms:NAZWA>038 158 912</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038158912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686932.421464 675599.362029</gml:lowerCorner>
        		<gml:upperCorner>686932.421464 675599.362029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686932.421464 675599.362029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 158 195</ms:GML_ID>
        <ms:NAZWA>038 158 195</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038158195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669349.688000 675947.537000</gml:lowerCorner>
        		<gml:upperCorner>669349.688000 675947.537000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669349.688000 675947.537000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 065 350</ms:GML_ID>
        <ms:NAZWA>223 065 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223065350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686968.185790 676208.711129</gml:lowerCorner>
        		<gml:upperCorner>686968.185790 676208.711129</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686968.185790 676208.711129</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 157 594</ms:GML_ID>
        <ms:NAZWA>038 157 594</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038157594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687350.017129 679122.945973</gml:lowerCorner>
        		<gml:upperCorner>687350.017129 679122.945973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687350.017129 679122.945973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 154 635</ms:GML_ID>
        <ms:NAZWA>038 154 635</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038154635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687400.470033 679410.478358</gml:lowerCorner>
        		<gml:upperCorner>687400.470033 679410.478358</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687400.470033 679410.478358</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 154 342</ms:GML_ID>
        <ms:NAZWA>038 154 342</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038154342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669172.569000 680345.618000</gml:lowerCorner>
        		<gml:upperCorner>669172.569000 680345.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669172.569000 680345.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 069 866</ms:GML_ID>
        <ms:NAZWA>223 069 866</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223069866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688883.362167 681599.520224</gml:lowerCorner>
        		<gml:upperCorner>688883.362167 681599.520224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688883.362167 681599.520224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 151 280</ms:GML_ID>
        <ms:NAZWA>038 151 280</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038151280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688573.398587 682607.894519</gml:lowerCorner>
        		<gml:upperCorner>688573.398587 682607.894519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688573.398587 682607.894519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 150 223</ms:GML_ID>
        <ms:NAZWA>038 150 223</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038150223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688334.819397 683328.625765</gml:lowerCorner>
        		<gml:upperCorner>688334.819397 683328.625765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688334.819397 683328.625765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 149 466</ms:GML_ID>
        <ms:NAZWA>038 149 466</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038149466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687978.030091 684973.552427</gml:lowerCorner>
        		<gml:upperCorner>687978.030091 684973.552427</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687978.030091 684973.552427</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 147 789</ms:GML_ID>
        <ms:NAZWA>038 147 789</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038147789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665880.547000 685064.598000</gml:lowerCorner>
        		<gml:upperCorner>665880.547000 685064.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665880.547000 685064.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 075 909</ms:GML_ID>
        <ms:NAZWA>223 075 909</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223075909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687646.797115 686080.735985</gml:lowerCorner>
        		<gml:upperCorner>687646.797115 686080.735985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687646.797115 686080.735985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 146 604</ms:GML_ID>
        <ms:NAZWA>038 146 604</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038146604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686747.024134 689102.901897</gml:lowerCorner>
        		<gml:upperCorner>686747.024134 689102.901897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686747.024134 689102.901897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 143 348</ms:GML_ID>
        <ms:NAZWA>038 143 348</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038143348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685697.991354 690863.960624</gml:lowerCorner>
        		<gml:upperCorner>685697.991354 690863.960624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685697.991354 690863.960624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 141 259</ms:GML_ID>
        <ms:NAZWA>038 141 259</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038141259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685652.111124 691909.407631</gml:lowerCorner>
        		<gml:upperCorner>685652.111124 691909.407631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685652.111124 691909.407631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 140 212</ms:GML_ID>
        <ms:NAZWA>038 140 212</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038140212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715190.645591 648960.686916</gml:lowerCorner>
        		<gml:upperCorner>715190.645591 648960.686916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715190.645591 648960.686916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 382 708</ms:GML_ID>
        <ms:NAZWA>353 382 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353382708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668963.610000 649261.157000</gml:lowerCorner>
        		<gml:upperCorner>668963.610000 649261.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668963.610000 649261.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 031 837</ms:GML_ID>
        <ms:NAZWA>223 031 837</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223031837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669219.059000 650568.843000</gml:lowerCorner>
        		<gml:upperCorner>669219.059000 650568.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669219.059000 650568.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 033 320</ms:GML_ID>
        <ms:NAZWA>223 033 320</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223033320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668864.285861 650771.510447</gml:lowerCorner>
        		<gml:upperCorner>668864.285861 650771.510447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668864.285861 650771.510447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 033 731</ms:GML_ID>
        <ms:NAZWA>223 033 731</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223033731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691776.746737 651956.494475</gml:lowerCorner>
        		<gml:upperCorner>691776.746737 651956.494475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691776.746737 651956.494475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 184 696</ms:GML_ID>
        <ms:NAZWA>038 184 696</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038184696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665770.851000 655045.750000</gml:lowerCorner>
        		<gml:upperCorner>665770.851000 655045.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665770.851000 655045.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 040 183</ms:GML_ID>
        <ms:NAZWA>223 040 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223040183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692489.729051 655374.138036</gml:lowerCorner>
        		<gml:upperCorner>692489.729051 655374.138036</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692489.729051 655374.138036</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 181 016</ms:GML_ID>
        <ms:NAZWA>038 181 016</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038181016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665727.022000 655605.579000</gml:lowerCorner>
        		<gml:upperCorner>665727.022000 655605.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665727.022000 655605.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 040 745</ms:GML_ID>
        <ms:NAZWA>223 040 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223040745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692582.237000 657872.227000</gml:lowerCorner>
        		<gml:upperCorner>692582.237000 657872.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692582.237000 657872.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.259 001 902</ms:GML_ID>
        <ms:NAZWA>259 001 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>259001902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691046.697904 659626.901364</gml:lowerCorner>
        		<gml:upperCorner>691046.697904 659626.901364</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691046.697904 659626.901364</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 176 222</ms:GML_ID>
        <ms:NAZWA>038 176 222</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038176222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690565.153931 659906.395636</gml:lowerCorner>
        		<gml:upperCorner>690565.153931 659906.395636</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690565.153931 659906.395636</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 175 660</ms:GML_ID>
        <ms:NAZWA>038 175 660</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038175660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689661.010640 660636.632385</gml:lowerCorner>
        		<gml:upperCorner>689661.010640 660636.632385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689661.010640 660636.632385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 174 477</ms:GML_ID>
        <ms:NAZWA>038 174 477</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038174477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688432.761594 661877.440802</gml:lowerCorner>
        		<gml:upperCorner>688432.761594 661877.440802</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688432.761594 661877.440802</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 172 708</ms:GML_ID>
        <ms:NAZWA>038 172 708</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038172708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687767.825180 663007.919311</gml:lowerCorner>
        		<gml:upperCorner>687767.825180 663007.919311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687767.825180 663007.919311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 171 365</ms:GML_ID>
        <ms:NAZWA>038 171 365</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038171365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687670.288586 664654.139077</gml:lowerCorner>
        		<gml:upperCorner>687670.288586 664654.139077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687670.288586 664654.139077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 169 675</ms:GML_ID>
        <ms:NAZWA>038 169 675</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038169675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687491.201450 665112.700928</gml:lowerCorner>
        		<gml:upperCorner>687491.201450 665112.700928</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687491.201450 665112.700928</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 169 182</ms:GML_ID>
        <ms:NAZWA>038 169 182</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038169182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686891.259789 666644.786116</gml:lowerCorner>
        		<gml:upperCorner>686891.259789 666644.786116</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686891.259789 666644.786116</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 167 537</ms:GML_ID>
        <ms:NAZWA>038 167 537</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038167537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667302.738976 673045.534309</gml:lowerCorner>
        		<gml:upperCorner>667302.738976 673045.534309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667302.738976 673045.534309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 061 721</ms:GML_ID>
        <ms:NAZWA>223 061 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223061721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662229.887000 668038.898000</gml:lowerCorner>
        		<gml:upperCorner>662229.887000 668038.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662229.887000 668038.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 054 379</ms:GML_ID>
        <ms:NAZWA>223 054 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223054379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662387.915000 666701.985000</gml:lowerCorner>
        		<gml:upperCorner>662387.915000 666701.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662387.915000 666701.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 053 008</ms:GML_ID>
        <ms:NAZWA>223 053 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223053008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662521.415000 668445.234000</gml:lowerCorner>
        		<gml:upperCorner>662521.415000 668445.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662521.415000 668445.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 054 879</ms:GML_ID>
        <ms:NAZWA>223 054 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223054879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662563.879000 691183.108000</gml:lowerCorner>
        		<gml:upperCorner>662563.879000 691183.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662563.879000 691183.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 083 017</ms:GML_ID>
        <ms:NAZWA>223 083 017</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223083017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662735.945000 692627.907000</gml:lowerCorner>
        		<gml:upperCorner>662735.945000 692627.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662735.945000 692627.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 084 477</ms:GML_ID>
        <ms:NAZWA>223 084 477</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223084477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663117.760000 669258.278000</gml:lowerCorner>
        		<gml:upperCorner>663117.760000 669258.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663117.760000 669258.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 055 888</ms:GML_ID>
        <ms:NAZWA>223 055 888</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223055888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663372.368000 689359.676000</gml:lowerCorner>
        		<gml:upperCorner>663372.368000 689359.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663372.368000 689359.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 081 021</ms:GML_ID>
        <ms:NAZWA>223 081 021</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223081021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663425.403459 693221.921991</gml:lowerCorner>
        		<gml:upperCorner>663425.403459 693221.921991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663425.403459 693221.921991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 085 477</ms:GML_ID>
        <ms:NAZWA>223 085 477</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223085477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663904.138000 663436.006000</gml:lowerCorner>
        		<gml:upperCorner>663904.138000 663436.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663904.138000 663436.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 048 905</ms:GML_ID>
        <ms:NAZWA>223 048 905</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223048905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664049.687000 670550.101000</gml:lowerCorner>
        		<gml:upperCorner>664049.687000 670550.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664049.687000 670550.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 057 508</ms:GML_ID>
        <ms:NAZWA>223 057 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223057508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664129.187000 662714.025000</gml:lowerCorner>
        		<gml:upperCorner>664129.187000 662714.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664129.187000 662714.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 048 148</ms:GML_ID>
        <ms:NAZWA>223 048 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223048148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664161.420000 687644.091000</gml:lowerCorner>
        		<gml:upperCorner>664161.420000 687644.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664161.420000 687644.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 079 052</ms:GML_ID>
        <ms:NAZWA>223 079 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223079052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664195.637000 662229.211000</gml:lowerCorner>
        		<gml:upperCorner>664195.637000 662229.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664195.637000 662229.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 047 660</ms:GML_ID>
        <ms:NAZWA>223 047 660</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223047660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664297.413014 693512.015770</gml:lowerCorner>
        		<gml:upperCorner>664297.413014 693512.015770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664297.413014 693512.015770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 086 395</ms:GML_ID>
        <ms:NAZWA>223 086 395</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223086395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664456.771000 661464.965000</gml:lowerCorner>
        		<gml:upperCorner>664456.771000 661464.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664456.771000 661464.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 046 846</ms:GML_ID>
        <ms:NAZWA>223 046 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223046846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664472.256495 693529.328777</gml:lowerCorner>
        		<gml:upperCorner>664472.256495 693529.328777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664472.256495 693529.328777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 086 572</ms:GML_ID>
        <ms:NAZWA>223 086 572</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223086572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664547.004000 670832.025000</gml:lowerCorner>
        		<gml:upperCorner>664547.004000 670832.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664547.004000 670832.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 058 084</ms:GML_ID>
        <ms:NAZWA>223 058 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223058084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664605.612000 660651.533000</gml:lowerCorner>
        		<gml:upperCorner>664605.612000 660651.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664605.612000 660651.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 046 018</ms:GML_ID>
        <ms:NAZWA>223 046 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223046018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664910.227000 659166.918000</gml:lowerCorner>
        		<gml:upperCorner>664910.227000 659166.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664910.227000 659166.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 044 494</ms:GML_ID>
        <ms:NAZWA>223 044 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223044494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664934.354000 686714.406000</gml:lowerCorner>
        		<gml:upperCorner>664934.354000 686714.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664934.354000 686714.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 077 814</ms:GML_ID>
        <ms:NAZWA>223 077 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223077814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665112.625000 693371.447000</gml:lowerCorner>
        		<gml:upperCorner>665112.625000 693371.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665112.625000 693371.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 087 232</ms:GML_ID>
        <ms:NAZWA>223 087 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223087232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665180.482000 658478.639000</gml:lowerCorner>
        		<gml:upperCorner>665180.482000 658478.639000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665180.482000 658478.639000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 043 754</ms:GML_ID>
        <ms:NAZWA>223 043 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223043754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666246.220000 693690.193000</gml:lowerCorner>
        		<gml:upperCorner>666246.220000 693690.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666246.220000 693690.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 088 446</ms:GML_ID>
        <ms:NAZWA>223 088 446</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223088446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666794.862000 694176.944000</gml:lowerCorner>
        		<gml:upperCorner>666794.862000 694176.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666794.862000 694176.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 089 196</ms:GML_ID>
        <ms:NAZWA>223 089 196</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223089196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660605.711000 718168.551000</gml:lowerCorner>
        		<gml:upperCorner>660605.711000 718168.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660605.711000 718168.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 148 947</ms:GML_ID>
        <ms:NAZWA>219 148 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219148947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661518.321000 718973.399000</gml:lowerCorner>
        		<gml:upperCorner>661518.321000 718973.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661518.321000 718973.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 150 152</ms:GML_ID>
        <ms:NAZWA>219 150 152</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219150152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661843.912662 719441.125414</gml:lowerCorner>
        		<gml:upperCorner>661843.912662 719441.125414</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661843.912662 719441.125414</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 150 735</ms:GML_ID>
        <ms:NAZWA>219 150 735</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219150735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664127.212000 720910.410000</gml:lowerCorner>
        		<gml:upperCorner>664127.212000 720910.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664127.212000 720910.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 153 536</ms:GML_ID>
        <ms:NAZWA>219 153 536</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219153536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665063.636000 721884.179000</gml:lowerCorner>
        		<gml:upperCorner>665063.636000 721884.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665063.636000 721884.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 154 904</ms:GML_ID>
        <ms:NAZWA>219 154 904</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219154904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665841.762000 712337.068000</gml:lowerCorner>
        		<gml:upperCorner>665841.762000 712337.068000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665841.762000 712337.068000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 110 908</ms:GML_ID>
        <ms:NAZWA>223 110 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223110908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666798.081000 715082.224000</gml:lowerCorner>
        		<gml:upperCorner>666798.081000 715082.224000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666798.081000 715082.224000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 113 845</ms:GML_ID>
        <ms:NAZWA>223 113 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223113845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667690.331499 708246.807870</gml:lowerCorner>
        		<gml:upperCorner>667690.331499 708246.807870</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667690.331499 708246.807870</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 106 014</ms:GML_ID>
        <ms:NAZWA>223 106 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223106014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668340.741190 720755.374385</gml:lowerCorner>
        		<gml:upperCorner>668340.741190 720755.374385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668340.741190 720755.374385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 104 174</ms:GML_ID>
        <ms:NAZWA>038 104 174</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038104174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668454.993481 721037.978483</gml:lowerCorner>
        		<gml:upperCorner>668454.993481 721037.978483</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668454.993481 721037.978483</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 001 044</ms:GML_ID>
        <ms:NAZWA>041 001 044</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041001044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668618.460364 719261.968881</gml:lowerCorner>
        		<gml:upperCorner>668618.460364 719261.968881</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668618.460364 719261.968881</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 118 630</ms:GML_ID>
        <ms:NAZWA>223 118 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223118630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668719.236023 718530.956371</gml:lowerCorner>
        		<gml:upperCorner>668719.236023 718530.956371</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668719.236023 718530.956371</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 106 565</ms:GML_ID>
        <ms:NAZWA>038 106 565</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038106565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668781.138417 721451.326059</gml:lowerCorner>
        		<gml:upperCorner>668781.138417 721451.326059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668781.138417 721451.326059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 001 581</ms:GML_ID>
        <ms:NAZWA>041 001 581</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041001581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668829.826897 717750.175720</gml:lowerCorner>
        		<gml:upperCorner>668829.826897 717750.175720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668829.826897 717750.175720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 107 357</ms:GML_ID>
        <ms:NAZWA>038 107 357</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038107357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668903.307169 717272.657293</gml:lowerCorner>
        		<gml:upperCorner>668903.307169 717272.657293</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668903.307169 717272.657293</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 107 840</ms:GML_ID>
        <ms:NAZWA>038 107 840</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038107840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668973.501000 721828.389000</gml:lowerCorner>
        		<gml:upperCorner>668973.501000 721828.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668973.501000 721828.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 001 973</ms:GML_ID>
        <ms:NAZWA>041 001 973</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041001973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669186.407953 716010.128178</gml:lowerCorner>
        		<gml:upperCorner>669186.407953 716010.128178</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669186.407953 716010.128178</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 109 144</ms:GML_ID>
        <ms:NAZWA>038 109 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038109144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669417.693741 722681.385401</gml:lowerCorner>
        		<gml:upperCorner>669417.693741 722681.385401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669417.693741 722681.385401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 002 941</ms:GML_ID>
        <ms:NAZWA>041 002 941</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041002941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669858.661177 715136.033823</gml:lowerCorner>
        		<gml:upperCorner>669858.661177 715136.033823</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669858.661177 715136.033823</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 110 246</ms:GML_ID>
        <ms:NAZWA>038 110 246</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038110246</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673215.254924 712167.134043</gml:lowerCorner>
        		<gml:upperCorner>673215.254924 712167.134043</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673215.254924 712167.134043</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 114 881</ms:GML_ID>
        <ms:NAZWA>038 114 881</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038114881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676471.068377 710074.399753</gml:lowerCorner>
        		<gml:upperCorner>676471.068377 710074.399753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676471.068377 710074.399753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 118 796</ms:GML_ID>
        <ms:NAZWA>038 118 796</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038118796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677798.082263 709067.804002</gml:lowerCorner>
        		<gml:upperCorner>677798.082263 709067.804002</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677798.082263 709067.804002</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 120 786</ms:GML_ID>
        <ms:NAZWA>038 120 786</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038120786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681295.633138 701720.654517</gml:lowerCorner>
        		<gml:upperCorner>681295.633138 701720.654517</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681295.633138 701720.654517</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 129 172</ms:GML_ID>
        <ms:NAZWA>038 129 172</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038129172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682373.476680 699967.768286</gml:lowerCorner>
        		<gml:upperCorner>682373.476680 699967.768286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682373.476680 699967.768286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 131 265</ms:GML_ID>
        <ms:NAZWA>038 131 265</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038131265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683612.511662 698600.943559</gml:lowerCorner>
        		<gml:upperCorner>683612.511662 698600.943559</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683612.511662 698600.943559</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 133 107</ms:GML_ID>
        <ms:NAZWA>038 133 107</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038133107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684120.911836 698025.796804</gml:lowerCorner>
        		<gml:upperCorner>684120.911836 698025.796804</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684120.911836 698025.796804</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 133 878</ms:GML_ID>
        <ms:NAZWA>038 133 878</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038133878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684379.097716 697456.245800</gml:lowerCorner>
        		<gml:upperCorner>684379.097716 697456.245800</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684379.097716 697456.245800</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 134 507</ms:GML_ID>
        <ms:NAZWA>038 134 507</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038134507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684807.024885 695792.800418</gml:lowerCorner>
        		<gml:upperCorner>684807.024885 695792.800418</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684807.024885 695792.800418</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 136 224</ms:GML_ID>
        <ms:NAZWA>038 136 224</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038136224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685288.236477 693918.652573</gml:lowerCorner>
        		<gml:upperCorner>685288.236477 693918.652573</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685288.236477 693918.652573</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 138 159</ms:GML_ID>
        <ms:NAZWA>038 138 159</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038138159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721370.188486 717110.374955</gml:lowerCorner>
        		<gml:upperCorner>721370.188486 717110.374955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721370.188486 717110.374955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 063 229</ms:GML_ID>
        <ms:NAZWA>041 063 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041063229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721529.789130 716418.647649</gml:lowerCorner>
        		<gml:upperCorner>721529.789130 716418.647649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721529.789130 716418.647649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 063 942</ms:GML_ID>
        <ms:NAZWA>041 063 942</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041063942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721658.532533 715757.608857</gml:lowerCorner>
        		<gml:upperCorner>721658.532533 715757.608857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721658.532533 715757.608857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 064 612</ms:GML_ID>
        <ms:NAZWA>041 064 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041064612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721710.593664 715422.561801</gml:lowerCorner>
        		<gml:upperCorner>721710.593664 715422.561801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721710.593664 715422.561801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 064 950</ms:GML_ID>
        <ms:NAZWA>041 064 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041064950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721860.373867 714519.834003</gml:lowerCorner>
        		<gml:upperCorner>721860.373867 714519.834003</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721860.373867 714519.834003</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 065 867</ms:GML_ID>
        <ms:NAZWA>041 065 867</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041065867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656897.380000 780131.230000</gml:lowerCorner>
        		<gml:upperCorner>656897.380000 780131.230000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656897.380000 780131.230000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 043 730</ms:GML_ID>
        <ms:NAZWA>040 043 730</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040043730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657051.170000 779648.251000</gml:lowerCorner>
        		<gml:upperCorner>657051.170000 779648.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657051.170000 779648.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 044 254</ms:GML_ID>
        <ms:NAZWA>040 044 254</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040044254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658782.193000 779886.191000</gml:lowerCorner>
        		<gml:upperCorner>658782.193000 779886.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658782.193000 779886.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 046 137</ms:GML_ID>
        <ms:NAZWA>040 046 137</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040046137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659373.730000 779756.887000</gml:lowerCorner>
        		<gml:upperCorner>659373.730000 779756.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659373.730000 779756.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 046 756</ms:GML_ID>
        <ms:NAZWA>040 046 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040046756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660193.673000 779224.351000</gml:lowerCorner>
        		<gml:upperCorner>660193.673000 779224.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660193.673000 779224.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 047 733</ms:GML_ID>
        <ms:NAZWA>040 047 733</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040047733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660681.506000 778606.640000</gml:lowerCorner>
        		<gml:upperCorner>660681.506000 778606.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660681.506000 778606.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 048 539</ms:GML_ID>
        <ms:NAZWA>040 048 539</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040048539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660953.784000 777841.840000</gml:lowerCorner>
        		<gml:upperCorner>660953.784000 777841.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660953.784000 777841.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 049 350</ms:GML_ID>
        <ms:NAZWA>040 049 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040049350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661071.018000 777512.398000</gml:lowerCorner>
        		<gml:upperCorner>661071.018000 777512.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661071.018000 777512.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 049 706</ms:GML_ID>
        <ms:NAZWA>040 049 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040049706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661313.513000 777036.449000</gml:lowerCorner>
        		<gml:upperCorner>661313.513000 777036.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661313.513000 777036.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 050 238</ms:GML_ID>
        <ms:NAZWA>040 050 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040050238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662917.975420 775737.122770</gml:lowerCorner>
        		<gml:upperCorner>662917.975420 775737.122770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662917.975420 775737.122770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 052 313</ms:GML_ID>
        <ms:NAZWA>040 052 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040052313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663779.854000 774401.489000</gml:lowerCorner>
        		<gml:upperCorner>663779.854000 774401.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663779.854000 774401.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 053 904</ms:GML_ID>
        <ms:NAZWA>040 053 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040053904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664043.230000 773978.641000</gml:lowerCorner>
        		<gml:upperCorner>664043.230000 773978.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664043.230000 773978.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 054 404</ms:GML_ID>
        <ms:NAZWA>040 054 404</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040054404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664445.634000 773427.570000</gml:lowerCorner>
        		<gml:upperCorner>664445.634000 773427.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664445.634000 773427.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 055 087</ms:GML_ID>
        <ms:NAZWA>040 055 087</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040055087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670956.097000 768513.772000</gml:lowerCorner>
        		<gml:upperCorner>670956.097000 768513.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670956.097000 768513.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 063 297</ms:GML_ID>
        <ms:NAZWA>040 063 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040063297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672278.056000 765784.203000</gml:lowerCorner>
        		<gml:upperCorner>672278.056000 765784.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672278.056000 765784.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 066 350</ms:GML_ID>
        <ms:NAZWA>040 066 350</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040066350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673353.009000 763768.771000</gml:lowerCorner>
        		<gml:upperCorner>673353.009000 763768.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673353.009000 763768.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 068 639</ms:GML_ID>
        <ms:NAZWA>040 068 639</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040068639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673609.710202 763408.552697</gml:lowerCorner>
        		<gml:upperCorner>673609.710202 763408.552697</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673609.710202 763408.552697</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 069 090</ms:GML_ID>
        <ms:NAZWA>040 069 090</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040069090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673788.850000 763234.297000</gml:lowerCorner>
        		<gml:upperCorner>673788.850000 763234.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673788.850000 763234.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 069 332</ms:GML_ID>
        <ms:NAZWA>040 069 332</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040069332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678250.626000 763459.213000</gml:lowerCorner>
        		<gml:upperCorner>678250.626000 763459.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678250.626000 763459.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 074 242</ms:GML_ID>
        <ms:NAZWA>040 074 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040074242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678638.835635 763578.818017</gml:lowerCorner>
        		<gml:upperCorner>678638.835635 763578.818017</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678638.835635 763578.818017</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 074 652</ms:GML_ID>
        <ms:NAZWA>040 074 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040074652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680349.548000 763946.445000</gml:lowerCorner>
        		<gml:upperCorner>680349.548000 763946.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680349.548000 763946.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 076 423</ms:GML_ID>
        <ms:NAZWA>040 076 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040076423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644538.896000 791502.258000</gml:lowerCorner>
        		<gml:upperCorner>644538.896000 791502.258000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644538.896000 791502.258000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 024 660</ms:GML_ID>
        <ms:NAZWA>040 024 660</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040024660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645621.065000 790937.000000</gml:lowerCorner>
        		<gml:upperCorner>645621.065000 790937.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645621.065000 790937.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 025 882</ms:GML_ID>
        <ms:NAZWA>040 025 882</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040025882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646094.770000 790690.335000</gml:lowerCorner>
        		<gml:upperCorner>646094.770000 790690.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646094.770000 790690.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 026 414</ms:GML_ID>
        <ms:NAZWA>040 026 414</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040026414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646923.268000 790382.474000</gml:lowerCorner>
        		<gml:upperCorner>646923.268000 790382.474000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646923.268000 790382.474000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 027 307</ms:GML_ID>
        <ms:NAZWA>040 027 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040027307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647760.906000 790491.052000</gml:lowerCorner>
        		<gml:upperCorner>647760.906000 790491.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647760.906000 790491.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 028 156</ms:GML_ID>
        <ms:NAZWA>040 028 156</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040028156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648851.365000 790290.847000</gml:lowerCorner>
        		<gml:upperCorner>648851.365000 790290.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648851.365000 790290.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 029 305</ms:GML_ID>
        <ms:NAZWA>040 029 305</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040029305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649413.433000 789944.547000</gml:lowerCorner>
        		<gml:upperCorner>649413.433000 789944.547000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649413.433000 789944.547000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 029 957</ms:GML_ID>
        <ms:NAZWA>040 029 957</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040029957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649695.624000 789567.236000</gml:lowerCorner>
        		<gml:upperCorner>649695.624000 789567.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649695.624000 789567.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 030 435</ms:GML_ID>
        <ms:NAZWA>040 030 435</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040030435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652496.596000 788014.795000</gml:lowerCorner>
        		<gml:upperCorner>652496.596000 788014.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652496.596000 788014.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 033 758</ms:GML_ID>
        <ms:NAZWA>040 033 758</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040033758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653647.486000 786954.874000</gml:lowerCorner>
        		<gml:upperCorner>653647.486000 786954.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653647.486000 786954.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 035 349</ms:GML_ID>
        <ms:NAZWA>040 035 349</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040035349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654052.500000 786463.690000</gml:lowerCorner>
        		<gml:upperCorner>654052.500000 786463.690000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654052.500000 786463.690000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 035 990</ms:GML_ID>
        <ms:NAZWA>040 035 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040035990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654439.386000 786131.180000</gml:lowerCorner>
        		<gml:upperCorner>654439.386000 786131.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654439.386000 786131.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 036 505</ms:GML_ID>
        <ms:NAZWA>040 036 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040036505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654847.047000 785833.256000</gml:lowerCorner>
        		<gml:upperCorner>654847.047000 785833.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654847.047000 785833.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 037 005</ms:GML_ID>
        <ms:NAZWA>040 037 005</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040037005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655181.541000 783094.463000</gml:lowerCorner>
        		<gml:upperCorner>655181.541000 783094.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655181.541000 783094.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 039 906</ms:GML_ID>
        <ms:NAZWA>040 039 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040039906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655266.371000 783672.493000</gml:lowerCorner>
        		<gml:upperCorner>655266.371000 783672.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655266.371000 783672.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 039 312</ms:GML_ID>
        <ms:NAZWA>040 039 312</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040039312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655322.066000 781731.294000</gml:lowerCorner>
        		<gml:upperCorner>655322.066000 781731.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655322.066000 781731.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 041 314</ms:GML_ID>
        <ms:NAZWA>040 041 314</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040041314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655375.436000 784485.311000</gml:lowerCorner>
        		<gml:upperCorner>655375.436000 784485.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655375.436000 784485.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 038 465</ms:GML_ID>
        <ms:NAZWA>040 038 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040038465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655389.590000 784003.125000</gml:lowerCorner>
        		<gml:upperCorner>655389.590000 784003.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655389.590000 784003.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 038 958</ms:GML_ID>
        <ms:NAZWA>040 038 958</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040038958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656601.850000 780913.619000</gml:lowerCorner>
        		<gml:upperCorner>656601.850000 780913.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656601.850000 780913.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 042 841</ms:GML_ID>
        <ms:NAZWA>040 042 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040042841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656854.146000 780621.021000</gml:lowerCorner>
        		<gml:upperCorner>656854.146000 780621.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656854.146000 780621.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 043 234</ms:GML_ID>
        <ms:NAZWA>040 043 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040043234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644387.261000 731376.008000</gml:lowerCorner>
        		<gml:upperCorner>644387.261000 731376.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644387.261000 731376.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 077 112</ms:GML_ID>
        <ms:NAZWA>038 077 112</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038077112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645768.409187 730243.555891</gml:lowerCorner>
        		<gml:upperCorner>645768.409187 730243.555891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645768.409187 730243.555891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 078 952</ms:GML_ID>
        <ms:NAZWA>038 078 952</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038078952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646197.417000 729924.735000</gml:lowerCorner>
        		<gml:upperCorner>646197.417000 729924.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646197.417000 729924.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 079 496</ms:GML_ID>
        <ms:NAZWA>038 079 496</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038079496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647367.121315 728572.097056</gml:lowerCorner>
        		<gml:upperCorner>647367.121315 728572.097056</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647367.121315 728572.097056</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 081 281</ms:GML_ID>
        <ms:NAZWA>038 081 281</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038081281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647876.516350 728101.802468</gml:lowerCorner>
        		<gml:upperCorner>647876.516350 728101.802468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647876.516350 728101.802468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 081 978</ms:GML_ID>
        <ms:NAZWA>038 081 978</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038081978</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648100.921778 727924.896192</gml:lowerCorner>
        		<gml:upperCorner>648100.921778 727924.896192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648100.921778 727924.896192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 082 272</ms:GML_ID>
        <ms:NAZWA>038 082 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038082272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649412.979000 727184.784000</gml:lowerCorner>
        		<gml:upperCorner>649412.979000 727184.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649412.979000 727184.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 083 731</ms:GML_ID>
        <ms:NAZWA>038 083 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038083731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650169.842879 727298.060800</gml:lowerCorner>
        		<gml:upperCorner>650169.842879 727298.060800</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650169.842879 727298.060800</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 084 529</ms:GML_ID>
        <ms:NAZWA>038 084 529</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038084529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651787.443000 727181.811000</gml:lowerCorner>
        		<gml:upperCorner>651787.443000 727181.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651787.443000 727181.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 086 234</ms:GML_ID>
        <ms:NAZWA>038 086 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038086234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652524.356104 726862.284907</gml:lowerCorner>
        		<gml:upperCorner>652524.356104 726862.284907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652524.356104 726862.284907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 087 038</ms:GML_ID>
        <ms:NAZWA>038 087 038</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038087038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653956.598000 726160.872000</gml:lowerCorner>
        		<gml:upperCorner>653956.598000 726160.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653956.598000 726160.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 088 633</ms:GML_ID>
        <ms:NAZWA>038 088 633</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038088633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654648.688251 725817.935108</gml:lowerCorner>
        		<gml:upperCorner>654648.688251 725817.935108</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654648.688251 725817.935108</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 089 405</ms:GML_ID>
        <ms:NAZWA>038 089 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038089405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657138.500104 724353.255955</gml:lowerCorner>
        		<gml:upperCorner>657138.500104 724353.255955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657138.500104 724353.255955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 092 297</ms:GML_ID>
        <ms:NAZWA>038 092 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038092297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657853.768000 723976.137000</gml:lowerCorner>
        		<gml:upperCorner>657853.768000 723976.137000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657853.768000 723976.137000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 093 109</ms:GML_ID>
        <ms:NAZWA>038 093 109</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038093109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669860.558000 723279.026000</gml:lowerCorner>
        		<gml:upperCorner>669860.558000 723279.026000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669860.558000 723279.026000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 003 692</ms:GML_ID>
        <ms:NAZWA>041 003 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041003692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672187.310920 725341.052543</gml:lowerCorner>
        		<gml:upperCorner>672187.310920 725341.052543</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672187.310920 725341.052543</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 006 800</ms:GML_ID>
        <ms:NAZWA>041 006 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041006800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674670.232000 762500.836000</gml:lowerCorner>
        		<gml:upperCorner>674670.232000 762500.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674670.232000 762500.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 070 491</ms:GML_ID>
        <ms:NAZWA>040 070 491</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040070491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674777.600000 727152.274000</gml:lowerCorner>
        		<gml:upperCorner>674777.600000 727152.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674777.600000 727152.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 009 973</ms:GML_ID>
        <ms:NAZWA>041 009 973</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041009973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676244.203000 727834.176000</gml:lowerCorner>
        		<gml:upperCorner>676244.203000 727834.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676244.203000 727834.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.041 011 596</ms:GML_ID>
        <ms:NAZWA>041 011 596</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>041011596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643662.072000 698458.359000</gml:lowerCorner>
        		<gml:upperCorner>643662.072000 698458.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643662.072000 698458.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 116 352</ms:GML_ID>
        <ms:NAZWA>219 116 352</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219116352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643702.935000 698682.242000</gml:lowerCorner>
        		<gml:upperCorner>643702.935000 698682.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643702.935000 698682.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 116 580</ms:GML_ID>
        <ms:NAZWA>219 116 580</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219116580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643740.896158 703981.637439</gml:lowerCorner>
        		<gml:upperCorner>643740.896158 703981.637439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643740.896158 703981.637439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 122 321</ms:GML_ID>
        <ms:NAZWA>219 122 321</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219122321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644328.748482 704461.049779</gml:lowerCorner>
        		<gml:upperCorner>644328.748482 704461.049779</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644328.748482 704461.049779</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 123 079</ms:GML_ID>
        <ms:NAZWA>219 123 079</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219123079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645700.806878 705174.610748</gml:lowerCorner>
        		<gml:upperCorner>645700.806878 705174.610748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645700.806878 705174.610748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 124 626</ms:GML_ID>
        <ms:NAZWA>219 124 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219124626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648087.967385 704607.394912</gml:lowerCorner>
        		<gml:upperCorner>648087.967385 704607.394912</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648087.967385 704607.394912</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 127 417</ms:GML_ID>
        <ms:NAZWA>219 127 417</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219127417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649330.091059 704582.986842</gml:lowerCorner>
        		<gml:upperCorner>649330.091059 704582.986842</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649330.091059 704582.986842</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 128 673</ms:GML_ID>
        <ms:NAZWA>219 128 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219128673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650314.743430 704762.171189</gml:lowerCorner>
        		<gml:upperCorner>650314.743430 704762.171189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650314.743430 704762.171189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 129 692</ms:GML_ID>
        <ms:NAZWA>219 129 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219129692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651067.670000 705316.412000</gml:lowerCorner>
        		<gml:upperCorner>651067.670000 705316.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651067.670000 705316.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 130 631</ms:GML_ID>
        <ms:NAZWA>219 130 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219130631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651880.384000 705669.306000</gml:lowerCorner>
        		<gml:upperCorner>651880.384000 705669.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651880.384000 705669.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 131 519</ms:GML_ID>
        <ms:NAZWA>219 131 519</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219131519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652231.741000 705822.306000</gml:lowerCorner>
        		<gml:upperCorner>652231.741000 705822.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652231.741000 705822.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 131 902</ms:GML_ID>
        <ms:NAZWA>219 131 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219131902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652980.143000 706849.637000</gml:lowerCorner>
        		<gml:upperCorner>652980.143000 706849.637000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652980.143000 706849.637000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 133 244</ms:GML_ID>
        <ms:NAZWA>219 133 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219133244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654033.648000 708302.328000</gml:lowerCorner>
        		<gml:upperCorner>654033.648000 708302.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654033.648000 708302.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 135 072</ms:GML_ID>
        <ms:NAZWA>219 135 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219135072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656478.120000 709955.657000</gml:lowerCorner>
        		<gml:upperCorner>656478.120000 709955.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656478.120000 709955.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 138 252</ms:GML_ID>
        <ms:NAZWA>219 138 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219138252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657145.759177 714611.466049</gml:lowerCorner>
        		<gml:upperCorner>657145.759177 714611.466049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657145.759177 714611.466049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 143 438</ms:GML_ID>
        <ms:NAZWA>219 143 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219143438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657259.075000 713961.244000</gml:lowerCorner>
        		<gml:upperCorner>657259.075000 713961.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657259.075000 713961.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 142 777</ms:GML_ID>
        <ms:NAZWA>219 142 777</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219142777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657451.707000 713310.302000</gml:lowerCorner>
        		<gml:upperCorner>657451.707000 713310.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657451.707000 713310.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 142 100</ms:GML_ID>
        <ms:NAZWA>219 142 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219142100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658401.773000 716707.007000</gml:lowerCorner>
        		<gml:upperCorner>658401.773000 716707.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658401.773000 716707.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 145 953</ms:GML_ID>
        <ms:NAZWA>219 145 953</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219145953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625138.113490 800549.111704</gml:lowerCorner>
        		<gml:upperCorner>625138.113490 800549.111704</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625138.113490 800549.111704</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 219 580</ms:GML_ID>
        <ms:NAZWA>006 219 580</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006219580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625821.678000 801097.069000</gml:lowerCorner>
        		<gml:upperCorner>625821.678000 801097.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625821.678000 801097.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 002 022</ms:GML_ID>
        <ms:NAZWA>040 002 022</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040002022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626044.109714 801901.988807</gml:lowerCorner>
        		<gml:upperCorner>626044.109714 801901.988807</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626044.109714 801901.988807</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 221 275</ms:GML_ID>
        <ms:NAZWA>006 221 275</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006221275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626176.538252 802401.412422</gml:lowerCorner>
        		<gml:upperCorner>626176.538252 802401.412422</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626176.538252 802401.412422</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 221 722</ms:GML_ID>
        <ms:NAZWA>006 221 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006221722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626687.661042 802553.029841</gml:lowerCorner>
        		<gml:upperCorner>626687.661042 802553.029841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626687.661042 802553.029841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.923 001 493</ms:GML_ID>
        <ms:NAZWA>923 001 493</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>923001493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627615.629000 803714.644000</gml:lowerCorner>
        		<gml:upperCorner>627615.629000 803714.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627615.629000 803714.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 223 679</ms:GML_ID>
        <ms:NAZWA>006 223 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006223679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627621.627000 799860.581000</gml:lowerCorner>
        		<gml:upperCorner>627621.627000 799860.581000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627621.627000 799860.581000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 004 250</ms:GML_ID>
        <ms:NAZWA>040 004 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040004250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628807.338000 799540.094000</gml:lowerCorner>
        		<gml:upperCorner>628807.338000 799540.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628807.338000 799540.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 005 562</ms:GML_ID>
        <ms:NAZWA>040 005 562</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040005562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629303.199000 804828.442000</gml:lowerCorner>
        		<gml:upperCorner>629303.199000 804828.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629303.199000 804828.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 225 703</ms:GML_ID>
        <ms:NAZWA>006 225 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006225703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630286.452000 799251.011000</gml:lowerCorner>
        		<gml:upperCorner>630286.452000 799251.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630286.452000 799251.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 007 118</ms:GML_ID>
        <ms:NAZWA>040 007 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040007118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630955.957000 798948.088000</gml:lowerCorner>
        		<gml:upperCorner>630955.957000 798948.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630955.957000 798948.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 007 854</ms:GML_ID>
        <ms:NAZWA>040 007 854</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040007854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631234.557000 798822.219000</gml:lowerCorner>
        		<gml:upperCorner>631234.557000 798822.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631234.557000 798822.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 008 159</ms:GML_ID>
        <ms:NAZWA>040 008 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040008159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631624.235000 798670.274000</gml:lowerCorner>
        		<gml:upperCorner>631624.235000 798670.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631624.235000 798670.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 008 576</ms:GML_ID>
        <ms:NAZWA>040 008 576</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040008576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632531.230000 798347.006000</gml:lowerCorner>
        		<gml:upperCorner>632531.230000 798347.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632531.230000 798347.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 009 540</ms:GML_ID>
        <ms:NAZWA>040 009 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040009540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632939.095301 807212.915137</gml:lowerCorner>
        		<gml:upperCorner>632939.095301 807212.915137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632939.095301 807212.915137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 230 071</ms:GML_ID>
        <ms:NAZWA>006 230 071</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006230071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633420.932000 798016.701000</gml:lowerCorner>
        		<gml:upperCorner>633420.932000 798016.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633420.932000 798016.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 010 489</ms:GML_ID>
        <ms:NAZWA>040 010 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040010489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633623.651960 807350.108234</gml:lowerCorner>
        		<gml:upperCorner>633623.651960 807350.108234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633623.651960 807350.108234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 230 760</ms:GML_ID>
        <ms:NAZWA>006 230 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006230760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633980.834000 797795.824000</gml:lowerCorner>
        		<gml:upperCorner>633980.834000 797795.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633980.834000 797795.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 011 090</ms:GML_ID>
        <ms:NAZWA>040 011 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040011090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634498.120000 797591.679000</gml:lowerCorner>
        		<gml:upperCorner>634498.120000 797591.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634498.120000 797591.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 011 646</ms:GML_ID>
        <ms:NAZWA>040 011 646</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040011646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634911.534000 797428.342000</gml:lowerCorner>
        		<gml:upperCorner>634911.534000 797428.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634911.534000 797428.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 012 090</ms:GML_ID>
        <ms:NAZWA>040 012 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040012090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635051.591000 807652.930000</gml:lowerCorner>
        		<gml:upperCorner>635051.591000 807652.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635051.591000 807652.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 232 238</ms:GML_ID>
        <ms:NAZWA>006 232 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006232238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635305.329000 797301.149000</gml:lowerCorner>
        		<gml:upperCorner>635305.329000 797301.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635305.329000 797301.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 012 507</ms:GML_ID>
        <ms:NAZWA>040 012 507</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040012507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635617.242000 797354.477000</gml:lowerCorner>
        		<gml:upperCorner>635617.242000 797354.477000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635617.242000 797354.477000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 012 826</ms:GML_ID>
        <ms:NAZWA>040 012 826</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040012826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636028.458490 807778.610254</gml:lowerCorner>
        		<gml:upperCorner>636028.458490 807778.610254</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636028.458490 807778.610254</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 233 242</ms:GML_ID>
        <ms:NAZWA>006 233 242</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006233242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636569.158000 797707.745000</gml:lowerCorner>
        		<gml:upperCorner>636569.158000 797707.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636569.158000 797707.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 013 841</ms:GML_ID>
        <ms:NAZWA>040 013 841</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040013841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637725.923067 807718.976794</gml:lowerCorner>
        		<gml:upperCorner>637725.923067 807718.976794</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637725.923067 807718.976794</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 234 999</ms:GML_ID>
        <ms:NAZWA>006 234 999</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006234999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637970.403000 797187.034000</gml:lowerCorner>
        		<gml:upperCorner>637970.403000 797187.034000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637970.403000 797187.034000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 015 479</ms:GML_ID>
        <ms:NAZWA>040 015 479</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040015479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638402.686000 796887.142000</gml:lowerCorner>
        		<gml:upperCorner>638402.686000 796887.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638402.686000 796887.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 016 004</ms:GML_ID>
        <ms:NAZWA>040 016 004</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040016004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638948.623946 807950.603560</gml:lowerCorner>
        		<gml:upperCorner>638948.623946 807950.603560</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638948.623946 807950.603560</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 236 283</ms:GML_ID>
        <ms:NAZWA>006 236 283</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006236283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639111.183000 796396.330000</gml:lowerCorner>
        		<gml:upperCorner>639111.183000 796396.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639111.183000 796396.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 016 860</ms:GML_ID>
        <ms:NAZWA>040 016 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040016860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639521.582000 796112.248000</gml:lowerCorner>
        		<gml:upperCorner>639521.582000 796112.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639521.582000 796112.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 017 365</ms:GML_ID>
        <ms:NAZWA>040 017 365</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040017365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640358.773575 807732.248400</gml:lowerCorner>
        		<gml:upperCorner>640358.773575 807732.248400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640358.773575 807732.248400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 237 754</ms:GML_ID>
        <ms:NAZWA>006 237 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006237754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641481.565000 793017.339000</gml:lowerCorner>
        		<gml:upperCorner>641481.565000 793017.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641481.565000 793017.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 021 245</ms:GML_ID>
        <ms:NAZWA>040 021 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040021245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642195.199000 792617.200000</gml:lowerCorner>
        		<gml:upperCorner>642195.199000 792617.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642195.199000 792617.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.040 022 063</ms:GML_ID>
        <ms:NAZWA>040 022 063</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>040022063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624114.196000 751149.018000</gml:lowerCorner>
        		<gml:upperCorner>624114.196000 751149.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624114.196000 751149.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 046 292</ms:GML_ID>
        <ms:NAZWA>038 046 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038046292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626611.423000 749001.314000</gml:lowerCorner>
        		<gml:upperCorner>626611.423000 749001.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626611.423000 749001.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 049 724</ms:GML_ID>
        <ms:NAZWA>038 049 724</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038049724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628036.793000 746544.588000</gml:lowerCorner>
        		<gml:upperCorner>628036.793000 746544.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628036.793000 746544.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 053 063</ms:GML_ID>
        <ms:NAZWA>038 053 063</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038053063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628079.714000 747941.941000</gml:lowerCorner>
        		<gml:upperCorner>628079.714000 747941.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628079.714000 747941.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 051 670</ms:GML_ID>
        <ms:NAZWA>038 051 670</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038051670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628259.667000 744749.073000</gml:lowerCorner>
        		<gml:upperCorner>628259.667000 744749.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628259.667000 744749.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 054 879</ms:GML_ID>
        <ms:NAZWA>038 054 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038054879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628653.812000 743364.179000</gml:lowerCorner>
        		<gml:upperCorner>628653.812000 743364.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628653.812000 743364.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 056 328</ms:GML_ID>
        <ms:NAZWA>038 056 328</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038056328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629929.928000 741934.110000</gml:lowerCorner>
        		<gml:upperCorner>629929.928000 741934.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629929.928000 741934.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 058 265</ms:GML_ID>
        <ms:NAZWA>038 058 265</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038058265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630730.510000 740495.927000</gml:lowerCorner>
        		<gml:upperCorner>630730.510000 740495.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630730.510000 740495.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 059 894</ms:GML_ID>
        <ms:NAZWA>038 059 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038059894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631211.716000 739588.790000</gml:lowerCorner>
        		<gml:upperCorner>631211.716000 739588.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631211.716000 739588.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 060 921</ms:GML_ID>
        <ms:NAZWA>038 060 921</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038060921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632908.307000 736577.124000</gml:lowerCorner>
        		<gml:upperCorner>632908.307000 736577.124000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632908.307000 736577.124000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 064 389</ms:GML_ID>
        <ms:NAZWA>038 064 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038064389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634986.166000 735355.565000</gml:lowerCorner>
        		<gml:upperCorner>634986.166000 735355.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634986.166000 735355.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 066 801</ms:GML_ID>
        <ms:NAZWA>038 066 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038066801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635329.080000 735155.647000</gml:lowerCorner>
        		<gml:upperCorner>635329.080000 735155.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635329.080000 735155.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 067 198</ms:GML_ID>
        <ms:NAZWA>038 067 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038067198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636626.996000 734601.434000</gml:lowerCorner>
        		<gml:upperCorner>636626.996000 734601.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636626.996000 734601.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 068 614</ms:GML_ID>
        <ms:NAZWA>038 068 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038068614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637402.587000 734350.946000</gml:lowerCorner>
        		<gml:upperCorner>637402.587000 734350.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637402.587000 734350.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 069 429</ms:GML_ID>
        <ms:NAZWA>038 069 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038069429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638290.217677 734058.014090</gml:lowerCorner>
        		<gml:upperCorner>638290.217677 734058.014090</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638290.217677 734058.014090</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 070 366</ms:GML_ID>
        <ms:NAZWA>038 070 366</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038070366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639213.419998 733765.933291</gml:lowerCorner>
        		<gml:upperCorner>639213.419998 733765.933291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639213.419998 733765.933291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 071 335</ms:GML_ID>
        <ms:NAZWA>038 071 335</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038071335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642022.059000 732858.295000</gml:lowerCorner>
        		<gml:upperCorner>642022.059000 732858.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642022.059000 732858.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 074 282</ms:GML_ID>
        <ms:NAZWA>038 074 282</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038074282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642447.697227 732719.951535</gml:lowerCorner>
        		<gml:upperCorner>642447.697227 732719.951535</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642447.697227 732719.951535</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 074 731</ms:GML_ID>
        <ms:NAZWA>038 074 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038074731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642782.100000 732537.800000</gml:lowerCorner>
        		<gml:upperCorner>642782.100000 732537.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642782.100000 732537.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 075 114</ms:GML_ID>
        <ms:NAZWA>038 075 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038075114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642811.598000 695298.339000</gml:lowerCorner>
        		<gml:upperCorner>642811.598000 695298.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642811.598000 695298.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 112 970</ms:GML_ID>
        <ms:NAZWA>219 112 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219112970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643269.034087 702626.523877</gml:lowerCorner>
        		<gml:upperCorner>643269.034087 702626.523877</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643269.034087 702626.523877</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 120 738</ms:GML_ID>
        <ms:NAZWA>219 120 738</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219120738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643292.403000 700756.204000</gml:lowerCorner>
        		<gml:upperCorner>643292.403000 700756.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643292.403000 700756.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 118 851</ms:GML_ID>
        <ms:NAZWA>219 118 851</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219118851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643298.630000 702298.520000</gml:lowerCorner>
        		<gml:upperCorner>643298.630000 702298.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643298.630000 702298.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 120 408</ms:GML_ID>
        <ms:NAZWA>219 120 408</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219120408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643443.104000 696701.064000</gml:lowerCorner>
        		<gml:upperCorner>643443.104000 696701.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643443.104000 696701.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 114 562</ms:GML_ID>
        <ms:NAZWA>219 114 562</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219114562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622219.480000 752138.684000</gml:lowerCorner>
        		<gml:upperCorner>622219.480000 752138.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622219.480000 752138.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 044 143</ms:GML_ID>
        <ms:NAZWA>038 044 143</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038044143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621319.845871 752718.147685</gml:lowerCorner>
        		<gml:upperCorner>621319.845871 752718.147685</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621319.845871 752718.147685</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 043 074</ms:GML_ID>
        <ms:NAZWA>038 043 074</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038043074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620526.365997 753097.881307</gml:lowerCorner>
        		<gml:upperCorner>620526.365997 753097.881307</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620526.365997 753097.881307</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 042 192</ms:GML_ID>
        <ms:NAZWA>038 042 192</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038042192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620004.885502 753320.468547</gml:lowerCorner>
        		<gml:upperCorner>620004.885502 753320.468547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620004.885502 753320.468547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 041 626</ms:GML_ID>
        <ms:NAZWA>038 041 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038041626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619393.373000 753587.771000</gml:lowerCorner>
        		<gml:upperCorner>619393.373000 753587.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619393.373000 753587.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 040 961</ms:GML_ID>
        <ms:NAZWA>038 040 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038040961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618025.461000 754152.070000</gml:lowerCorner>
        		<gml:upperCorner>618025.461000 754152.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618025.461000 754152.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 039 468</ms:GML_ID>
        <ms:NAZWA>038 039 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038039468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617195.128000 754373.795000</gml:lowerCorner>
        		<gml:upperCorner>617195.128000 754373.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617195.128000 754373.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 038 600</ms:GML_ID>
        <ms:NAZWA>038 038 600</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038038600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616279.523000 755658.851000</gml:lowerCorner>
        		<gml:upperCorner>616279.523000 755658.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616279.523000 755658.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 036 920</ms:GML_ID>
        <ms:NAZWA>038 036 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038036920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615646.302000 756097.539000</gml:lowerCorner>
        		<gml:upperCorner>615646.302000 756097.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615646.302000 756097.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 036 123</ms:GML_ID>
        <ms:NAZWA>038 036 123</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038036123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614354.389000 756100.496000</gml:lowerCorner>
        		<gml:upperCorner>614354.389000 756100.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614354.389000 756100.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 034 831</ms:GML_ID>
        <ms:NAZWA>038 034 831</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038034831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613388.362000 756256.581000</gml:lowerCorner>
        		<gml:upperCorner>613388.362000 756256.581000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613388.362000 756256.581000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 033 841</ms:GML_ID>
        <ms:NAZWA>038 033 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038033841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612095.292000 756912.778000</gml:lowerCorner>
        		<gml:upperCorner>612095.292000 756912.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612095.292000 756912.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 032 380</ms:GML_ID>
        <ms:NAZWA>038 032 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038032380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611337.363000 757345.066000</gml:lowerCorner>
        		<gml:upperCorner>611337.363000 757345.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611337.363000 757345.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 031 510</ms:GML_ID>
        <ms:NAZWA>038 031 510</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038031510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610025.153000 758830.707000</gml:lowerCorner>
        		<gml:upperCorner>610025.153000 758830.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610025.153000 758830.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 029 522</ms:GML_ID>
        <ms:NAZWA>038 029 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038029522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609406.161812 759457.644729</gml:lowerCorner>
        		<gml:upperCorner>609406.161812 759457.644729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609406.161812 759457.644729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 028 640</ms:GML_ID>
        <ms:NAZWA>038 028 640</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038028640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608176.304000 760506.038000</gml:lowerCorner>
        		<gml:upperCorner>608176.304000 760506.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608176.304000 760506.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 027 022</ms:GML_ID>
        <ms:NAZWA>038 027 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038027022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607579.942000 760928.434000</gml:lowerCorner>
        		<gml:upperCorner>607579.942000 760928.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607579.942000 760928.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 026 290</ms:GML_ID>
        <ms:NAZWA>038 026 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038026290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605569.323000 761759.381000</gml:lowerCorner>
        		<gml:upperCorner>605569.323000 761759.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605569.323000 761759.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 023 994</ms:GML_ID>
        <ms:NAZWA>038 023 994</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038023994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606385.566000 761771.225000</gml:lowerCorner>
        		<gml:upperCorner>606385.566000 761771.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606385.566000 761771.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 024 828</ms:GML_ID>
        <ms:NAZWA>038 024 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038024828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604314.644000 761781.226000</gml:lowerCorner>
        		<gml:upperCorner>604314.644000 761781.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604314.644000 761781.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 022 712</ms:GML_ID>
        <ms:NAZWA>038 022 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038022712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602537.825000 762685.320000</gml:lowerCorner>
        		<gml:upperCorner>602537.825000 762685.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602537.825000 762685.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 020 673</ms:GML_ID>
        <ms:NAZWA>038 020 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038020673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614206.257120 785929.821564</gml:lowerCorner>
        		<gml:upperCorner>614206.257120 785929.821564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614206.257120 785929.821564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 200 613</ms:GML_ID>
        <ms:NAZWA>006 200 613</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006200613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591997.792000 787322.662000</gml:lowerCorner>
        		<gml:upperCorner>591997.792000 787322.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591997.792000 787322.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 011 702</ms:GML_ID>
        <ms:NAZWA>037 011 702</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037011702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616013.857238 787333.285657</gml:lowerCorner>
        		<gml:upperCorner>616013.857238 787333.285657</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616013.857238 787333.285657</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 202 902</ms:GML_ID>
        <ms:NAZWA>006 202 902</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006202902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591815.865000 788372.790000</gml:lowerCorner>
        		<gml:upperCorner>591815.865000 788372.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591815.865000 788372.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 012 769</ms:GML_ID>
        <ms:NAZWA>037 012 769</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037012769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617437.284000 788458.167000</gml:lowerCorner>
        		<gml:upperCorner>617437.284000 788458.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617437.284000 788458.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 204 715</ms:GML_ID>
        <ms:NAZWA>006 204 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006204715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617986.684000 788993.056000</gml:lowerCorner>
        		<gml:upperCorner>617986.684000 788993.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617986.684000 788993.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 205 483</ms:GML_ID>
        <ms:NAZWA>006 205 483</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006205483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618661.827000 789683.409000</gml:lowerCorner>
        		<gml:upperCorner>618661.827000 789683.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618661.827000 789683.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 206 448</ms:GML_ID>
        <ms:NAZWA>006 206 448</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006206448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619405.434000 790443.311000</gml:lowerCorner>
        		<gml:upperCorner>619405.434000 790443.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619405.434000 790443.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 207 511</ms:GML_ID>
        <ms:NAZWA>006 207 511</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006207511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590971.242000 790889.517000</gml:lowerCorner>
        		<gml:upperCorner>590971.242000 790889.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590971.242000 790889.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 015 427</ms:GML_ID>
        <ms:NAZWA>037 015 427</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037015427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590640.903546 791725.996154</gml:lowerCorner>
        		<gml:upperCorner>590640.903546 791725.996154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590640.903546 791725.996154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 016 331</ms:GML_ID>
        <ms:NAZWA>037 016 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037016331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620688.823029 791800.089739</gml:lowerCorner>
        		<gml:upperCorner>620688.823029 791800.089739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620688.823029 791800.089739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 209 379</ms:GML_ID>
        <ms:NAZWA>006 209 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006209379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621233.134326 792589.480306</gml:lowerCorner>
        		<gml:upperCorner>621233.134326 792589.480306</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621233.134326 792589.480306</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 210 338</ms:GML_ID>
        <ms:NAZWA>006 210 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006210338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590606.315000 792732.328000</gml:lowerCorner>
        		<gml:upperCorner>590606.315000 792732.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590606.315000 792732.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 017 338</ms:GML_ID>
        <ms:NAZWA>037 017 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037017338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590347.361000 794719.600000</gml:lowerCorner>
        		<gml:upperCorner>590347.361000 794719.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590347.361000 794719.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 019 353</ms:GML_ID>
        <ms:NAZWA>037 019 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037019353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622297.907000 795147.681000</gml:lowerCorner>
        		<gml:upperCorner>622297.907000 795147.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622297.907000 795147.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 213 123</ms:GML_ID>
        <ms:NAZWA>006 213 123</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006213123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623884.026000 796720.947000</gml:lowerCorner>
        		<gml:upperCorner>623884.026000 796720.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623884.026000 796720.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 215 500</ms:GML_ID>
        <ms:NAZWA>006 215 500</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006215500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624418.167376 797961.766477</gml:lowerCorner>
        		<gml:upperCorner>624418.167376 797961.766477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624418.167376 797961.766477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 216 890</ms:GML_ID>
        <ms:NAZWA>006 216 890</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006216890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589442.000000 798046.677000</gml:lowerCorner>
        		<gml:upperCorner>589442.000000 798046.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589442.000000 798046.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 022 828</ms:GML_ID>
        <ms:NAZWA>037 022 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037022828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624513.628868 798481.905516</gml:lowerCorner>
        		<gml:upperCorner>624513.628868 798481.905516</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624513.628868 798481.905516</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 217 421</ms:GML_ID>
        <ms:NAZWA>006 217 421</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006217421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589511.402011 798989.856372</gml:lowerCorner>
        		<gml:upperCorner>589511.402011 798989.856372</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589511.402011 798989.856372</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 023 774</ms:GML_ID>
        <ms:NAZWA>037 023 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037023774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589463.430000 800263.540000</gml:lowerCorner>
        		<gml:upperCorner>589463.430000 800263.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589463.430000 800263.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 025 054</ms:GML_ID>
        <ms:NAZWA>037 025 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037025054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589647.130447 802053.354426</gml:lowerCorner>
        		<gml:upperCorner>589647.130447 802053.354426</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589647.130447 802053.354426</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 026 877</ms:GML_ID>
        <ms:NAZWA>037 026 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037026877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591845.450000 808289.268000</gml:lowerCorner>
        		<gml:upperCorner>591845.450000 808289.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591845.450000 808289.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 033 668</ms:GML_ID>
        <ms:NAZWA>037 033 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037033668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592483.151041 810573.815171</gml:lowerCorner>
        		<gml:upperCorner>592483.151041 810573.815171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592483.151041 810573.815171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 036 040</ms:GML_ID>
        <ms:NAZWA>037 036 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037036040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592773.482585 811598.216029</gml:lowerCorner>
        		<gml:upperCorner>592773.482585 811598.216029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592773.482585 811598.216029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 037 103</ms:GML_ID>
        <ms:NAZWA>037 037 103</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037037103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592643.947000 813888.805000</gml:lowerCorner>
        		<gml:upperCorner>592643.947000 813888.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592643.947000 813888.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 039 448</ms:GML_ID>
        <ms:NAZWA>037 039 448</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037039448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592198.074967 815428.154062</gml:lowerCorner>
        		<gml:upperCorner>592198.074967 815428.154062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592198.074967 815428.154062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 041 051</ms:GML_ID>
        <ms:NAZWA>037 041 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037041051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591737.314000 816549.366000</gml:lowerCorner>
        		<gml:upperCorner>591737.314000 816549.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591737.314000 816549.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 042 285</ms:GML_ID>
        <ms:NAZWA>037 042 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037042285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591264.290532 817697.131047</gml:lowerCorner>
        		<gml:upperCorner>591264.290532 817697.131047</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591264.290532 817697.131047</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 043 523</ms:GML_ID>
        <ms:NAZWA>037 043 523</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037043523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590407.937562 820244.807578</gml:lowerCorner>
        		<gml:upperCorner>590407.937562 820244.807578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590407.937562 820244.807578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 046 229</ms:GML_ID>
        <ms:NAZWA>037 046 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037046229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591070.891024 822630.106805</gml:lowerCorner>
        		<gml:upperCorner>591070.891024 822630.106805</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591070.891024 822630.106805</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 048 712</ms:GML_ID>
        <ms:NAZWA>037 048 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037048712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591229.366216 822898.518283</gml:lowerCorner>
        		<gml:upperCorner>591229.366216 822898.518283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591229.366216 822898.518283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 049 027</ms:GML_ID>
        <ms:NAZWA>037 049 027</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037049027</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592043.465478 824324.335124</gml:lowerCorner>
        		<gml:upperCorner>592043.465478 824324.335124</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592043.465478 824324.335124</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 050 667</ms:GML_ID>
        <ms:NAZWA>037 050 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037050667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592577.453605 826101.556464</gml:lowerCorner>
        		<gml:upperCorner>592577.453605 826101.556464</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592577.453605 826101.556464</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 052 525</ms:GML_ID>
        <ms:NAZWA>037 052 525</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037052525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635960.516000 649175.441000</gml:lowerCorner>
        		<gml:upperCorner>635960.516000 649175.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635960.516000 649175.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 062 244</ms:GML_ID>
        <ms:NAZWA>219 062 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219062244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635980.474000 649901.397000</gml:lowerCorner>
        		<gml:upperCorner>635980.474000 649901.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635980.474000 649901.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 062 971</ms:GML_ID>
        <ms:NAZWA>219 062 971</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219062971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636011.743000 651044.813000</gml:lowerCorner>
        		<gml:upperCorner>636011.743000 651044.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636011.743000 651044.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 064 115</ms:GML_ID>
        <ms:NAZWA>219 064 115</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219064115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586138.525000 651834.278000</gml:lowerCorner>
        		<gml:upperCorner>586138.525000 651834.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586138.525000 651834.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 026 951</ms:GML_ID>
        <ms:NAZWA>035 026 951</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035026951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638673.363000 655590.789000</gml:lowerCorner>
        		<gml:upperCorner>638673.363000 655590.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638673.363000 655590.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 069 464</ms:GML_ID>
        <ms:NAZWA>219 069 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219069464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639150.693742 656220.077168</gml:lowerCorner>
        		<gml:upperCorner>639150.693742 656220.077168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639150.693742 656220.077168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 070 260</ms:GML_ID>
        <ms:NAZWA>219 070 260</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219070260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640158.913000 658699.901000</gml:lowerCorner>
        		<gml:upperCorner>640158.913000 658699.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640158.913000 658699.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 072 945</ms:GML_ID>
        <ms:NAZWA>219 072 945</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219072945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641910.795000 661484.250000</gml:lowerCorner>
        		<gml:upperCorner>641910.795000 661484.250000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641910.795000 661484.250000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 076 274</ms:GML_ID>
        <ms:NAZWA>219 076 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219076274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644735.254509 666507.385981</gml:lowerCorner>
        		<gml:upperCorner>644735.254509 666507.385981</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644735.254509 666507.385981</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 082 182</ms:GML_ID>
        <ms:NAZWA>219 082 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219082182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662183.748000 667671.196000</gml:lowerCorner>
        		<gml:upperCorner>662183.748000 667671.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662183.748000 667671.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 054 000</ms:GML_ID>
        <ms:NAZWA>223 054 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223054000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645512.294000 669592.192000</gml:lowerCorner>
        		<gml:upperCorner>645512.294000 669592.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645512.294000 669592.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 086 132</ms:GML_ID>
        <ms:NAZWA>219 086 132</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219086132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645067.328292 669868.487672</gml:lowerCorner>
        		<gml:upperCorner>645067.328292 669868.487672</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645067.328292 669868.487672</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 086 654</ms:GML_ID>
        <ms:NAZWA>219 086 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219086654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644662.454000 670889.595000</gml:lowerCorner>
        		<gml:upperCorner>644662.454000 670889.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644662.454000 670889.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 087 844</ms:GML_ID>
        <ms:NAZWA>219 087 844</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219087844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644932.304000 675972.680000</gml:lowerCorner>
        		<gml:upperCorner>644932.304000 675972.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644932.304000 675972.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 093 079</ms:GML_ID>
        <ms:NAZWA>219 093 079</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219093079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644934.025000 676757.172000</gml:lowerCorner>
        		<gml:upperCorner>644934.025000 676757.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644934.025000 676757.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 093 864</ms:GML_ID>
        <ms:NAZWA>219 093 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219093864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644785.468000 682082.277000</gml:lowerCorner>
        		<gml:upperCorner>644785.468000 682082.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644785.468000 682082.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 099 402</ms:GML_ID>
        <ms:NAZWA>219 099 402</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219099402</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644563.458000 682856.353000</gml:lowerCorner>
        		<gml:upperCorner>644563.458000 682856.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644563.458000 682856.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 100 207</ms:GML_ID>
        <ms:NAZWA>219 100 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219100207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644434.370000 685266.174000</gml:lowerCorner>
        		<gml:upperCorner>644434.370000 685266.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644434.370000 685266.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 102 645</ms:GML_ID>
        <ms:NAZWA>219 102 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219102645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644261.076936 686418.071985</gml:lowerCorner>
        		<gml:upperCorner>644261.076936 686418.071985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644261.076936 686418.071985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 103 818</ms:GML_ID>
        <ms:NAZWA>219 103 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219103818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644018.689000 686998.969000</gml:lowerCorner>
        		<gml:upperCorner>644018.689000 686998.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644018.689000 686998.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 104 457</ms:GML_ID>
        <ms:NAZWA>219 104 457</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219104457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643975.513215 687338.027288</gml:lowerCorner>
        		<gml:upperCorner>643975.513215 687338.027288</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643975.513215 687338.027288</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 104 800</ms:GML_ID>
        <ms:NAZWA>219 104 800</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219104800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643831.343000 688479.286000</gml:lowerCorner>
        		<gml:upperCorner>643831.343000 688479.286000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643831.343000 688479.286000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 105 949</ms:GML_ID>
        <ms:NAZWA>219 105 949</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219105949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643791.038000 688765.810000</gml:lowerCorner>
        		<gml:upperCorner>643791.038000 688765.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643791.038000 688765.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 106 239</ms:GML_ID>
        <ms:NAZWA>219 106 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219106239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643593.876000 690056.638000</gml:lowerCorner>
        		<gml:upperCorner>643593.876000 690056.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643593.876000 690056.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 107 549</ms:GML_ID>
        <ms:NAZWA>219 107 549</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219107549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643536.363000 690401.235000</gml:lowerCorner>
        		<gml:upperCorner>643536.363000 690401.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643536.363000 690401.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 107 895</ms:GML_ID>
        <ms:NAZWA>219 107 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219107895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643334.904000 691585.093000</gml:lowerCorner>
        		<gml:upperCorner>643334.904000 691585.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643334.904000 691585.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 109 096</ms:GML_ID>
        <ms:NAZWA>219 109 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219109096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643200.211000 692350.834000</gml:lowerCorner>
        		<gml:upperCorner>643200.211000 692350.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643200.211000 692350.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 109 874</ms:GML_ID>
        <ms:NAZWA>219 109 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219109874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642989.022000 692866.037000</gml:lowerCorner>
        		<gml:upperCorner>642989.022000 692866.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642989.022000 692866.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 110 431</ms:GML_ID>
        <ms:NAZWA>219 110 431</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219110431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642746.092000 693453.909000</gml:lowerCorner>
        		<gml:upperCorner>642746.092000 693453.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642746.092000 693453.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 111 067</ms:GML_ID>
        <ms:NAZWA>219 111 067</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219111067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581579.473036 718740.612130</gml:lowerCorner>
        		<gml:upperCorner>581579.473036 718740.612130</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581579.473036 718740.612130</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 044 567</ms:GML_ID>
        <ms:NAZWA>036 044 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036044567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581659.021701 717959.230542</gml:lowerCorner>
        		<gml:upperCorner>581659.021701 717959.230542</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581659.021701 717959.230542</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 043 779</ms:GML_ID>
        <ms:NAZWA>036 043 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036043779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581820.431105 711446.198780</gml:lowerCorner>
        		<gml:upperCorner>581820.431105 711446.198780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581820.431105 711446.198780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 037 119</ms:GML_ID>
        <ms:NAZWA>036 037 119</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036037119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581952.292917 712381.586463</gml:lowerCorner>
        		<gml:upperCorner>581952.292917 712381.586463</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581952.292917 712381.586463</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 038 064</ms:GML_ID>
        <ms:NAZWA>036 038 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036038064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581993.333803 712757.090384</gml:lowerCorner>
        		<gml:upperCorner>581993.333803 712757.090384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581993.333803 712757.090384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 038 442</ms:GML_ID>
        <ms:NAZWA>036 038 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036038442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582146.777522 716397.008859</gml:lowerCorner>
        		<gml:upperCorner>582146.777522 716397.008859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582146.777522 716397.008859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 042 143</ms:GML_ID>
        <ms:NAZWA>036 042 143</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036042143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582193.913106 714814.062918</gml:lowerCorner>
        		<gml:upperCorner>582193.913106 714814.062918</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582193.913106 714814.062918</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 040 546</ms:GML_ID>
        <ms:NAZWA>036 040 546</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036040546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582197.125369 713743.959399</gml:lowerCorner>
        		<gml:upperCorner>582197.125369 713743.959399</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582197.125369 713743.959399</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 039 453</ms:GML_ID>
        <ms:NAZWA>036 039 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036039453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582205.523019 713962.977011</gml:lowerCorner>
        		<gml:upperCorner>582205.523019 713962.977011</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582205.523019 713962.977011</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 039 673</ms:GML_ID>
        <ms:NAZWA>036 039 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036039673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582225.000000 715634.860000</gml:lowerCorner>
        		<gml:upperCorner>582225.000000 715634.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582225.000000 715634.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 041 375</ms:GML_ID>
        <ms:NAZWA>036 041 375</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036041375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582402.739000 701828.357000</gml:lowerCorner>
        		<gml:upperCorner>582402.739000 701828.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582402.739000 701828.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 004 052</ms:GML_ID>
        <ms:NAZWA>049 004 052</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049004052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583775.239295 702474.997430</gml:lowerCorner>
        		<gml:upperCorner>583775.239295 702474.997430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583775.239295 702474.997430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 005 580</ms:GML_ID>
        <ms:NAZWA>049 005 580</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049005580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584422.586454 702643.882889</gml:lowerCorner>
        		<gml:upperCorner>584422.586454 702643.882889</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584422.586454 702643.882889</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 006 248</ms:GML_ID>
        <ms:NAZWA>049 006 248</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049006248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585360.666905 703119.882707</gml:lowerCorner>
        		<gml:upperCorner>585360.666905 703119.882707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585360.666905 703119.882707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 007 314</ms:GML_ID>
        <ms:NAZWA>049 007 314</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049007314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585842.151458 703453.140825</gml:lowerCorner>
        		<gml:upperCorner>585842.151458 703453.140825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585842.151458 703453.140825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 007 905</ms:GML_ID>
        <ms:NAZWA>049 007 905</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049007905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587272.197279 703999.880756</gml:lowerCorner>
        		<gml:upperCorner>587272.197279 703999.880756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587272.197279 703999.880756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 009 612</ms:GML_ID>
        <ms:NAZWA>049 009 612</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049009612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588751.205451 703739.301745</gml:lowerCorner>
        		<gml:upperCorner>588751.205451 703739.301745</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588751.205451 703739.301745</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 011 205</ms:GML_ID>
        <ms:NAZWA>049 011 205</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049011205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590279.363852 703834.343374</gml:lowerCorner>
        		<gml:upperCorner>590279.363852 703834.343374</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590279.363852 703834.343374</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 012 773</ms:GML_ID>
        <ms:NAZWA>049 012 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049012773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590991.381327 703626.174131</gml:lowerCorner>
        		<gml:upperCorner>590991.381327 703626.174131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590991.381327 703626.174131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 013 516</ms:GML_ID>
        <ms:NAZWA>049 013 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049013516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591810.269066 703799.561446</gml:lowerCorner>
        		<gml:upperCorner>591810.269066 703799.561446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591810.269066 703799.561446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 014 366</ms:GML_ID>
        <ms:NAZWA>049 014 366</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049014366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592275.181311 703956.271624</gml:lowerCorner>
        		<gml:upperCorner>592275.181311 703956.271624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592275.181311 703956.271624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 014 855</ms:GML_ID>
        <ms:NAZWA>049 014 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049014855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592961.635209 704227.671891</gml:lowerCorner>
        		<gml:upperCorner>592961.635209 704227.671891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592961.635209 704227.671891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 015 593</ms:GML_ID>
        <ms:NAZWA>049 015 593</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049015593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593379.516184 704414.011115</gml:lowerCorner>
        		<gml:upperCorner>593379.516184 704414.011115</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593379.516184 704414.011115</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 016 050</ms:GML_ID>
        <ms:NAZWA>049 016 050</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049016050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601714.248000 763602.078000</gml:lowerCorner>
        		<gml:upperCorner>601714.248000 763602.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601714.248000 763602.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 019 441</ms:GML_ID>
        <ms:NAZWA>038 019 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038019441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600594.135000 764984.168000</gml:lowerCorner>
        		<gml:upperCorner>600594.135000 764984.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600594.135000 764984.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 017 657</ms:GML_ID>
        <ms:NAZWA>038 017 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038017657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600103.251000 766262.139000</gml:lowerCorner>
        		<gml:upperCorner>600103.251000 766262.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600103.251000 766262.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 016 281</ms:GML_ID>
        <ms:NAZWA>038 016 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038016281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599871.649000 766730.994000</gml:lowerCorner>
        		<gml:upperCorner>599871.649000 766730.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599871.649000 766730.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 015 758</ms:GML_ID>
        <ms:NAZWA>038 015 758</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038015758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599444.496000 767597.089000</gml:lowerCorner>
        		<gml:upperCorner>599444.496000 767597.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599444.496000 767597.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 014 793</ms:GML_ID>
        <ms:NAZWA>038 014 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038014793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597598.420000 768972.350000</gml:lowerCorner>
        		<gml:upperCorner>597598.420000 768972.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597598.420000 768972.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 012 443</ms:GML_ID>
        <ms:NAZWA>038 012 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038012443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597130.002000 770343.565000</gml:lowerCorner>
        		<gml:upperCorner>597130.002000 770343.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597130.002000 770343.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 010 956</ms:GML_ID>
        <ms:NAZWA>038 010 956</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038010956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596826.714000 771031.553000</gml:lowerCorner>
        		<gml:upperCorner>596826.714000 771031.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596826.714000 771031.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 010 194</ms:GML_ID>
        <ms:NAZWA>038 010 194</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038010194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592659.543679 772868.187842</gml:lowerCorner>
        		<gml:upperCorner>592659.543679 772868.187842</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592659.543679 772868.187842</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 005 460</ms:GML_ID>
        <ms:NAZWA>038 005 460</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>038005460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590237.537000 775329.936000</gml:lowerCorner>
        		<gml:upperCorner>590237.537000 775329.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590237.537000 775329.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 072 495</ms:GML_ID>
        <ms:NAZWA>032 072 495</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032072495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583866.723000 776239.975000</gml:lowerCorner>
        		<gml:upperCorner>583866.723000 776239.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583866.723000 776239.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 065 429</ms:GML_ID>
        <ms:NAZWA>032 065 429</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032065429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588133.137469 776241.745044</gml:lowerCorner>
        		<gml:upperCorner>588133.137469 776241.745044</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588133.137469 776241.745044</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 069 775</ms:GML_ID>
        <ms:NAZWA>032 069 775</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032069775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584833.557026 776406.167342</gml:lowerCorner>
        		<gml:upperCorner>584833.557026 776406.167342</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584833.557026 776406.167342</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 066 419</ms:GML_ID>
        <ms:NAZWA>032 066 419</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032066419</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586479.735231 776432.590580</gml:lowerCorner>
        		<gml:upperCorner>586479.735231 776432.590580</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586479.735231 776432.590580</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 068 100</ms:GML_ID>
        <ms:NAZWA>032 068 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032068100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581901.515024 776472.908378</gml:lowerCorner>
        		<gml:upperCorner>581901.515024 776472.908378</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581901.515024 776472.908378</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 063 452</ms:GML_ID>
        <ms:NAZWA>032 063 452</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032063452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580636.229000 776539.448000</gml:lowerCorner>
        		<gml:upperCorner>580636.229000 776539.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580636.229000 776539.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 062 181</ms:GML_ID>
        <ms:NAZWA>032 062 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032062181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579403.521000 776608.651000</gml:lowerCorner>
        		<gml:upperCorner>579403.521000 776608.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579403.521000 776608.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 060 947</ms:GML_ID>
        <ms:NAZWA>032 060 947</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032060947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595377.442000 777168.937000</gml:lowerCorner>
        		<gml:upperCorner>595377.442000 777168.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595377.442000 777168.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 179 461</ms:GML_ID>
        <ms:NAZWA>006 179 461</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006179461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597889.684000 777397.730000</gml:lowerCorner>
        		<gml:upperCorner>597889.684000 777397.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597889.684000 777397.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 181 983</ms:GML_ID>
        <ms:NAZWA>006 181 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006181983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594131.028000 777470.112000</gml:lowerCorner>
        		<gml:upperCorner>594131.028000 777470.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594131.028000 777470.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 001 203</ms:GML_ID>
        <ms:NAZWA>037 001 203</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037001203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599154.199000 778216.354000</gml:lowerCorner>
        		<gml:upperCorner>599154.199000 778216.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599154.199000 778216.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 183 505</ms:GML_ID>
        <ms:NAZWA>006 183 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006183505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600601.591665 778845.374437</gml:lowerCorner>
        		<gml:upperCorner>600601.591665 778845.374437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600601.591665 778845.374437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 185 095</ms:GML_ID>
        <ms:NAZWA>006 185 095</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006185095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605094.371000 780284.110000</gml:lowerCorner>
        		<gml:upperCorner>605094.371000 780284.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605094.371000 780284.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 189 814</ms:GML_ID>
        <ms:NAZWA>006 189 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006189814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593962.177369 780413.862221</gml:lowerCorner>
        		<gml:upperCorner>593962.177369 780413.862221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593962.177369 780413.862221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 004 404</ms:GML_ID>
        <ms:NAZWA>037 004 404</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037004404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593568.004000 781203.577000</gml:lowerCorner>
        		<gml:upperCorner>593568.004000 781203.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593568.004000 781203.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 005 287</ms:GML_ID>
        <ms:NAZWA>037 005 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037005287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608144.107000 781593.892000</gml:lowerCorner>
        		<gml:upperCorner>608144.107000 781593.892000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608144.107000 781593.892000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 193 155</ms:GML_ID>
        <ms:NAZWA>006 193 155</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006193155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609910.348042 782724.338273</gml:lowerCorner>
        		<gml:upperCorner>609910.348042 782724.338273</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609910.348042 782724.338273</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 195 251</ms:GML_ID>
        <ms:NAZWA>006 195 251</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006195251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592769.397000 782868.607000</gml:lowerCorner>
        		<gml:upperCorner>592769.397000 782868.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592769.397000 782868.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 007 132</ms:GML_ID>
        <ms:NAZWA>037 007 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037007132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592584.014000 783254.972000</gml:lowerCorner>
        		<gml:upperCorner>592584.014000 783254.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592584.014000 783254.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 007 559</ms:GML_ID>
        <ms:NAZWA>037 007 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037007559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611166.424000 783551.765000</gml:lowerCorner>
        		<gml:upperCorner>611166.424000 783551.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611166.424000 783551.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 196 755</ms:GML_ID>
        <ms:NAZWA>006 196 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006196755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612320.821262 784450.016888</gml:lowerCorner>
        		<gml:upperCorner>612320.821262 784450.016888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612320.821262 784450.016888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 198 217</ms:GML_ID>
        <ms:NAZWA>006 198 217</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006198217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613131.298732 785081.736771</gml:lowerCorner>
        		<gml:upperCorner>613131.298732 785081.736771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613131.298732 785081.736771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 199 245</ms:GML_ID>
        <ms:NAZWA>006 199 245</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006199245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592178.647000 785225.303000</gml:lowerCorner>
        		<gml:upperCorner>592178.647000 785225.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592178.647000 785225.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.037 009 595</ms:GML_ID>
        <ms:NAZWA>037 009 595</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>037009595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291930.431835 799001.919377</gml:lowerCorner>
        		<gml:upperCorner>291930.431835 799001.919377</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291930.431835 799001.919377</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 104 022</ms:GML_ID>
        <ms:NAZWA>069 104 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069104022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291830.560000 799674.131000</gml:lowerCorner>
        		<gml:upperCorner>291830.560000 799674.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291830.560000 799674.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 104 707</ms:GML_ID>
        <ms:NAZWA>069 104 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069104707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291607.904000 801394.544000</gml:lowerCorner>
        		<gml:upperCorner>291607.904000 801394.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291607.904000 801394.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 106 445</ms:GML_ID>
        <ms:NAZWA>069 106 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069106445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291392.845000 802510.469000</gml:lowerCorner>
        		<gml:upperCorner>291392.845000 802510.469000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291392.845000 802510.469000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 107 626</ms:GML_ID>
        <ms:NAZWA>069 107 626</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069107626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290733.867475 803994.235762</gml:lowerCorner>
        		<gml:upperCorner>290733.867475 803994.235762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290733.867475 803994.235762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 109 302</ms:GML_ID>
        <ms:NAZWA>069 109 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069109302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290865.352000 807044.859000</gml:lowerCorner>
        		<gml:upperCorner>290865.352000 807044.859000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290865.352000 807044.859000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 112 382</ms:GML_ID>
        <ms:NAZWA>069 112 382</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069112382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290679.566000 807565.870000</gml:lowerCorner>
        		<gml:upperCorner>290679.566000 807565.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290679.566000 807565.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 112 950</ms:GML_ID>
        <ms:NAZWA>069 112 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069112950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290647.347218 808029.993589</gml:lowerCorner>
        		<gml:upperCorner>290647.347218 808029.993589</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290647.347218 808029.993589</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 113 420</ms:GML_ID>
        <ms:NAZWA>069 113 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069113420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290445.284000 809203.878000</gml:lowerCorner>
        		<gml:upperCorner>290445.284000 809203.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290445.284000 809203.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 114 615</ms:GML_ID>
        <ms:NAZWA>069 114 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069114615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289635.869000 810585.145000</gml:lowerCorner>
        		<gml:upperCorner>289635.869000 810585.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289635.869000 810585.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 116 286</ms:GML_ID>
        <ms:NAZWA>069 116 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069116286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289278.968141 810980.269131</gml:lowerCorner>
        		<gml:upperCorner>289278.968141 810980.269131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289278.968141 810980.269131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 116 829</ms:GML_ID>
        <ms:NAZWA>069 116 829</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069116829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288544.120773 813044.966165</gml:lowerCorner>
        		<gml:upperCorner>288544.120773 813044.966165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288544.120773 813044.966165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 119 092</ms:GML_ID>
        <ms:NAZWA>069 119 092</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069119092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288588.962000 813339.225000</gml:lowerCorner>
        		<gml:upperCorner>288588.962000 813339.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288588.962000 813339.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 119 404</ms:GML_ID>
        <ms:NAZWA>069 119 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069119404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288767.847000 814144.971000</gml:lowerCorner>
        		<gml:upperCorner>288767.847000 814144.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288767.847000 814144.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 120 258</ms:GML_ID>
        <ms:NAZWA>069 120 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069120258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288819.771000 814559.974000</gml:lowerCorner>
        		<gml:upperCorner>288819.771000 814559.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288819.771000 814559.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 120 677</ms:GML_ID>
        <ms:NAZWA>069 120 677</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069120677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288911.332000 814768.698000</gml:lowerCorner>
        		<gml:upperCorner>288911.332000 814768.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288911.332000 814768.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 120 904</ms:GML_ID>
        <ms:NAZWA>069 120 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069120904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288977.484000 815100.936000</gml:lowerCorner>
        		<gml:upperCorner>288977.484000 815100.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288977.484000 815100.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 121 244</ms:GML_ID>
        <ms:NAZWA>069 121 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069121244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288771.010000 815659.425000</gml:lowerCorner>
        		<gml:upperCorner>288771.010000 815659.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288771.010000 815659.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 121 860</ms:GML_ID>
        <ms:NAZWA>069 121 860</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069121860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296850.566740 724997.588819</gml:lowerCorner>
        		<gml:upperCorner>296850.566740 724997.588819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296850.566740 724997.588819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 117 401</ms:GML_ID>
        <ms:NAZWA>068 117 401</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068117401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295764.030375 726274.257149</gml:lowerCorner>
        		<gml:upperCorner>295764.030375 726274.257149</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295764.030375 726274.257149</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 119 080</ms:GML_ID>
        <ms:NAZWA>068 119 080</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068119080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294602.228676 727165.251506</gml:lowerCorner>
        		<gml:upperCorner>294602.228676 727165.251506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294602.228676 727165.251506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 120 562</ms:GML_ID>
        <ms:NAZWA>068 120 562</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068120562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293121.091837 728059.795240</gml:lowerCorner>
        		<gml:upperCorner>293121.091837 728059.795240</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293121.091837 728059.795240</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 122 294</ms:GML_ID>
        <ms:NAZWA>068 122 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068122294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292165.765634 728701.871555</gml:lowerCorner>
        		<gml:upperCorner>292165.765634 728701.871555</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292165.765634 728701.871555</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 123 445</ms:GML_ID>
        <ms:NAZWA>068 123 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068123445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291205.865000 729692.569000</gml:lowerCorner>
        		<gml:upperCorner>291205.865000 729692.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291205.865000 729692.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 124 838</ms:GML_ID>
        <ms:NAZWA>068 124 838</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068124838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290985.749000 729971.775000</gml:lowerCorner>
        		<gml:upperCorner>290985.749000 729971.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290985.749000 729971.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 125 187</ms:GML_ID>
        <ms:NAZWA>068 125 187</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068125187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290814.326763 730192.787977</gml:lowerCorner>
        		<gml:upperCorner>290814.326763 730192.787977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290814.326763 730192.787977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 125 471</ms:GML_ID>
        <ms:NAZWA>068 125 471</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068125471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290520.540729 730549.186635</gml:lowerCorner>
        		<gml:upperCorner>290520.540729 730549.186635</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290520.540729 730549.186635</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 125 932</ms:GML_ID>
        <ms:NAZWA>068 125 932</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068125932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283479.923000 731161.850000</gml:lowerCorner>
        		<gml:upperCorner>283479.923000 731161.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283479.923000 731161.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 133 317</ms:GML_ID>
        <ms:NAZWA>068 133 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068133317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286042.774845 731215.445274</gml:lowerCorner>
        		<gml:upperCorner>286042.774845 731215.445274</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286042.774845 731215.445274</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 130 768</ms:GML_ID>
        <ms:NAZWA>068 130 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068130768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282679.270740 731269.772874</gml:lowerCorner>
        		<gml:upperCorner>282679.270740 731269.772874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282679.270740 731269.772874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 134 150</ms:GML_ID>
        <ms:NAZWA>068 134 150</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068134150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279159.536501 737275.568185</gml:lowerCorner>
        		<gml:upperCorner>279159.536501 737275.568185</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279159.536501 737275.568185</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 141 292</ms:GML_ID>
        <ms:NAZWA>068 141 292</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068141292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278861.090000 737496.754000</gml:lowerCorner>
        		<gml:upperCorner>278861.090000 737496.754000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278861.090000 737496.754000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 141 664</ms:GML_ID>
        <ms:NAZWA>068 141 664</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068141664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278180.094523 738037.234621</gml:lowerCorner>
        		<gml:upperCorner>278180.094523 738037.234621</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278180.094523 738037.234621</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 142 535</ms:GML_ID>
        <ms:NAZWA>068 142 535</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068142535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276124.631000 739551.726000</gml:lowerCorner>
        		<gml:upperCorner>276124.631000 739551.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276124.631000 739551.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 145 092</ms:GML_ID>
        <ms:NAZWA>068 145 092</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068145092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276042.478000 739604.745000</gml:lowerCorner>
        		<gml:upperCorner>276042.478000 739604.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276042.478000 739604.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 145 189</ms:GML_ID>
        <ms:NAZWA>068 145 189</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068145189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275186.125000 740082.465000</gml:lowerCorner>
        		<gml:upperCorner>275186.125000 740082.465000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275186.125000 740082.465000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 146 173</ms:GML_ID>
        <ms:NAZWA>068 146 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068146173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273067.048000 742423.399000</gml:lowerCorner>
        		<gml:upperCorner>273067.048000 742423.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273067.048000 742423.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 149 354</ms:GML_ID>
        <ms:NAZWA>068 149 354</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068149354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272450.500207 743432.734750</gml:lowerCorner>
        		<gml:upperCorner>272450.500207 743432.734750</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272450.500207 743432.734750</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 150 607</ms:GML_ID>
        <ms:NAZWA>068 150 607</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068150607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271429.539361 743859.232702</gml:lowerCorner>
        		<gml:upperCorner>271429.539361 743859.232702</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271429.539361 743859.232702</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 151 725</ms:GML_ID>
        <ms:NAZWA>068 151 725</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068151725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271222.727622 744373.193361</gml:lowerCorner>
        		<gml:upperCorner>271222.727622 744373.193361</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271222.727622 744373.193361</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 152 285</ms:GML_ID>
        <ms:NAZWA>068 152 285</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068152285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269255.386283 811801.804440</gml:lowerCorner>
        		<gml:upperCorner>269255.386283 811801.804440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269255.386283 811801.804440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 059 660</ms:GML_ID>
        <ms:NAZWA>101 059 660</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101059660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270557.000717 817365.579918</gml:lowerCorner>
        		<gml:upperCorner>270557.000717 817365.579918</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270557.000717 817365.579918</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 065 894</ms:GML_ID>
        <ms:NAZWA>101 065 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101065894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271591.813562 818126.777131</gml:lowerCorner>
        		<gml:upperCorner>271591.813562 818126.777131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271591.813562 818126.777131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 067 714</ms:GML_ID>
        <ms:NAZWA>101 067 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101067714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273540.458932 821959.001456</gml:lowerCorner>
        		<gml:upperCorner>273540.458932 821959.001456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273540.458932 821959.001456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 073 708</ms:GML_ID>
        <ms:NAZWA>101 073 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101073708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273839.408000 822722.305000</gml:lowerCorner>
        		<gml:upperCorner>273839.408000 822722.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273839.408000 822722.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 074 586</ms:GML_ID>
        <ms:NAZWA>101 074 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101074586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273869.270000 818602.247000</gml:lowerCorner>
        		<gml:upperCorner>273869.270000 818602.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273869.270000 818602.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 070 116</ms:GML_ID>
        <ms:NAZWA>101 070 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101070116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273873.135870 820678.401796</gml:lowerCorner>
        		<gml:upperCorner>273873.135870 820678.401796</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273873.135870 820678.401796</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.116 001 925</ms:GML_ID>
        <ms:NAZWA>116 001 925</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>116001925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273892.798506 820679.614342</gml:lowerCorner>
        		<gml:upperCorner>273892.798506 820679.614342</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273892.798506 820679.614342</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 072 377</ms:GML_ID>
        <ms:NAZWA>101 072 377</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101072377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275962.201000 824609.058000</gml:lowerCorner>
        		<gml:upperCorner>275962.201000 824609.058000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275962.201000 824609.058000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 077 809</ms:GML_ID>
        <ms:NAZWA>101 077 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101077809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276291.641000 825170.512000</gml:lowerCorner>
        		<gml:upperCorner>276291.641000 825170.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276291.641000 825170.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 078 497</ms:GML_ID>
        <ms:NAZWA>101 078 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101078497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276799.984000 825398.613000</gml:lowerCorner>
        		<gml:upperCorner>276799.984000 825398.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276799.984000 825398.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 079 054</ms:GML_ID>
        <ms:NAZWA>101 079 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101079054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277377.683265 825670.605494</gml:lowerCorner>
        		<gml:upperCorner>277377.683265 825670.605494</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277377.683265 825670.605494</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 079 692</ms:GML_ID>
        <ms:NAZWA>101 079 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101079692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278311.444000 826240.025000</gml:lowerCorner>
        		<gml:upperCorner>278311.444000 826240.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278311.444000 826240.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 080 812</ms:GML_ID>
        <ms:NAZWA>101 080 812</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101080812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279002.881000 826221.558000</gml:lowerCorner>
        		<gml:upperCorner>279002.881000 826221.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279002.881000 826221.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 081 504</ms:GML_ID>
        <ms:NAZWA>101 081 504</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101081504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279766.672000 826315.812000</gml:lowerCorner>
        		<gml:upperCorner>279766.672000 826315.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279766.672000 826315.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 082 275</ms:GML_ID>
        <ms:NAZWA>101 082 275</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>101082275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279917.614000 828016.003000</gml:lowerCorner>
        		<gml:upperCorner>279917.614000 828016.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279917.614000 828016.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 138 024</ms:GML_ID>
        <ms:NAZWA>069 138 024</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069138024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280101.413160 826495.931840</gml:lowerCorner>
        		<gml:upperCorner>280101.413160 826495.931840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280101.413160 826495.931840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 136 480</ms:GML_ID>
        <ms:NAZWA>069 136 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069136480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280127.519433 826012.064087</gml:lowerCorner>
        		<gml:upperCorner>280127.519433 826012.064087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280127.519433 826012.064087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 135 993</ms:GML_ID>
        <ms:NAZWA>069 135 993</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069135993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281244.175000 824535.238000</gml:lowerCorner>
        		<gml:upperCorner>281244.175000 824535.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281244.175000 824535.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 134 028</ms:GML_ID>
        <ms:NAZWA>069 134 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069134028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282576.231470 823544.107856</gml:lowerCorner>
        		<gml:upperCorner>282576.231470 823544.107856</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282576.231470 823544.107856</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 132 354</ms:GML_ID>
        <ms:NAZWA>069 132 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069132354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283961.866586 822602.657554</gml:lowerCorner>
        		<gml:upperCorner>283961.866586 822602.657554</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283961.866586 822602.657554</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 130 624</ms:GML_ID>
        <ms:NAZWA>069 130 624</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069130624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284715.794268 822101.431568</gml:lowerCorner>
        		<gml:upperCorner>284715.794268 822101.431568</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284715.794268 822101.431568</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 129 707</ms:GML_ID>
        <ms:NAZWA>069 129 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069129707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285240.389154 821492.527385</gml:lowerCorner>
        		<gml:upperCorner>285240.389154 821492.527385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285240.389154 821492.527385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 128 847</ms:GML_ID>
        <ms:NAZWA>069 128 847</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069128847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286328.487486 819509.855396</gml:lowerCorner>
        		<gml:upperCorner>286328.487486 819509.855396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286328.487486 819509.855396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 126 506</ms:GML_ID>
        <ms:NAZWA>069 126 506</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069126506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287875.665000 816724.991000</gml:lowerCorner>
        		<gml:upperCorner>287875.665000 816724.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287875.665000 816724.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 123 248</ms:GML_ID>
        <ms:NAZWA>069 123 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069123248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262366.661000 788343.267000</gml:lowerCorner>
        		<gml:upperCorner>262366.661000 788343.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262366.661000 788343.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 033 074</ms:GML_ID>
        <ms:NAZWA>101 033 074</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101033074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262495.731167 789312.379078</gml:lowerCorner>
        		<gml:upperCorner>262495.731167 789312.379078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262495.731167 789312.379078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 034 101</ms:GML_ID>
        <ms:NAZWA>101 034 101</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101034101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262790.341923 791074.893073</gml:lowerCorner>
        		<gml:upperCorner>262790.341923 791074.893073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262790.341923 791074.893073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 035 888</ms:GML_ID>
        <ms:NAZWA>101 035 888</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101035888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262893.377958 791683.802509</gml:lowerCorner>
        		<gml:upperCorner>262893.377958 791683.802509</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262893.377958 791683.802509</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 036 505</ms:GML_ID>
        <ms:NAZWA>101 036 505</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101036505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263038.749000 792543.056000</gml:lowerCorner>
        		<gml:upperCorner>263038.749000 792543.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263038.749000 792543.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 037 376</ms:GML_ID>
        <ms:NAZWA>101 037 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101037376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263465.012913 794285.301452</gml:lowerCorner>
        		<gml:upperCorner>263465.012913 794285.301452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263465.012913 794285.301452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 039 176</ms:GML_ID>
        <ms:NAZWA>101 039 176</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101039176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264026.661000 795220.642000</gml:lowerCorner>
        		<gml:upperCorner>264026.661000 795220.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264026.661000 795220.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 040 297</ms:GML_ID>
        <ms:NAZWA>101 040 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101040297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266014.830000 797531.867000</gml:lowerCorner>
        		<gml:upperCorner>266014.830000 797531.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266014.830000 797531.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 043 373</ms:GML_ID>
        <ms:NAZWA>101 043 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101043373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266456.640592 798260.609091</gml:lowerCorner>
        		<gml:upperCorner>266456.640592 798260.609091</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266456.640592 798260.609091</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 044 225</ms:GML_ID>
        <ms:NAZWA>101 044 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101044225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266614.040841 798721.085364</gml:lowerCorner>
        		<gml:upperCorner>266614.040841 798721.085364</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266614.040841 798721.085364</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 044 724</ms:GML_ID>
        <ms:NAZWA>101 044 724</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101044724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266386.222231 801041.182118</gml:lowerCorner>
        		<gml:upperCorner>266386.222231 801041.182118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266386.222231 801041.182118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 047 066</ms:GML_ID>
        <ms:NAZWA>101 047 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101047066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266083.230000 801841.952000</gml:lowerCorner>
        		<gml:upperCorner>266083.230000 801841.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266083.230000 801841.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 047 925</ms:GML_ID>
        <ms:NAZWA>101 047 925</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101047925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265471.748505 802756.550744</gml:lowerCorner>
        		<gml:upperCorner>265471.748505 802756.550744</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265471.748505 802756.550744</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 049 033</ms:GML_ID>
        <ms:NAZWA>101 049 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101049033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265480.792954 803729.094410</gml:lowerCorner>
        		<gml:upperCorner>265480.792954 803729.094410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265480.792954 803729.094410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 050 010</ms:GML_ID>
        <ms:NAZWA>101 050 010</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101050010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265558.837000 805448.935000</gml:lowerCorner>
        		<gml:upperCorner>265558.837000 805448.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265558.837000 805448.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 051 727</ms:GML_ID>
        <ms:NAZWA>101 051 727</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101051727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265815.198789 806546.151984</gml:lowerCorner>
        		<gml:upperCorner>265815.198789 806546.151984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265815.198789 806546.151984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 052 856</ms:GML_ID>
        <ms:NAZWA>101 052 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101052856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266499.418000 808210.098000</gml:lowerCorner>
        		<gml:upperCorner>266499.418000 808210.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266499.418000 808210.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 054 673</ms:GML_ID>
        <ms:NAZWA>101 054 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101054673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267084.780000 809169.921000</gml:lowerCorner>
        		<gml:upperCorner>267084.780000 809169.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267084.780000 809169.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 055 797</ms:GML_ID>
        <ms:NAZWA>101 055 797</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101055797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267425.118363 809858.197070</gml:lowerCorner>
        		<gml:upperCorner>267425.118363 809858.197070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267425.118363 809858.197070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 056 566</ms:GML_ID>
        <ms:NAZWA>101 056 566</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101056566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267602.562001 810461.433002</gml:lowerCorner>
        		<gml:upperCorner>267602.562001 810461.433002</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267602.562001 810461.433002</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 057 198</ms:GML_ID>
        <ms:NAZWA>101 057 198</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101057198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273174.273736 695954.062072</gml:lowerCorner>
        		<gml:upperCorner>273174.273736 695954.062072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273174.273736 695954.062072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 031 200</ms:GML_ID>
        <ms:NAZWA>071 031 200</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071031200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274265.555855 695976.990829</gml:lowerCorner>
        		<gml:upperCorner>274265.555855 695976.990829</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274265.555855 695976.990829</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 030 113</ms:GML_ID>
        <ms:NAZWA>071 030 113</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071030113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275541.957000 696264.281000</gml:lowerCorner>
        		<gml:upperCorner>275541.957000 696264.281000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275541.957000 696264.281000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 028 793</ms:GML_ID>
        <ms:NAZWA>071 028 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071028793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272139.648000 696269.703000</gml:lowerCorner>
        		<gml:upperCorner>272139.648000 696269.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272139.648000 696269.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 032 294</ms:GML_ID>
        <ms:NAZWA>071 032 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071032294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276455.946000 696559.212000</gml:lowerCorner>
        		<gml:upperCorner>276455.946000 696559.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276455.946000 696559.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 027 824</ms:GML_ID>
        <ms:NAZWA>071 027 824</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071027824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270813.000000 696791.928000</gml:lowerCorner>
        		<gml:upperCorner>270813.000000 696791.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270813.000000 696791.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 033 717</ms:GML_ID>
        <ms:NAZWA>071 033 717</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071033717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269215.692000 697729.786000</gml:lowerCorner>
        		<gml:upperCorner>269215.692000 697729.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269215.692000 697729.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 035 584</ms:GML_ID>
        <ms:NAZWA>071 035 584</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071035584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268329.418000 698281.471000</gml:lowerCorner>
        		<gml:upperCorner>268329.418000 698281.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268329.418000 698281.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 036 627</ms:GML_ID>
        <ms:NAZWA>071 036 627</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071036627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266821.751000 699219.813000</gml:lowerCorner>
        		<gml:upperCorner>266821.751000 699219.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266821.751000 699219.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 038 404</ms:GML_ID>
        <ms:NAZWA>071 038 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071038404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265434.683000 700094.908000</gml:lowerCorner>
        		<gml:upperCorner>265434.683000 700094.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265434.683000 700094.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 040 046</ms:GML_ID>
        <ms:NAZWA>071 040 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071040046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264821.946852 702184.074659</gml:lowerCorner>
        		<gml:upperCorner>264821.946852 702184.074659</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264821.946852 702184.074659</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 042 201</ms:GML_ID>
        <ms:NAZWA>071 042 201</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071042201</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264668.469000 702626.166000</gml:lowerCorner>
        		<gml:upperCorner>264668.469000 702626.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264668.469000 702626.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 042 720</ms:GML_ID>
        <ms:NAZWA>071 042 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071042720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264456.621000 703050.346000</gml:lowerCorner>
        		<gml:upperCorner>264456.621000 703050.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264456.621000 703050.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 043 195</ms:GML_ID>
        <ms:NAZWA>071 043 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071043195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263942.744609 704047.018519</gml:lowerCorner>
        		<gml:upperCorner>263942.744609 704047.018519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263942.744609 704047.018519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 044 317</ms:GML_ID>
        <ms:NAZWA>071 044 317</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071044317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263480.974000 704808.812000</gml:lowerCorner>
        		<gml:upperCorner>263480.974000 704808.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263480.974000 704808.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 045 213</ms:GML_ID>
        <ms:NAZWA>071 045 213</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071045213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262239.235208 705982.613923</gml:lowerCorner>
        		<gml:upperCorner>262239.235208 705982.613923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262239.235208 705982.613923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 046 925</ms:GML_ID>
        <ms:NAZWA>071 046 925</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071046925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271042.601442 744607.690750</gml:lowerCorner>
        		<gml:upperCorner>271042.601442 744607.690750</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271042.601442 744607.690750</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 152 583</ms:GML_ID>
        <ms:NAZWA>068 152 583</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068152583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270542.000527 744961.007853</gml:lowerCorner>
        		<gml:upperCorner>270542.000527 744961.007853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270542.000527 744961.007853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 153 204</ms:GML_ID>
        <ms:NAZWA>068 153 204</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068153204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270281.213000 745641.746000</gml:lowerCorner>
        		<gml:upperCorner>270281.213000 745641.746000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270281.213000 745641.746000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 153 928</ms:GML_ID>
        <ms:NAZWA>068 153 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068153928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269689.203000 746743.936000</gml:lowerCorner>
        		<gml:upperCorner>269689.203000 746743.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269689.203000 746743.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 155 219</ms:GML_ID>
        <ms:NAZWA>068 155 219</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068155219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268850.570000 746882.814000</gml:lowerCorner>
        		<gml:upperCorner>268850.570000 746882.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268850.570000 746882.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 156 114</ms:GML_ID>
        <ms:NAZWA>068 156 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068156114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269328.794000 746913.384000</gml:lowerCorner>
        		<gml:upperCorner>269328.794000 746913.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269328.794000 746913.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 155 616</ms:GML_ID>
        <ms:NAZWA>068 155 616</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068155616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268210.094000 746967.249000</gml:lowerCorner>
        		<gml:upperCorner>268210.094000 746967.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268210.094000 746967.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 156 793</ms:GML_ID>
        <ms:NAZWA>068 156 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068156793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266844.666000 747649.492000</gml:lowerCorner>
        		<gml:upperCorner>266844.666000 747649.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266844.666000 747649.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 158 320</ms:GML_ID>
        <ms:NAZWA>068 158 320</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068158320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266093.054000 748051.929000</gml:lowerCorner>
        		<gml:upperCorner>266093.054000 748051.929000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266093.054000 748051.929000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 159 175</ms:GML_ID>
        <ms:NAZWA>068 159 175</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068159175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265376.229000 748436.354000</gml:lowerCorner>
        		<gml:upperCorner>265376.229000 748436.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265376.229000 748436.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 159 991</ms:GML_ID>
        <ms:NAZWA>068 159 991</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068159991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262353.539964 750110.071661</gml:lowerCorner>
        		<gml:upperCorner>262353.539964 750110.071661</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262353.539964 750110.071661</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 163 446</ms:GML_ID>
        <ms:NAZWA>068 163 446</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068163446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261526.549927 750626.313344</gml:lowerCorner>
        		<gml:upperCorner>261526.549927 750626.313344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261526.549927 750626.313344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 164 415</ms:GML_ID>
        <ms:NAZWA>068 164 415</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068164415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261213.085000 750811.410000</gml:lowerCorner>
        		<gml:upperCorner>261213.085000 750811.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261213.085000 750811.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 164 779</ms:GML_ID>
        <ms:NAZWA>068 164 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068164779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260262.476000 751391.316000</gml:lowerCorner>
        		<gml:upperCorner>260262.476000 751391.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260262.476000 751391.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 165 892</ms:GML_ID>
        <ms:NAZWA>068 165 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068165892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259670.699000 751752.220000</gml:lowerCorner>
        		<gml:upperCorner>259670.699000 751752.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259670.699000 751752.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 166 585</ms:GML_ID>
        <ms:NAZWA>068 166 585</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068166585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259378.959181 751948.007272</gml:lowerCorner>
        		<gml:upperCorner>259378.959181 751948.007272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259378.959181 751948.007272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 166 937</ms:GML_ID>
        <ms:NAZWA>068 166 937</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068166937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255223.528000 752450.236000</gml:lowerCorner>
        		<gml:upperCorner>255223.528000 752450.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255223.528000 752450.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 171 535</ms:GML_ID>
        <ms:NAZWA>068 171 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068171535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258507.766000 752562.005000</gml:lowerCorner>
        		<gml:upperCorner>258507.766000 752562.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258507.766000 752562.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 168 002</ms:GML_ID>
        <ms:NAZWA>068 168 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068168002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255475.372000 752587.959000</gml:lowerCorner>
        		<gml:upperCorner>255475.372000 752587.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255475.372000 752587.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 171 247</ms:GML_ID>
        <ms:NAZWA>068 171 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068171247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258235.693818 752753.749360</gml:lowerCorner>
        		<gml:upperCorner>258235.693818 752753.749360</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258235.693818 752753.749360</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 168 333</ms:GML_ID>
        <ms:NAZWA>068 168 333</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068168333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257913.955209 787380.981537</gml:lowerCorner>
        		<gml:upperCorner>257913.955209 787380.981537</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257913.955209 787380.981537</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 028 405</ms:GML_ID>
        <ms:NAZWA>101 028 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101028405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258988.891000 787755.019000</gml:lowerCorner>
        		<gml:upperCorner>258988.891000 787755.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258988.891000 787755.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 029 548</ms:GML_ID>
        <ms:NAZWA>101 029 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101029548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280192.939000 674738.816000</gml:lowerCorner>
        		<gml:upperCorner>280192.939000 674738.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280192.939000 674738.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 283 753</ms:GML_ID>
        <ms:NAZWA>025 283 753</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025283753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270198.615250 675239.009911</gml:lowerCorner>
        		<gml:upperCorner>270198.615250 675239.009911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270198.615250 675239.009911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 295 121</ms:GML_ID>
        <ms:NAZWA>025 295 121</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025295121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269912.859000 675636.920000</gml:lowerCorner>
        		<gml:upperCorner>269912.859000 675636.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269912.859000 675636.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 295 612</ms:GML_ID>
        <ms:NAZWA>025 295 612</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025295612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269761.975000 675846.615000</gml:lowerCorner>
        		<gml:upperCorner>269761.975000 675846.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269761.975000 675846.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 295 870</ms:GML_ID>
        <ms:NAZWA>025 295 870</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025295870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267622.793846 677427.073920</gml:lowerCorner>
        		<gml:upperCorner>267622.793846 677427.073920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267622.793846 677427.073920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 298 611</ms:GML_ID>
        <ms:NAZWA>025 298 611</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025298611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267285.707000 677581.020000</gml:lowerCorner>
        		<gml:upperCorner>267285.707000 677581.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267285.707000 677581.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 298 984</ms:GML_ID>
        <ms:NAZWA>025 298 984</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025298984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257711.008166 677968.392445</gml:lowerCorner>
        		<gml:upperCorner>257711.008166 677968.392445</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257711.008166 677968.392445</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 308 923</ms:GML_ID>
        <ms:NAZWA>025 308 923</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025308923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258285.807492 678006.786137</gml:lowerCorner>
        		<gml:upperCorner>258285.807492 678006.786137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258285.807492 678006.786137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 308 341</ms:GML_ID>
        <ms:NAZWA>025 308 341</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025308341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258754.967847 678123.965502</gml:lowerCorner>
        		<gml:upperCorner>258754.967847 678123.965502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258754.967847 678123.965502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 307 856</ms:GML_ID>
        <ms:NAZWA>025 307 856</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025307856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256839.476809 678193.982576</gml:lowerCorner>
        		<gml:upperCorner>256839.476809 678193.982576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256839.476809 678193.982576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 309 826</ms:GML_ID>
        <ms:NAZWA>025 309 826</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025309826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259503.223000 678311.247000</gml:lowerCorner>
        		<gml:upperCorner>259503.223000 678311.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259503.223000 678311.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 307 085</ms:GML_ID>
        <ms:NAZWA>025 307 085</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025307085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259802.360000 678385.942000</gml:lowerCorner>
        		<gml:upperCorner>259802.360000 678385.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259802.360000 678385.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 306 776</ms:GML_ID>
        <ms:NAZWA>025 306 776</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025306776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255208.326790 678392.709930</gml:lowerCorner>
        		<gml:upperCorner>255208.326790 678392.709930</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255208.326790 678392.709930</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 311 470</ms:GML_ID>
        <ms:NAZWA>025 311 470</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025311470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254313.202000 678502.596000</gml:lowerCorner>
        		<gml:upperCorner>254313.202000 678502.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254313.202000 678502.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 312 372</ms:GML_ID>
        <ms:NAZWA>025 312 372</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025312372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260566.798000 678576.436000</gml:lowerCorner>
        		<gml:upperCorner>260566.798000 678576.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260566.798000 678576.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 305 987</ms:GML_ID>
        <ms:NAZWA>025 305 987</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025305987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253364.641185 678618.784222</gml:lowerCorner>
        		<gml:upperCorner>253364.641185 678618.784222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253364.641185 678618.784222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 313 328</ms:GML_ID>
        <ms:NAZWA>025 313 328</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025313328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264659.861441 678688.258924</gml:lowerCorner>
        		<gml:upperCorner>264659.861441 678688.258924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264659.861441 678688.258924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 301 842</ms:GML_ID>
        <ms:NAZWA>025 301 842</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025301842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264106.610000 678733.346000</gml:lowerCorner>
        		<gml:upperCorner>264106.610000 678733.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264106.610000 678733.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 302 400</ms:GML_ID>
        <ms:NAZWA>025 302 400</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025302400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261419.067000 678789.758000</gml:lowerCorner>
        		<gml:upperCorner>261419.067000 678789.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261419.067000 678789.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 305 108</ms:GML_ID>
        <ms:NAZWA>025 305 108</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025305108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263112.943000 678813.935000</gml:lowerCorner>
        		<gml:upperCorner>263112.943000 678813.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263112.943000 678813.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 303 398</ms:GML_ID>
        <ms:NAZWA>025 303 398</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025303398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262104.419000 678895.678000</gml:lowerCorner>
        		<gml:upperCorner>262104.419000 678895.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262104.419000 678895.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 304 409</ms:GML_ID>
        <ms:NAZWA>025 304 409</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025304409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292980.875000 682558.506000</gml:lowerCorner>
        		<gml:upperCorner>292980.875000 682558.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292980.875000 682558.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 267 990</ms:GML_ID>
        <ms:NAZWA>025 267 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025267990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293018.142000 683648.733000</gml:lowerCorner>
        		<gml:upperCorner>293018.142000 683648.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293018.142000 683648.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 266 900</ms:GML_ID>
        <ms:NAZWA>025 266 900</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025266900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293668.521000 685170.490000</gml:lowerCorner>
        		<gml:upperCorner>293668.521000 685170.490000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293668.521000 685170.490000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 265 223</ms:GML_ID>
        <ms:NAZWA>025 265 223</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025265223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294068.533871 691282.106401</gml:lowerCorner>
        		<gml:upperCorner>294068.533871 691282.106401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294068.533871 691282.106401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 005 560</ms:GML_ID>
        <ms:NAZWA>071 005 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071005560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283722.122000 692981.576000</gml:lowerCorner>
        		<gml:upperCorner>283722.122000 692981.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283722.122000 692981.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 018 349</ms:GML_ID>
        <ms:NAZWA>071 018 349</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071018349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282748.524334 693431.028953</gml:lowerCorner>
        		<gml:upperCorner>282748.524334 693431.028953</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282748.524334 693431.028953</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 019 517</ms:GML_ID>
        <ms:NAZWA>071 019 517</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071019517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284606.961167 693625.761976</gml:lowerCorner>
        		<gml:upperCorner>284606.961167 693625.761976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284606.961167 693625.761976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 017 162</ms:GML_ID>
        <ms:NAZWA>071 017 162</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071017162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291421.243000 693830.445000</gml:lowerCorner>
        		<gml:upperCorner>291421.243000 693830.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291421.243000 693830.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 009 259</ms:GML_ID>
        <ms:NAZWA>071 009 259</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071009259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279313.538000 694393.109000</gml:lowerCorner>
        		<gml:upperCorner>279313.538000 694393.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279313.538000 694393.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 023 913</ms:GML_ID>
        <ms:NAZWA>071 023 913</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071023913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290184.080000 694400.823000</gml:lowerCorner>
        		<gml:upperCorner>290184.080000 694400.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290184.080000 694400.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 010 622</ms:GML_ID>
        <ms:NAZWA>071 010 622</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071010622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286880.699254 694580.480482</gml:lowerCorner>
        		<gml:upperCorner>286880.699254 694580.480482</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286880.699254 694580.480482</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 014 047</ms:GML_ID>
        <ms:NAZWA>071 014 047</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071014047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280940.105834 694595.569192</gml:lowerCorner>
        		<gml:upperCorner>280940.105834 694595.569192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280940.105834 694595.569192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 022 220</ms:GML_ID>
        <ms:NAZWA>071 022 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071022220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277807.293000 694899.003000</gml:lowerCorner>
        		<gml:upperCorner>277807.293000 694899.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277807.293000 694899.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 025 521</ms:GML_ID>
        <ms:NAZWA>071 025 521</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071025521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248761.129000 758242.357000</gml:lowerCorner>
        		<gml:upperCorner>248761.129000 758242.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248761.129000 758242.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 202 584</ms:GML_ID>
        <ms:NAZWA>091 202 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091202584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249588.913000 757115.443000</gml:lowerCorner>
        		<gml:upperCorner>249588.913000 757115.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249588.913000 757115.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 201 157</ms:GML_ID>
        <ms:NAZWA>091 201 157</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091201157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250241.226712 751206.010148</gml:lowerCorner>
        		<gml:upperCorner>250241.226712 751206.010148</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250241.226712 751206.010148</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 195 096</ms:GML_ID>
        <ms:NAZWA>091 195 096</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091195096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250437.920000 749966.450000</gml:lowerCorner>
        		<gml:upperCorner>250437.920000 749966.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250437.920000 749966.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 193 816</ms:GML_ID>
        <ms:NAZWA>091 193 816</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091193816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250461.127000 750005.795000</gml:lowerCorner>
        		<gml:upperCorner>250461.127000 750005.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250461.127000 750005.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 176 930</ms:GML_ID>
        <ms:NAZWA>068 176 930</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068176930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250478.677738 752466.933312</gml:lowerCorner>
        		<gml:upperCorner>250478.677738 752466.933312</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250478.677738 752466.933312</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 196 412</ms:GML_ID>
        <ms:NAZWA>091 196 412</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091196412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250624.539000 727078.599000</gml:lowerCorner>
        		<gml:upperCorner>250624.539000 727078.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250624.539000 727078.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 170 566</ms:GML_ID>
        <ms:NAZWA>091 170 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091170566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250899.282000 750085.408000</gml:lowerCorner>
        		<gml:upperCorner>250899.282000 750085.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250899.282000 750085.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 176 486</ms:GML_ID>
        <ms:NAZWA>068 176 486</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068176486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250934.176000 728073.037000</gml:lowerCorner>
        		<gml:upperCorner>250934.176000 728073.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250934.176000 728073.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 171 610</ms:GML_ID>
        <ms:NAZWA>091 171 610</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091171610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250955.303000 728605.157000</gml:lowerCorner>
        		<gml:upperCorner>250955.303000 728605.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250955.303000 728605.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 172 144</ms:GML_ID>
        <ms:NAZWA>091 172 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091172144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250981.025183 749359.569080</gml:lowerCorner>
        		<gml:upperCorner>250981.025183 749359.569080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250981.025183 749359.569080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 193 007</ms:GML_ID>
        <ms:NAZWA>091 193 007</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091193007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251000.719000 729811.040000</gml:lowerCorner>
        		<gml:upperCorner>251000.719000 729811.040000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251000.719000 729811.040000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 173 351</ms:GML_ID>
        <ms:NAZWA>091 173 351</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091173351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251078.928000 731910.062000</gml:lowerCorner>
        		<gml:upperCorner>251078.928000 731910.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251078.928000 731910.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 175 453</ms:GML_ID>
        <ms:NAZWA>091 175 453</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091175453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251304.391000 733710.231000</gml:lowerCorner>
        		<gml:upperCorner>251304.391000 733710.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251304.391000 733710.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 177 269</ms:GML_ID>
        <ms:NAZWA>091 177 269</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091177269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251388.861237 734407.351758</gml:lowerCorner>
        		<gml:upperCorner>251388.861237 734407.351758</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251388.861237 734407.351758</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 177 972</ms:GML_ID>
        <ms:NAZWA>091 177 972</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091177972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251455.731000 735798.663000</gml:lowerCorner>
        		<gml:upperCorner>251455.731000 735798.663000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251455.731000 735798.663000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 179 370</ms:GML_ID>
        <ms:NAZWA>091 179 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091179370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251508.212995 750401.921611</gml:lowerCorner>
        		<gml:upperCorner>251508.212995 750401.921611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251508.212995 750401.921611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 175 785</ms:GML_ID>
        <ms:NAZWA>068 175 785</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068175785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251544.900976 747057.944187</gml:lowerCorner>
        		<gml:upperCorner>251544.900976 747057.944187</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251544.900976 747057.944187</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 190 645</ms:GML_ID>
        <ms:NAZWA>091 190 645</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091190645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251548.932616 737748.414495</gml:lowerCorner>
        		<gml:upperCorner>251548.932616 737748.414495</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251548.932616 737748.414495</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 181 322</ms:GML_ID>
        <ms:NAZWA>091 181 322</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091181322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251571.726931 738230.323420</gml:lowerCorner>
        		<gml:upperCorner>251571.726931 738230.323420</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251571.726931 738230.323420</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 181 803</ms:GML_ID>
        <ms:NAZWA>091 181 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091181803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251581.913000 738448.584000</gml:lowerCorner>
        		<gml:upperCorner>251581.913000 738448.584000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251581.913000 738448.584000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 182 018</ms:GML_ID>
        <ms:NAZWA>091 182 018</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091182018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251597.695000 738778.902000</gml:lowerCorner>
        		<gml:upperCorner>251597.695000 738778.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251597.695000 738778.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 182 354</ms:GML_ID>
        <ms:NAZWA>091 182 354</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091182354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251638.672000 739746.115000</gml:lowerCorner>
        		<gml:upperCorner>251638.672000 739746.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251638.672000 739746.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 183 316</ms:GML_ID>
        <ms:NAZWA>091 183 316</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091183316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251662.548000 745090.786000</gml:lowerCorner>
        		<gml:upperCorner>251662.548000 745090.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251662.548000 745090.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 188 671</ms:GML_ID>
        <ms:NAZWA>091 188 671</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091188671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251689.235000 740811.769000</gml:lowerCorner>
        		<gml:upperCorner>251689.235000 740811.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251689.235000 740811.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 184 388</ms:GML_ID>
        <ms:NAZWA>091 184 388</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091184388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251690.796204 744389.923208</gml:lowerCorner>
        		<gml:upperCorner>251690.796204 744389.923208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251690.796204 744389.923208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 187 972</ms:GML_ID>
        <ms:NAZWA>091 187 972</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091187972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251743.951120 741844.692874</gml:lowerCorner>
        		<gml:upperCorner>251743.951120 741844.692874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251743.951120 741844.692874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 185 423</ms:GML_ID>
        <ms:NAZWA>091 185 423</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091185423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251868.331000 783903.369000</gml:lowerCorner>
        		<gml:upperCorner>251868.331000 783903.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251868.331000 783903.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 021 376</ms:GML_ID>
        <ms:NAZWA>101 021 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101021376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252486.101000 750863.562000</gml:lowerCorner>
        		<gml:upperCorner>252486.101000 750863.562000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252486.101000 750863.562000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 174 706</ms:GML_ID>
        <ms:NAZWA>068 174 706</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068174706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252821.958088 784665.422654</gml:lowerCorner>
        		<gml:upperCorner>252821.958088 784665.422654</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252821.958088 784665.422654</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 022 630</ms:GML_ID>
        <ms:NAZWA>101 022 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101022630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253577.236598 751433.341458</gml:lowerCorner>
        		<gml:upperCorner>253577.236598 751433.341458</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253577.236598 751433.341458</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 173 469</ms:GML_ID>
        <ms:NAZWA>068 173 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068173469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254091.823476 751762.174291</gml:lowerCorner>
        		<gml:upperCorner>254091.823476 751762.174291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254091.823476 751762.174291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 172 861</ms:GML_ID>
        <ms:NAZWA>068 172 861</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068172861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254104.387000 785352.170000</gml:lowerCorner>
        		<gml:upperCorner>254104.387000 785352.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254104.387000 785352.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 024 084</ms:GML_ID>
        <ms:NAZWA>101 024 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101024084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254682.873433 752138.939379</gml:lowerCorner>
        		<gml:upperCorner>254682.873433 752138.939379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254682.873433 752138.939379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 172 159</ms:GML_ID>
        <ms:NAZWA>068 172 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>068172159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248317.535226 714075.305830</gml:lowerCorner>
        		<gml:upperCorner>248317.535226 714075.305830</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248317.535226 714075.305830</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 063 824</ms:GML_ID>
        <ms:NAZWA>071 063 824</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071063824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248542.356264 721164.041133</gml:lowerCorner>
        		<gml:upperCorner>248542.356264 721164.041133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248542.356264 721164.041133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 164 295</ms:GML_ID>
        <ms:NAZWA>091 164 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091164295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248897.235148 722167.375624</gml:lowerCorner>
        		<gml:upperCorner>248897.235148 722167.375624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248897.235148 722167.375624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 165 358</ms:GML_ID>
        <ms:NAZWA>091 165 358</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091165358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248981.437000 713870.490000</gml:lowerCorner>
        		<gml:upperCorner>248981.437000 713870.490000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248981.437000 713870.490000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 063 130</ms:GML_ID>
        <ms:NAZWA>071 063 130</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071063130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249202.433000 713131.132000</gml:lowerCorner>
        		<gml:upperCorner>249202.433000 713131.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249202.433000 713131.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 153 352</ms:GML_ID>
        <ms:NAZWA>091 153 352</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091153352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249240.819000 723196.947000</gml:lowerCorner>
        		<gml:upperCorner>249240.819000 723196.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249240.819000 723196.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 166 432</ms:GML_ID>
        <ms:NAZWA>091 166 432</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091166432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249572.147000 724105.231000</gml:lowerCorner>
        		<gml:upperCorner>249572.147000 724105.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249572.147000 724105.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 167 411</ms:GML_ID>
        <ms:NAZWA>091 167 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091167411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249723.909366 713643.442771</gml:lowerCorner>
        		<gml:upperCorner>249723.909366 713643.442771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249723.909366 713643.442771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 062 354</ms:GML_ID>
        <ms:NAZWA>071 062 354</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071062354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250056.357000 725473.762000</gml:lowerCorner>
        		<gml:upperCorner>250056.357000 725473.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250056.357000 725473.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 168 863</ms:GML_ID>
        <ms:NAZWA>091 168 863</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091168863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250356.272000 713466.982000</gml:lowerCorner>
        		<gml:upperCorner>250356.272000 713466.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250356.272000 713466.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 061 696</ms:GML_ID>
        <ms:NAZWA>071 061 696</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071061696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250951.544046 713300.899360</gml:lowerCorner>
        		<gml:upperCorner>250951.544046 713300.899360</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250951.544046 713300.899360</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 061 079</ms:GML_ID>
        <ms:NAZWA>071 061 079</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071061079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252116.582000 712942.663000</gml:lowerCorner>
        		<gml:upperCorner>252116.582000 712942.663000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252116.582000 712942.663000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 059 857</ms:GML_ID>
        <ms:NAZWA>071 059 857</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071059857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253849.180297 713368.749136</gml:lowerCorner>
        		<gml:upperCorner>253849.180297 713368.749136</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253849.180297 713368.749136</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.626 002 513</ms:GML_ID>
        <ms:NAZWA>626 002 513</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>626002513</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253956.206052 714284.238249</gml:lowerCorner>
        		<gml:upperCorner>253956.206052 714284.238249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253956.206052 714284.238249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.626 003 442</ms:GML_ID>
        <ms:NAZWA>626 003 442</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>626003442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254030.157807 714880.775576</gml:lowerCorner>
        		<gml:upperCorner>254030.157807 714880.775576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254030.157807 714880.775576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.626 004 043</ms:GML_ID>
        <ms:NAZWA>626 004 043</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>626004043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254100.491000 712190.555000</gml:lowerCorner>
        		<gml:upperCorner>254100.491000 712190.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254100.491000 712190.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 057 717</ms:GML_ID>
        <ms:NAZWA>071 057 717</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071057717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254170.827535 715741.221874</gml:lowerCorner>
        		<gml:upperCorner>254170.827535 715741.221874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254170.827535 715741.221874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.626 004 924</ms:GML_ID>
        <ms:NAZWA>626 004 924</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>626004924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255265.796695 711985.876102</gml:lowerCorner>
        		<gml:upperCorner>255265.796695 711985.876102</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255265.796695 711985.876102</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 056 534</ms:GML_ID>
        <ms:NAZWA>071 056 534</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071056534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256395.348325 711787.568334</gml:lowerCorner>
        		<gml:upperCorner>256395.348325 711787.568334</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256395.348325 711787.568334</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 055 387</ms:GML_ID>
        <ms:NAZWA>071 055 387</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071055387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257801.352952 711148.856505</gml:lowerCorner>
        		<gml:upperCorner>257801.352952 711148.856505</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257801.352952 711148.856505</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 053 810</ms:GML_ID>
        <ms:NAZWA>071 053 810</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>071053810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243517.807000 640761.247000</gml:lowerCorner>
        		<gml:upperCorner>243517.807000 640761.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243517.807000 640761.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 005 268</ms:GML_ID>
        <ms:NAZWA>115 005 268</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115005268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244376.063107 640378.298426</gml:lowerCorner>
        		<gml:upperCorner>244376.063107 640378.298426</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244376.063107 640378.298426</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 006 209</ms:GML_ID>
        <ms:NAZWA>115 006 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115006209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245279.989958 640065.900453</gml:lowerCorner>
        		<gml:upperCorner>245279.989958 640065.900453</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245279.989958 640065.900453</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 007 170</ms:GML_ID>
        <ms:NAZWA>115 007 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115007170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246010.864304 656600.242007</gml:lowerCorner>
        		<gml:upperCorner>246010.864304 656600.242007</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246010.864304 656600.242007</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 094 355</ms:GML_ID>
        <ms:NAZWA>091 094 355</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091094355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246274.185553 639854.732842</gml:lowerCorner>
        		<gml:upperCorner>246274.185553 639854.732842</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246274.185553 639854.732842</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 008 287</ms:GML_ID>
        <ms:NAZWA>115 008 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115008287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246640.686000 659171.973000</gml:lowerCorner>
        		<gml:upperCorner>246640.686000 659171.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246640.686000 659171.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 097 035</ms:GML_ID>
        <ms:NAZWA>091 097 035</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091097035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246814.972863 639739.516251</gml:lowerCorner>
        		<gml:upperCorner>246814.972863 639739.516251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246814.972863 639739.516251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 008 740</ms:GML_ID>
        <ms:NAZWA>115 008 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115008740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246987.867616 639688.553512</gml:lowerCorner>
        		<gml:upperCorner>246987.867616 639688.553512</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246987.867616 639688.553512</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 008 920</ms:GML_ID>
        <ms:NAZWA>115 008 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115008920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247277.435000 639513.730000</gml:lowerCorner>
        		<gml:upperCorner>247277.435000 639513.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247277.435000 639513.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 009 261</ms:GML_ID>
        <ms:NAZWA>115 009 261</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115009261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247516.109987 639324.166063</gml:lowerCorner>
        		<gml:upperCorner>247516.109987 639324.166063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247516.109987 639324.166063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 009 567</ms:GML_ID>
        <ms:NAZWA>115 009 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115009567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247679.371590 639194.466087</gml:lowerCorner>
        		<gml:upperCorner>247679.371590 639194.466087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247679.371590 639194.466087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 009 774</ms:GML_ID>
        <ms:NAZWA>115 009 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115009774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255023.716000 639204.086000</gml:lowerCorner>
        		<gml:upperCorner>255023.716000 639204.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255023.716000 639204.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 020 643</ms:GML_ID>
        <ms:NAZWA>115 020 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115020643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255179.889117 639497.942755</gml:lowerCorner>
        		<gml:upperCorner>255179.889117 639497.942755</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255179.889117 639497.942755</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 020 983</ms:GML_ID>
        <ms:NAZWA>115 020 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115020983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255517.226569 639768.683819</gml:lowerCorner>
        		<gml:upperCorner>255517.226569 639768.683819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255517.226569 639768.683819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 021 414</ms:GML_ID>
        <ms:NAZWA>115 021 414</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115021414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271724.190385 673170.259203</gml:lowerCorner>
        		<gml:upperCorner>271724.190385 673170.259203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271724.190385 673170.259203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 292 545</ms:GML_ID>
        <ms:NAZWA>025 292 545</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025292545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273049.784802 672945.494217</gml:lowerCorner>
        		<gml:upperCorner>273049.784802 672945.494217</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273049.784802 672945.494217</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 291 185</ms:GML_ID>
        <ms:NAZWA>025 291 185</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025291185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274297.681540 673120.738057</gml:lowerCorner>
        		<gml:upperCorner>274297.681540 673120.738057</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274297.681540 673120.738057</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 289 917</ms:GML_ID>
        <ms:NAZWA>025 289 917</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025289917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276474.015838 673821.081178</gml:lowerCorner>
        		<gml:upperCorner>276474.015838 673821.081178</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276474.015838 673821.081178</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 287 629</ms:GML_ID>
        <ms:NAZWA>025 287 629</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025287629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278592.623573 674580.550830</gml:lowerCorner>
        		<gml:upperCorner>278592.623573 674580.550830</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278592.623573 674580.550830</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 285 361</ms:GML_ID>
        <ms:NAZWA>025 285 361</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025285361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238678.584000 709835.541000</gml:lowerCorner>
        		<gml:upperCorner>238678.584000 709835.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238678.584000 709835.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 009 776</ms:GML_ID>
        <ms:NAZWA>106 009 776</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106009776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239878.530081 710548.614534</gml:lowerCorner>
        		<gml:upperCorner>239878.530081 710548.614534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239878.530081 710548.614534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 008 371</ms:GML_ID>
        <ms:NAZWA>106 008 371</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106008371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240122.370000 710665.459000</gml:lowerCorner>
        		<gml:upperCorner>240122.370000 710665.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240122.370000 710665.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 008 100</ms:GML_ID>
        <ms:NAZWA>106 008 100</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106008100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240478.514000 710879.643000</gml:lowerCorner>
        		<gml:upperCorner>240478.514000 710879.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240478.514000 710879.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 007 679</ms:GML_ID>
        <ms:NAZWA>106 007 679</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106007679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241870.761000 711872.871000</gml:lowerCorner>
        		<gml:upperCorner>241870.761000 711872.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241870.761000 711872.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 005 916</ms:GML_ID>
        <ms:NAZWA>106 005 916</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106005916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242664.939829 712601.654680</gml:lowerCorner>
        		<gml:upperCorner>242664.939829 712601.654680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242664.939829 712601.654680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 004 836</ms:GML_ID>
        <ms:NAZWA>106 004 836</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106004836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243611.623771 713138.183233</gml:lowerCorner>
        		<gml:upperCorner>243611.623771 713138.183233</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243611.623771 713138.183233</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 003 725</ms:GML_ID>
        <ms:NAZWA>106 003 725</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106003725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243970.540797 713415.357619</gml:lowerCorner>
        		<gml:upperCorner>243970.540797 713415.357619</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243970.540797 713415.357619</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 003 263</ms:GML_ID>
        <ms:NAZWA>106 003 263</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106003263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244316.792154 713655.781086</gml:lowerCorner>
        		<gml:upperCorner>244316.792154 713655.781086</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244316.792154 713655.781086</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 002 850</ms:GML_ID>
        <ms:NAZWA>106 002 850</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106002850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244636.802923 713769.053128</gml:lowerCorner>
        		<gml:upperCorner>244636.802923 713769.053128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244636.802923 713769.053128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 002 506</ms:GML_ID>
        <ms:NAZWA>106 002 506</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106002506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245906.005000 714123.495000</gml:lowerCorner>
        		<gml:upperCorner>245906.005000 714123.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245906.005000 714123.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 001 187</ms:GML_ID>
        <ms:NAZWA>106 001 187</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106001187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246094.327000 714400.364000</gml:lowerCorner>
        		<gml:upperCorner>246094.327000 714400.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246094.327000 714400.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 000 839</ms:GML_ID>
        <ms:NAZWA>106 000 839</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106000839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246123.713000 714363.874000</gml:lowerCorner>
        		<gml:upperCorner>246123.713000 714363.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246123.713000 714363.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.611 000 329</ms:GML_ID>
        <ms:NAZWA>611 000 329</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>611000329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246317.620907 714417.465713</gml:lowerCorner>
        		<gml:upperCorner>246317.620907 714417.465713</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246317.620907 714417.465713</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 156 655</ms:GML_ID>
        <ms:NAZWA>091 156 655</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091156655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247338.374030 717760.286222</gml:lowerCorner>
        		<gml:upperCorner>247338.374030 717760.286222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247338.374030 717760.286222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 160 681</ms:GML_ID>
        <ms:NAZWA>091 160 681</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091160681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247408.529111 716723.991753</gml:lowerCorner>
        		<gml:upperCorner>247408.529111 716723.991753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247408.529111 716723.991753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 159 910</ms:GML_ID>
        <ms:NAZWA>091 159 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091159910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247658.748228 716744.857161</gml:lowerCorner>
        		<gml:upperCorner>247658.748228 716744.857161</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247658.748228 716744.857161</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 159 900</ms:GML_ID>
        <ms:NAZWA>091 159 900</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091159900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247715.138462 718825.286768</gml:lowerCorner>
        		<gml:upperCorner>247715.138462 718825.286768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247715.138462 718825.286768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 161 814</ms:GML_ID>
        <ms:NAZWA>091 161 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091161814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247985.709574 719501.689045</gml:lowerCorner>
        		<gml:upperCorner>247985.709574 719501.689045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247985.709574 719501.689045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 162 551</ms:GML_ID>
        <ms:NAZWA>091 162 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091162551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248151.304253 720058.493004</gml:lowerCorner>
        		<gml:upperCorner>248151.304253 720058.493004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248151.304253 720058.493004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 163 120</ms:GML_ID>
        <ms:NAZWA>091 163 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091163120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231688.376914 702673.369969</gml:lowerCorner>
        		<gml:upperCorner>231688.376914 702673.369969</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231688.376914 702673.369969</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 023 736</ms:GML_ID>
        <ms:NAZWA>106 023 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106023736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227688.142501 702687.315636</gml:lowerCorner>
        		<gml:upperCorner>227688.142501 702687.315636</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227688.142501 702687.315636</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 028 012</ms:GML_ID>
        <ms:NAZWA>106 028 012</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106028012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234162.263000 702799.771000</gml:lowerCorner>
        		<gml:upperCorner>234162.263000 702799.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234162.263000 702799.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 020 766</ms:GML_ID>
        <ms:NAZWA>106 020 766</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106020766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230433.578465 703158.378226</gml:lowerCorner>
        		<gml:upperCorner>230433.578465 703158.378226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230433.578465 703158.378226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 025 128</ms:GML_ID>
        <ms:NAZWA>106 025 128</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106025128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230063.470794 703213.690520</gml:lowerCorner>
        		<gml:upperCorner>230063.470794 703213.690520</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230063.470794 703213.690520</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 025 503</ms:GML_ID>
        <ms:NAZWA>106 025 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106025503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229285.237000 703214.649000</gml:lowerCorner>
        		<gml:upperCorner>229285.237000 703214.649000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229285.237000 703214.649000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 026 292</ms:GML_ID>
        <ms:NAZWA>106 026 292</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106026292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233993.834000 703942.498000</gml:lowerCorner>
        		<gml:upperCorner>233993.834000 703942.498000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233993.834000 703942.498000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 019 576</ms:GML_ID>
        <ms:NAZWA>106 019 576</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106019576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233841.259482 704298.884438</gml:lowerCorner>
        		<gml:upperCorner>233841.259482 704298.884438</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233841.259482 704298.884438</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 019 188</ms:GML_ID>
        <ms:NAZWA>106 019 188</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106019188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233621.492000 704808.762000</gml:lowerCorner>
        		<gml:upperCorner>233621.492000 704808.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233621.492000 704808.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 018 634</ms:GML_ID>
        <ms:NAZWA>106 018 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106018634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233569.035000 705951.208000</gml:lowerCorner>
        		<gml:upperCorner>233569.035000 705951.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233569.035000 705951.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 017 453</ms:GML_ID>
        <ms:NAZWA>106 017 453</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106017453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233621.914000 706183.926000</gml:lowerCorner>
        		<gml:upperCorner>233621.914000 706183.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233621.914000 706183.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 017 215</ms:GML_ID>
        <ms:NAZWA>106 017 215</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106017215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233755.673000 706747.143000</gml:lowerCorner>
        		<gml:upperCorner>233755.673000 706747.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233755.673000 706747.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 016 635</ms:GML_ID>
        <ms:NAZWA>106 016 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106016635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233698.624897 707415.775971</gml:lowerCorner>
        		<gml:upperCorner>233698.624897 707415.775971</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233698.624897 707415.775971</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 015 926</ms:GML_ID>
        <ms:NAZWA>106 015 926</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106015926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233695.000553 707967.203485</gml:lowerCorner>
        		<gml:upperCorner>233695.000553 707967.203485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233695.000553 707967.203485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 015 373</ms:GML_ID>
        <ms:NAZWA>106 015 373</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106015373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234282.341000 708578.687000</gml:lowerCorner>
        		<gml:upperCorner>234282.341000 708578.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234282.341000 708578.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 014 509</ms:GML_ID>
        <ms:NAZWA>106 014 509</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106014509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234977.701000 708887.429000</gml:lowerCorner>
        		<gml:upperCorner>234977.701000 708887.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234977.701000 708887.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 013 745</ms:GML_ID>
        <ms:NAZWA>106 013 745</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106013745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235603.047000 709005.092000</gml:lowerCorner>
        		<gml:upperCorner>235603.047000 709005.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235603.047000 709005.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 013 089</ms:GML_ID>
        <ms:NAZWA>106 013 089</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106013089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235284.676000 709014.456000</gml:lowerCorner>
        		<gml:upperCorner>235284.676000 709014.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235284.676000 709014.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 013 409</ms:GML_ID>
        <ms:NAZWA>106 013 409</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106013409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236779.911000 709465.049000</gml:lowerCorner>
        		<gml:upperCorner>236779.911000 709465.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236779.911000 709465.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 011 825</ms:GML_ID>
        <ms:NAZWA>106 011 825</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106011825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241970.786000 766917.170000</gml:lowerCorner>
        		<gml:upperCorner>241970.786000 766917.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241970.786000 766917.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 213 930</ms:GML_ID>
        <ms:NAZWA>091 213 930</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091213930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242040.581165 767018.150904</gml:lowerCorner>
        		<gml:upperCorner>242040.581165 767018.150904</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242040.581165 767018.150904</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 000 678</ms:GML_ID>
        <ms:NAZWA>101 000 678</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101000678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239819.972000 769151.897000</gml:lowerCorner>
        		<gml:upperCorner>239819.972000 769151.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239819.972000 769151.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 217 047</ms:GML_ID>
        <ms:NAZWA>091 217 047</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091217047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245044.533000 769779.705000</gml:lowerCorner>
        		<gml:upperCorner>245044.533000 769779.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245044.533000 769779.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 005 082</ms:GML_ID>
        <ms:NAZWA>101 005 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101005082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246270.839000 771022.014000</gml:lowerCorner>
        		<gml:upperCorner>246270.839000 771022.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246270.839000 771022.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 006 827</ms:GML_ID>
        <ms:NAZWA>101 006 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101006827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238302.784000 772314.576000</gml:lowerCorner>
        		<gml:upperCorner>238302.784000 772314.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238302.784000 772314.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 220 565</ms:GML_ID>
        <ms:NAZWA>091 220 565</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091220565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248199.448000 772975.757000</gml:lowerCorner>
        		<gml:upperCorner>248199.448000 772975.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248199.448000 772975.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 009 572</ms:GML_ID>
        <ms:NAZWA>101 009 572</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101009572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249044.932000 774195.661000</gml:lowerCorner>
        		<gml:upperCorner>249044.932000 774195.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249044.932000 774195.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 011 071</ms:GML_ID>
        <ms:NAZWA>101 011 071</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101011071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237450.846168 774262.168275</gml:lowerCorner>
        		<gml:upperCorner>237450.846168 774262.168275</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237450.846168 774262.168275</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 222 690</ms:GML_ID>
        <ms:NAZWA>091 222 690</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091222690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226418.790189 774590.734369</gml:lowerCorner>
        		<gml:upperCorner>226418.790189 774590.734369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226418.790189 774590.734369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.119 002 705</ms:GML_ID>
        <ms:NAZWA>119 002 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>119002705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236004.110000 775468.334000</gml:lowerCorner>
        		<gml:upperCorner>236004.110000 775468.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236004.110000 775468.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 224 699</ms:GML_ID>
        <ms:NAZWA>091 224 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091224699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234926.983000 775844.511000</gml:lowerCorner>
        		<gml:upperCorner>234926.983000 775844.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234926.983000 775844.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 225 839</ms:GML_ID>
        <ms:NAZWA>091 225 839</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091225839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249602.480000 775929.363000</gml:lowerCorner>
        		<gml:upperCorner>249602.480000 775929.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249602.480000 775929.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 012 919</ms:GML_ID>
        <ms:NAZWA>101 012 919</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101012919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233599.974000 776307.976000</gml:lowerCorner>
        		<gml:upperCorner>233599.974000 776307.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233599.974000 776307.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 227 244</ms:GML_ID>
        <ms:NAZWA>091 227 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091227244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233037.622156 776504.278700</gml:lowerCorner>
        		<gml:upperCorner>233037.622156 776504.278700</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233037.622156 776504.278700</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 227 833</ms:GML_ID>
        <ms:NAZWA>091 227 833</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091227833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232768.918000 776598.396000</gml:lowerCorner>
        		<gml:upperCorner>232768.918000 776598.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232768.918000 776598.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 228 118</ms:GML_ID>
        <ms:NAZWA>091 228 118</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091228118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227388.395000 776654.104000</gml:lowerCorner>
        		<gml:upperCorner>227388.395000 776654.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227388.395000 776654.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 233 775</ms:GML_ID>
        <ms:NAZWA>091 233 775</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091233775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228867.854000 777107.501000</gml:lowerCorner>
        		<gml:upperCorner>228867.854000 777107.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228867.854000 777107.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 232 217</ms:GML_ID>
        <ms:NAZWA>091 232 217</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091232217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230760.078000 777300.319000</gml:lowerCorner>
        		<gml:upperCorner>230760.078000 777300.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230760.078000 777300.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 230 247</ms:GML_ID>
        <ms:NAZWA>091 230 247</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091230247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249784.638488 777573.049700</gml:lowerCorner>
        		<gml:upperCorner>249784.638488 777573.049700</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249784.638488 777573.049700</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 014 573</ms:GML_ID>
        <ms:NAZWA>101 014 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101014573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250006.601057 779570.426133</gml:lowerCorner>
        		<gml:upperCorner>250006.601057 779570.426133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250006.601057 779570.426133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 016 581</ms:GML_ID>
        <ms:NAZWA>101 016 581</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101016581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250054.988000 780006.896000</gml:lowerCorner>
        		<gml:upperCorner>250054.988000 780006.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250054.988000 780006.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 017 023</ms:GML_ID>
        <ms:NAZWA>101 017 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101017023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250119.728000 780588.889000</gml:lowerCorner>
        		<gml:upperCorner>250119.728000 780588.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250119.728000 780588.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 017 607</ms:GML_ID>
        <ms:NAZWA>101 017 607</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101017607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250228.888000 781041.397000</gml:lowerCorner>
        		<gml:upperCorner>250228.888000 781041.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250228.888000 781041.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 018 077</ms:GML_ID>
        <ms:NAZWA>101 018 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101018077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250814.453839 782064.008801</gml:lowerCorner>
        		<gml:upperCorner>250814.453839 782064.008801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250814.453839 782064.008801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.101 019 255</ms:GML_ID>
        <ms:NAZWA>101 019 255</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>101019255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225890.214000 692830.465000</gml:lowerCorner>
        		<gml:upperCorner>225890.214000 692830.465000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225890.214000 692830.465000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 039 794</ms:GML_ID>
        <ms:NAZWA>106 039 794</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106039794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226064.258000 693619.976000</gml:lowerCorner>
        		<gml:upperCorner>226064.258000 693619.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226064.258000 693619.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 038 977</ms:GML_ID>
        <ms:NAZWA>106 038 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106038977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226462.405000 694301.476000</gml:lowerCorner>
        		<gml:upperCorner>226462.405000 694301.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226462.405000 694301.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 038 187</ms:GML_ID>
        <ms:NAZWA>106 038 187</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106038187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226627.710000 694658.792000</gml:lowerCorner>
        		<gml:upperCorner>226627.710000 694658.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226627.710000 694658.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 037 793</ms:GML_ID>
        <ms:NAZWA>106 037 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106037793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226681.779000 695298.037000</gml:lowerCorner>
        		<gml:upperCorner>226681.779000 695298.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226681.779000 695298.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 037 140</ms:GML_ID>
        <ms:NAZWA>106 037 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106037140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226601.847381 695615.766720</gml:lowerCorner>
        		<gml:upperCorner>226601.847381 695615.766720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226601.847381 695615.766720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 036 813</ms:GML_ID>
        <ms:NAZWA>106 036 813</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106036813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226501.400333 696026.022883</gml:lowerCorner>
        		<gml:upperCorner>226501.400333 696026.022883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226501.400333 696026.022883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 036 390</ms:GML_ID>
        <ms:NAZWA>106 036 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106036390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226395.312000 697235.573000</gml:lowerCorner>
        		<gml:upperCorner>226395.312000 697235.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226395.312000 697235.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 035 161</ms:GML_ID>
        <ms:NAZWA>106 035 161</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106035161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226214.003000 697791.275000</gml:lowerCorner>
        		<gml:upperCorner>226214.003000 697791.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226214.003000 697791.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 034 577</ms:GML_ID>
        <ms:NAZWA>106 034 577</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106034577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226106.302000 698654.425000</gml:lowerCorner>
        		<gml:upperCorner>226106.302000 698654.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226106.302000 698654.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 033 708</ms:GML_ID>
        <ms:NAZWA>106 033 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106033708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226060.259000 699169.825000</gml:lowerCorner>
        		<gml:upperCorner>226060.259000 699169.825000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226060.259000 699169.825000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 033 189</ms:GML_ID>
        <ms:NAZWA>106 033 189</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106033189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226143.872000 700702.093000</gml:lowerCorner>
        		<gml:upperCorner>226143.872000 700702.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226143.872000 700702.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 031 581</ms:GML_ID>
        <ms:NAZWA>106 031 581</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106031581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226200.082159 700915.780251</gml:lowerCorner>
        		<gml:upperCorner>226200.082159 700915.780251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226200.082159 700915.780251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 031 357</ms:GML_ID>
        <ms:NAZWA>106 031 357</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106031357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226185.061000 701722.067000</gml:lowerCorner>
        		<gml:upperCorner>226185.061000 701722.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226185.061000 701722.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 030 550</ms:GML_ID>
        <ms:NAZWA>106 030 550</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106030550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232395.302076 702288.798985</gml:lowerCorner>
        		<gml:upperCorner>232395.302076 702288.798985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232395.302076 702288.798985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 022 931</ms:GML_ID>
        <ms:NAZWA>106 022 931</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106022931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226047.195035 702376.128119</gml:lowerCorner>
        		<gml:upperCorner>226047.195035 702376.128119</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226047.195035 702376.128119</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 029 764</ms:GML_ID>
        <ms:NAZWA>106 029 764</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106029764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226885.795437 702376.649275</gml:lowerCorner>
        		<gml:upperCorner>226885.795437 702376.649275</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226885.795437 702376.649275</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 028 885</ms:GML_ID>
        <ms:NAZWA>106 028 885</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106028885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227047.781000 702394.265000</gml:lowerCorner>
        		<gml:upperCorner>227047.781000 702394.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227047.781000 702394.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 028 720</ms:GML_ID>
        <ms:NAZWA>106 028 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106028720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219799.168000 772723.666000</gml:lowerCorner>
        		<gml:upperCorner>219799.168000 772723.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219799.168000 772723.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 245 327</ms:GML_ID>
        <ms:NAZWA>091 245 327</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091245327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219730.290604 772862.003202</gml:lowerCorner>
        		<gml:upperCorner>219730.290604 772862.003202</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219730.290604 772862.003202</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 001 158</ms:GML_ID>
        <ms:NAZWA>102 001 158</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102001158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219733.162000 772946.001000</gml:lowerCorner>
        		<gml:upperCorner>219733.162000 772946.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219733.162000 772946.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.615 000 244</ms:GML_ID>
        <ms:NAZWA>615 000 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>615000244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218847.943721 773295.486324</gml:lowerCorner>
        		<gml:upperCorner>218847.943721 773295.486324</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218847.943721 773295.486324</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 002 126</ms:GML_ID>
        <ms:NAZWA>102 002 126</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102002126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219975.976000 773814.572000</gml:lowerCorner>
        		<gml:upperCorner>219975.976000 773814.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219975.976000 773814.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 246 433</ms:GML_ID>
        <ms:NAZWA>091 246 433</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091246433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223148.996091 773885.886469</gml:lowerCorner>
        		<gml:upperCorner>223148.996091 773885.886469</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223148.996091 773885.886469</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 239 083</ms:GML_ID>
        <ms:NAZWA>091 239 083</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091239083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223635.334000 774316.249000</gml:lowerCorner>
        		<gml:upperCorner>223635.334000 774316.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223635.334000 774316.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 238 397</ms:GML_ID>
        <ms:NAZWA>091 238 397</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091238397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224970.633556 774626.100531</gml:lowerCorner>
        		<gml:upperCorner>224970.633556 774626.100531</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224970.633556 774626.100531</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.119 001 255</ms:GML_ID>
        <ms:NAZWA>119 001 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>119001255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224003.165000 774926.308000</gml:lowerCorner>
        		<gml:upperCorner>224003.165000 774926.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224003.165000 774926.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.125 000 350</ms:GML_ID>
        <ms:NAZWA>125 000 350</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>125000350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224229.729000 775259.323000</gml:lowerCorner>
        		<gml:upperCorner>224229.729000 775259.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224229.729000 775259.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.119 000 140</ms:GML_ID>
        <ms:NAZWA>119 000 140</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>119000140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219984.695000 775350.544000</gml:lowerCorner>
        		<gml:upperCorner>219984.695000 775350.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219984.695000 775350.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 247 967</ms:GML_ID>
        <ms:NAZWA>091 247 967</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091247967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224278.928402 775361.580301</gml:lowerCorner>
        		<gml:upperCorner>224278.928402 775361.580301</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224278.928402 775361.580301</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 237 156</ms:GML_ID>
        <ms:NAZWA>091 237 156</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091237156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224603.098763 775754.130639</gml:lowerCorner>
        		<gml:upperCorner>224603.098763 775754.130639</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224603.098763 775754.130639</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.614 000 183</ms:GML_ID>
        <ms:NAZWA>614 000 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>614000183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218061.677064 775991.355921</gml:lowerCorner>
        		<gml:upperCorner>218061.677064 775991.355921</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218061.677064 775991.355921</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.120 002 276</ms:GML_ID>
        <ms:NAZWA>120 002 276</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>120002276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225033.452739 776008.925721</gml:lowerCorner>
        		<gml:upperCorner>225033.452739 776008.925721</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225033.452739 776008.925721</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.614 000 315</ms:GML_ID>
        <ms:NAZWA>614 000 315</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>614000315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220022.977000 776126.193000</gml:lowerCorner>
        		<gml:upperCorner>220022.977000 776126.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220022.977000 776126.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.120 000 215</ms:GML_ID>
        <ms:NAZWA>120 000 215</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>120000215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220652.769000 776234.496000</gml:lowerCorner>
        		<gml:upperCorner>220652.769000 776234.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220652.769000 776234.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.613 004 127</ms:GML_ID>
        <ms:NAZWA>613 004 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>613004127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220051.377000 776441.015000</gml:lowerCorner>
        		<gml:upperCorner>220051.377000 776441.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220051.377000 776441.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.123 000 670</ms:GML_ID>
        <ms:NAZWA>123 000 670</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>123000670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220211.547000 778933.722000</gml:lowerCorner>
        		<gml:upperCorner>220211.547000 778933.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220211.547000 778933.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 251 573</ms:GML_ID>
        <ms:NAZWA>091 251 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091251573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221027.667463 779587.306152</gml:lowerCorner>
        		<gml:upperCorner>221027.667463 779587.306152</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221027.667463 779587.306152</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.092 008 177</ms:GML_ID>
        <ms:NAZWA>092 008 177</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>092008177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221374.105357 781237.158322</gml:lowerCorner>
        		<gml:upperCorner>221374.105357 781237.158322</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221374.105357 781237.158322</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 254 171</ms:GML_ID>
        <ms:NAZWA>091 254 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091254171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223061.221789 781328.538493</gml:lowerCorner>
        		<gml:upperCorner>223061.221789 781328.538493</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223061.221789 781328.538493</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.121 001 737</ms:GML_ID>
        <ms:NAZWA>121 001 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>121001737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216041.981685 642139.945762</gml:lowerCorner>
        		<gml:upperCorner>216041.981685 642139.945762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216041.981685 642139.945762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 036 645</ms:GML_ID>
        <ms:NAZWA>096 036 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096036645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217914.339000 641531.966000</gml:lowerCorner>
        		<gml:upperCorner>217914.339000 641531.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217914.339000 641531.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 034 559</ms:GML_ID>
        <ms:NAZWA>096 034 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096034559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219723.456000 640754.053000</gml:lowerCorner>
        		<gml:upperCorner>219723.456000 640754.053000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219723.456000 640754.053000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 032 518</ms:GML_ID>
        <ms:NAZWA>096 032 518</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096032518</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220663.294000 641086.795000</gml:lowerCorner>
        		<gml:upperCorner>220663.294000 641086.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220663.294000 641086.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 031 519</ms:GML_ID>
        <ms:NAZWA>096 031 519</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096031519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220741.515179 641115.826273</gml:lowerCorner>
        		<gml:upperCorner>220741.515179 641115.826273</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220741.515179 641115.826273</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 031 436</ms:GML_ID>
        <ms:NAZWA>096 031 436</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096031436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221011.466000 641510.669000</gml:lowerCorner>
        		<gml:upperCorner>221011.466000 641510.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221011.466000 641510.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 030 939</ms:GML_ID>
        <ms:NAZWA>096 030 939</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096030939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221248.340463 642031.220598</gml:lowerCorner>
        		<gml:upperCorner>221248.340463 642031.220598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221248.340463 642031.220598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 030 363</ms:GML_ID>
        <ms:NAZWA>096 030 363</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096030363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222421.637000 643504.132000</gml:lowerCorner>
        		<gml:upperCorner>222421.637000 643504.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222421.637000 643504.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 028 181</ms:GML_ID>
        <ms:NAZWA>096 028 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096028181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223626.732000 645356.941000</gml:lowerCorner>
        		<gml:upperCorner>223626.732000 645356.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223626.732000 645356.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 025 596</ms:GML_ID>
        <ms:NAZWA>096 025 596</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096025596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223919.229539 646269.454366</gml:lowerCorner>
        		<gml:upperCorner>223919.229539 646269.454366</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223919.229539 646269.454366</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 024 591</ms:GML_ID>
        <ms:NAZWA>096 024 591</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096024591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224961.220000 647033.147000</gml:lowerCorner>
        		<gml:upperCorner>224961.220000 647033.147000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224961.220000 647033.147000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 023 257</ms:GML_ID>
        <ms:NAZWA>096 023 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096023257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225921.736334 647458.107986</gml:lowerCorner>
        		<gml:upperCorner>225921.736334 647458.107986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225921.736334 647458.107986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 022 197</ms:GML_ID>
        <ms:NAZWA>096 022 197</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096022197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227705.511611 646651.312440</gml:lowerCorner>
        		<gml:upperCorner>227705.511611 646651.312440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227705.511611 646651.312440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 019 576</ms:GML_ID>
        <ms:NAZWA>096 019 576</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096019576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228870.203257 645025.563396</gml:lowerCorner>
        		<gml:upperCorner>228870.203257 645025.563396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228870.203257 645025.563396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 017 352</ms:GML_ID>
        <ms:NAZWA>096 017 352</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096017352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229298.156118 641315.116264</gml:lowerCorner>
        		<gml:upperCorner>229298.156118 641315.116264</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229298.156118 641315.116264</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 013 046</ms:GML_ID>
        <ms:NAZWA>096 013 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096013046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229370.969000 641789.453000</gml:lowerCorner>
        		<gml:upperCorner>229370.969000 641789.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229370.969000 641789.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 013 533</ms:GML_ID>
        <ms:NAZWA>096 013 533</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096013533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229381.181000 640987.872000</gml:lowerCorner>
        		<gml:upperCorner>229381.181000 640987.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229381.181000 640987.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 012 703</ms:GML_ID>
        <ms:NAZWA>096 012 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096012703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229502.573000 643428.297000</gml:lowerCorner>
        		<gml:upperCorner>229502.573000 643428.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229502.573000 643428.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 015 498</ms:GML_ID>
        <ms:NAZWA>096 015 498</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096015498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212606.927391 686421.104851</gml:lowerCorner>
        		<gml:upperCorner>212606.927391 686421.104851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212606.927391 686421.104851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 061 094</ms:GML_ID>
        <ms:NAZWA>106 061 094</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106061094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212636.856541 684482.631005</gml:lowerCorner>
        		<gml:upperCorner>212636.856541 684482.631005</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212636.856541 684482.631005</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 063 035</ms:GML_ID>
        <ms:NAZWA>106 063 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106063035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212639.981498 685667.728182</gml:lowerCorner>
        		<gml:upperCorner>212639.981498 685667.728182</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212639.981498 685667.728182</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 061 848</ms:GML_ID>
        <ms:NAZWA>106 061 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106061848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212654.321086 685242.806183</gml:lowerCorner>
        		<gml:upperCorner>212654.321086 685242.806183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212654.321086 685242.806183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 062 273</ms:GML_ID>
        <ms:NAZWA>106 062 273</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106062273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212931.181793 687485.572853</gml:lowerCorner>
        		<gml:upperCorner>212931.181793 687485.572853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212931.181793 687485.572853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 059 950</ms:GML_ID>
        <ms:NAZWA>106 059 950</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106059950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213182.008994 688407.522572</gml:lowerCorner>
        		<gml:upperCorner>213182.008994 688407.522572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213182.008994 688407.522572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 058 967</ms:GML_ID>
        <ms:NAZWA>106 058 967</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106058967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213248.213000 688556.528000</gml:lowerCorner>
        		<gml:upperCorner>213248.213000 688556.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213248.213000 688556.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 058 802</ms:GML_ID>
        <ms:NAZWA>106 058 802</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106058802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213321.734000 688974.202000</gml:lowerCorner>
        		<gml:upperCorner>213321.734000 688974.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213321.734000 688974.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 058 375</ms:GML_ID>
        <ms:NAZWA>106 058 375</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106058375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220394.307000 688942.151000</gml:lowerCorner>
        		<gml:upperCorner>220394.307000 688942.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220394.307000 688942.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 048 945</ms:GML_ID>
        <ms:NAZWA>106 048 945</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106048945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220768.287000 688597.596000</gml:lowerCorner>
        		<gml:upperCorner>220768.287000 688597.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220768.287000 688597.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 048 426</ms:GML_ID>
        <ms:NAZWA>106 048 426</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106048426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221181.378000 688395.899000</gml:lowerCorner>
        		<gml:upperCorner>221181.378000 688395.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221181.378000 688395.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 047 965</ms:GML_ID>
        <ms:NAZWA>106 047 965</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106047965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221962.218484 688009.845349</gml:lowerCorner>
        		<gml:upperCorner>221962.218484 688009.845349</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221962.218484 688009.845349</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 047 094</ms:GML_ID>
        <ms:NAZWA>106 047 094</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106047094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222437.389000 687806.494000</gml:lowerCorner>
        		<gml:upperCorner>222437.389000 687806.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222437.389000 687806.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 046 564</ms:GML_ID>
        <ms:NAZWA>106 046 564</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106046564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222558.215000 687825.626000</gml:lowerCorner>
        		<gml:upperCorner>222558.215000 687825.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222558.215000 687825.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 046 442</ms:GML_ID>
        <ms:NAZWA>106 046 442</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106046442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223010.194000 687923.688000</gml:lowerCorner>
        		<gml:upperCorner>223010.194000 687923.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223010.194000 687923.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 045 979</ms:GML_ID>
        <ms:NAZWA>106 045 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106045979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223882.012000 688257.240000</gml:lowerCorner>
        		<gml:upperCorner>223882.012000 688257.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223882.012000 688257.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 045 037</ms:GML_ID>
        <ms:NAZWA>106 045 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106045037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224526.009000 688645.688000</gml:lowerCorner>
        		<gml:upperCorner>224526.009000 688645.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224526.009000 688645.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 044 283</ms:GML_ID>
        <ms:NAZWA>106 044 283</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106044283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238213.852000 709491.157000</gml:lowerCorner>
        		<gml:upperCorner>238213.852000 709491.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238213.852000 709491.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 010 363</ms:GML_ID>
        <ms:NAZWA>106 010 363</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106010363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246309.659816 672932.746983</gml:lowerCorner>
        		<gml:upperCorner>246309.659816 672932.746983</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246309.659816 672932.746983</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 322 890</ms:GML_ID>
        <ms:NAZWA>025 322 890</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025322890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247674.679350 675216.299753</gml:lowerCorner>
        		<gml:upperCorner>247674.679350 675216.299753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247674.679350 675216.299753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 320 123</ms:GML_ID>
        <ms:NAZWA>025 320 123</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025320123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247982.679472 675564.384535</gml:lowerCorner>
        		<gml:upperCorner>247982.679472 675564.384535</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247982.679472 675564.384535</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 319 658</ms:GML_ID>
        <ms:NAZWA>025 319 658</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025319658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248187.807234 681502.810625</gml:lowerCorner>
        		<gml:upperCorner>248187.807234 681502.810625</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248187.807234 681502.810625</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 120 399</ms:GML_ID>
        <ms:NAZWA>091 120 399</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091120399</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248193.917335 675635.059596</gml:lowerCorner>
        		<gml:upperCorner>248193.917335 675635.059596</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248193.917335 675635.059596</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 319 433</ms:GML_ID>
        <ms:NAZWA>025 319 433</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025319433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248229.086000 698909.786000</gml:lowerCorner>
        		<gml:upperCorner>248229.086000 698909.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248229.086000 698909.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 138 463</ms:GML_ID>
        <ms:NAZWA>091 138 463</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091138463</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248645.232069 675706.165894</gml:lowerCorner>
        		<gml:upperCorner>248645.232069 675706.165894</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248645.232069 675706.165894</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 318 974</ms:GML_ID>
        <ms:NAZWA>025 318 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025318974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249225.643573 676145.222975</gml:lowerCorner>
        		<gml:upperCorner>249225.643573 676145.222975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249225.643573 676145.222975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 318 242</ms:GML_ID>
        <ms:NAZWA>025 318 242</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025318242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250888.373725 677511.026656</gml:lowerCorner>
        		<gml:upperCorner>250888.373725 677511.026656</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250888.373725 677511.026656</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 316 092</ms:GML_ID>
        <ms:NAZWA>025 316 092</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025316092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251273.824495 677697.123859</gml:lowerCorner>
        		<gml:upperCorner>251273.824495 677697.123859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251273.824495 677697.123859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 315 663</ms:GML_ID>
        <ms:NAZWA>025 315 663</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025315663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252098.762000 678003.515000</gml:lowerCorner>
        		<gml:upperCorner>252098.762000 678003.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252098.762000 678003.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 314 778</ms:GML_ID>
        <ms:NAZWA>025 314 778</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025314778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211014.335167 678255.151393</gml:lowerCorner>
        		<gml:upperCorner>211014.335167 678255.151393</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211014.335167 678255.151393</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 046 222</ms:GML_ID>
        <ms:NAZWA>108 046 222</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108046222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211300.810000 678628.344000</gml:lowerCorner>
        		<gml:upperCorner>211300.810000 678628.344000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211300.810000 678628.344000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 046 709</ms:GML_ID>
        <ms:NAZWA>108 046 709</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108046709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211026.899000 679429.227000</gml:lowerCorner>
        		<gml:upperCorner>211026.899000 679429.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211026.899000 679429.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.618 003 782</ms:GML_ID>
        <ms:NAZWA>618 003 782</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>618003782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210691.463633 679886.690082</gml:lowerCorner>
        		<gml:upperCorner>210691.463633 679886.690082</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210691.463633 679886.690082</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 048 174</ms:GML_ID>
        <ms:NAZWA>108 048 174</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108048174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211747.725887 679886.899385</gml:lowerCorner>
        		<gml:upperCorner>211747.725887 679886.899385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211747.725887 679886.899385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 067 811</ms:GML_ID>
        <ms:NAZWA>106 067 811</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106067811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210668.149000 680172.086000</gml:lowerCorner>
        		<gml:upperCorner>210668.149000 680172.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210668.149000 680172.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 048 458</ms:GML_ID>
        <ms:NAZWA>108 048 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108048458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211750.543953 680849.294760</gml:lowerCorner>
        		<gml:upperCorner>211750.543953 680849.294760</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211750.543953 680849.294760</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 066 851</ms:GML_ID>
        <ms:NAZWA>106 066 851</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106066851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210624.913000 681208.958000</gml:lowerCorner>
        		<gml:upperCorner>210624.913000 681208.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210624.913000 681208.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 049 498</ms:GML_ID>
        <ms:NAZWA>108 049 498</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108049498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210712.693000 681718.128000</gml:lowerCorner>
        		<gml:upperCorner>210712.693000 681718.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210712.693000 681718.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 050 022</ms:GML_ID>
        <ms:NAZWA>108 050 022</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108050022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210786.570000 682275.406000</gml:lowerCorner>
        		<gml:upperCorner>210786.570000 682275.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210786.570000 682275.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 050 586</ms:GML_ID>
        <ms:NAZWA>108 050 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108050586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212131.986262 682384.001353</gml:lowerCorner>
        		<gml:upperCorner>212131.986262 682384.001353</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212131.986262 682384.001353</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 065 236</ms:GML_ID>
        <ms:NAZWA>106 065 236</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106065236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212374.842000 682909.842000</gml:lowerCorner>
        		<gml:upperCorner>212374.842000 682909.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212374.842000 682909.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 064 665</ms:GML_ID>
        <ms:NAZWA>106 064 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106064665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210837.796000 682926.572000</gml:lowerCorner>
        		<gml:upperCorner>210837.796000 682926.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210837.796000 682926.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 051 239</ms:GML_ID>
        <ms:NAZWA>108 051 239</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108051239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210837.058000 683340.175000</gml:lowerCorner>
        		<gml:upperCorner>210837.058000 683340.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210837.058000 683340.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 051 653</ms:GML_ID>
        <ms:NAZWA>108 051 653</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108051653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210739.529706 684700.183976</gml:lowerCorner>
        		<gml:upperCorner>210739.529706 684700.183976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210739.529706 684700.183976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 053 017</ms:GML_ID>
        <ms:NAZWA>108 053 017</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108053017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210755.253610 685183.312000</gml:lowerCorner>
        		<gml:upperCorner>210755.253610 685183.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210755.253610 685183.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 053 502</ms:GML_ID>
        <ms:NAZWA>108 053 502</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108053502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210876.762641 685910.732750</gml:lowerCorner>
        		<gml:upperCorner>210876.762641 685910.732750</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210876.762641 685910.732750</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 054 244</ms:GML_ID>
        <ms:NAZWA>108 054 244</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108054244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210844.834000 687177.229000</gml:lowerCorner>
        		<gml:upperCorner>210844.834000 687177.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210844.834000 687177.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 055 535</ms:GML_ID>
        <ms:NAZWA>108 055 535</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108055535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210773.939000 687542.435000</gml:lowerCorner>
        		<gml:upperCorner>210773.939000 687542.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210773.939000 687542.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 055 916</ms:GML_ID>
        <ms:NAZWA>108 055 916</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108055916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210690.338000 687856.098000</gml:lowerCorner>
        		<gml:upperCorner>210690.338000 687856.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210690.338000 687856.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 056 242</ms:GML_ID>
        <ms:NAZWA>108 056 242</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108056242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210682.043000 688041.872000</gml:lowerCorner>
        		<gml:upperCorner>210682.043000 688041.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210682.043000 688041.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 056 429</ms:GML_ID>
        <ms:NAZWA>108 056 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108056429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210490.729000 688894.472000</gml:lowerCorner>
        		<gml:upperCorner>210490.729000 688894.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210490.729000 688894.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 057 426</ms:GML_ID>
        <ms:NAZWA>108 057 426</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108057426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209932.827000 689193.900000</gml:lowerCorner>
        		<gml:upperCorner>209932.827000 689193.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209932.827000 689193.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 058 069</ms:GML_ID>
        <ms:NAZWA>108 058 069</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108058069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210828.067261 664279.511572</gml:lowerCorner>
        		<gml:upperCorner>210828.067261 664279.511572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210828.067261 664279.511572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 029 208</ms:GML_ID>
        <ms:NAZWA>108 029 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108029208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211175.614993 664469.588814</gml:lowerCorner>
        		<gml:upperCorner>211175.614993 664469.588814</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211175.614993 664469.588814</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 029 604</ms:GML_ID>
        <ms:NAZWA>108 029 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108029604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212067.549954 665281.620548</gml:lowerCorner>
        		<gml:upperCorner>212067.549954 665281.620548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212067.549954 665281.620548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 030 849</ms:GML_ID>
        <ms:NAZWA>108 030 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108030849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212283.219095 665461.793005</gml:lowerCorner>
        		<gml:upperCorner>212283.219095 665461.793005</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212283.219095 665461.793005</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 031 130</ms:GML_ID>
        <ms:NAZWA>108 031 130</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108031130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212269.838000 666444.246000</gml:lowerCorner>
        		<gml:upperCorner>212269.838000 666444.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212269.838000 666444.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 032 245</ms:GML_ID>
        <ms:NAZWA>108 032 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108032245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211729.352000 666817.098000</gml:lowerCorner>
        		<gml:upperCorner>211729.352000 666817.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211729.352000 666817.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 032 902</ms:GML_ID>
        <ms:NAZWA>108 032 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108032902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211206.134400 668062.986997</gml:lowerCorner>
        		<gml:upperCorner>211206.134400 668062.986997</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211206.134400 668062.986997</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 034 514</ms:GML_ID>
        <ms:NAZWA>108 034 514</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108034514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211240.115000 668820.870000</gml:lowerCorner>
        		<gml:upperCorner>211240.115000 668820.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211240.115000 668820.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 035 282</ms:GML_ID>
        <ms:NAZWA>108 035 282</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108035282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210791.587000 670181.101000</gml:lowerCorner>
        		<gml:upperCorner>210791.587000 670181.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210791.587000 670181.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 036 714</ms:GML_ID>
        <ms:NAZWA>108 036 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108036714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210350.068000 671513.437000</gml:lowerCorner>
        		<gml:upperCorner>210350.068000 671513.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210350.068000 671513.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 038 119</ms:GML_ID>
        <ms:NAZWA>108 038 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108038119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210203.916486 671953.869354</gml:lowerCorner>
        		<gml:upperCorner>210203.916486 671953.869354</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210203.916486 671953.869354</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 038 583</ms:GML_ID>
        <ms:NAZWA>108 038 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108038583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210085.862053 672308.833073</gml:lowerCorner>
        		<gml:upperCorner>210085.862053 672308.833073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210085.862053 672308.833073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 038 957</ms:GML_ID>
        <ms:NAZWA>108 038 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108038957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

